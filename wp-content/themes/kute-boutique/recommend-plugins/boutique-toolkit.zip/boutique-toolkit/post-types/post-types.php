<?php

if ( !defined('ABSPATH')) exit;

function register_post_type_init() {
    
    $labels = array(
        'name'               => __( 'Mega Menu', 'boutique' ),
        'singular_name'      => __( 'Mega Menu Item', 'boutique' ),
        'add_new'            => __( 'Add New', 'boutique' ),
        'add_new_item'       => __( 'Add New Menu Item', 'boutique' ),
        'edit_item'          => __( 'Edit Menu Item', 'boutique' ),
        'new_item'           => __( 'New Menu Item', 'boutique' ),
        'view_item'          => __( 'View Menu Item', 'boutique' ),
        'search_items'       => __( 'Search Menu Items', 'boutique' ),
        'not_found'          => __( 'No Menu Items found', 'boutique' ),
        'not_found_in_trash' => __( 'No Menu Items found in Trash', 'boutique' ),
        'parent_item_colon'  => __( 'Parent Menu Item:', 'boutique' ),
        'menu_name'          => __( 'Mega Menu', 'boutique' ),
    );

    $args = array(
        'labels'              => $labels,
        'hierarchical'        => false,
        'description'         => __('Mega Menus.', 'boutique'),
        'supports'            => array( 'title', 'editor' ),
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'menu_position'       => 40,
        'show_in_nav_menus'   => true,
        'publicly_queryable'  => false,
        'exclude_from_search' => true,
        'has_archive'         => false,
        'query_var'           => true,
        'can_export'          => true,
        'rewrite'             => false,
        'capability_type'     => 'page',
        'menu_icon'           => 'dashicons-welcome-widgets-menus',
    );

    register_post_type( 'megamenu', $args );
    
    $labels = array(
        'name'               => __( 'Header/Footer', 'boutique' ),
        'singular_name'      => __( 'Header/Footer Tenplate', 'boutique' ),
        'add_new'            => __( 'Add New', 'boutique' ),
        'add_new_item'       => __( 'Add New Menu Item', 'boutique' ),
        'edit_item'          => __( 'Edit Menu Item', 'boutique' ),
        'new_item'           => __( 'New Menu Item', 'boutique' ),
        'view_item'          => __( 'View Menu Item', 'boutique' ),
        'search_items'       => __( 'Search Tenplate Items', 'boutique' ),
        'not_found'          => __( 'No Tenplate Items found', 'boutique' ),
        'not_found_in_trash' => __( 'No Tenplate Items found in Trash', 'boutique' ),
        'parent_item_colon'  => __( 'Parent Tenplate Item:', 'boutique' ),
        'menu_name'          => __( 'Header/Footer', 'boutique' ),
    );

    $args = array(
        'labels'              => $labels,
        'hierarchical'        => false,
        'description'         => __('To Build Template Header/Footer.', 'boutique'),
        'supports'            => array( 'title', 'editor' ),
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'menu_position'       => 40,
        'show_in_nav_menus'   => true,
        'publicly_queryable'  => false,
        'exclude_from_search' => true,
        'has_archive'         => false,
        'query_var'           => true,
        'can_export'          => true,
        'rewrite'             => false,
        'capability_type'     => 'page',
    );

    register_post_type( 'template', $args );
    
    
    /* Testimonials */
    $labels = array(
        'name'               => __( 'Testimonial', 'boutique' ),
        'singular_name'      => __( 'Testimonial', 'boutique'),
        'add_new'            => __( 'Add New', 'boutique' ),
        'all_items'          => __( 'Testimonials', 'boutique' ),
        'add_new_item'       => __( 'Add New Testimonial', 'boutique' ),
        'edit_item'          => __( 'Edit Testimonial', 'boutique' ),
        'new_item'           => __( 'New Testimonial', 'boutique' ),
        'view_item'          => __( 'View Testimonial', 'boutique' ),
        'search_items'       => __( 'Search Testimonial', 'boutique' ),
        'not_found'          => __( 'No Testimonial found', 'boutique' ),
        'not_found_in_trash' => __( 'No Testimonial found in Trash', 'boutique' ),
        'parent_item_colon'  => __( 'Parent Testimonial', 'boutique' ),
        'menu_name'          => __( 'Testimonials', 'boutique' )
    );
    $args = array(
        'labels'             => $labels,
        'hierarchical'       => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_nav_menus'  => false,
        'supports'           => array( 'title', 'thumbnail', 'editor' ),
        'rewrite'            => false,
        'query_var'          => false,
        'publicly_queryable' => false,
        'public'             => true,
        'menu_icon'          => 'dashicons-editor-quote',
        

    );
    register_post_type( 'testimonial', $args );
    
    /* Services */
    $labels = array(
        'name'               => __( 'Services', 'boutique' ),
        'singular_name'      => __( 'Services', 'boutique'),
        'add_new'            => __( 'Add New', 'boutique' ),
        'all_items'          => __( 'Services', 'boutique' ),
        'add_new_item'       => __( 'Add New Service', 'boutique' ),
        'edit_item'          => __( 'Edit Service', 'boutique' ),
        'new_item'           => __( 'New Service', 'boutique' ),
        'view_item'          => __( 'View Service', 'boutique' ),
        'search_items'       => __( 'Search Service', 'boutique' ),
        'not_found'          => __( 'No Service found', 'boutique' ),
        'not_found_in_trash' => __( 'No Service found in Trash', 'boutique' ),
        'parent_item_colon'  => __( 'Parent Service', 'boutique' ),
        'menu_name'          => __( 'Services', 'boutique' )
    );
    $args = array(
        'labels'             => $labels,
        'hierarchical'       => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_nav_menus'  => false,
        'supports'           => array( 'title', 'thumbnail', 'editor' ),
        'rewrite'            => true,
        'query_var'          => true,
        'publicly_queryable' => true,
        'public'             => true,
        'menu_icon'          => 'dashicons-update'
    );
    register_post_type( 'service', $args );

    flush_rewrite_rules();
}

add_action( 'init', 'register_post_type_init' );