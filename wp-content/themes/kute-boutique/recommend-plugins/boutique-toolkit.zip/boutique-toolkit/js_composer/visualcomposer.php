<?php
/**
 * @author  AngelsIT
 * @package KUTE TOOLKIT
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
if( is_admin() ){
    require_once KUTETHEME_PLUGIN_PATH . '/js_composer/custom-fields.php';
}

if ( kt_check_active_plugin( 'woocommerce/woocommerce.php' ) ) {
    require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/brand.php';
    require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/feature_product.php';
    require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/woocommerce.php';
    
    function kt_mini_cart( $atts ) {
        $atts = shortcode_atts( array(
    		'title' => ''
    	),  $atts, 'kt_mini_cart' );
        
    	// Get mini cart
		ob_start();

		woocommerce_mini_cart($atts);

		$mini_cart = ob_get_clean();
        return $mini_cart;
    }
    add_shortcode( 'kt_mini_cart', 'kt_mini_cart' );
    
    function kt_my_account( $atts ) {
        $atts = shortcode_atts( array(
    		'title'     => __( "My Account", 'boutique'),
            'login'     => __( 'Login', 'boutique' ),
            'logout'    => __( 'Logout', 'boutique' ),
            'register'  => __( 'Register', 'boutique' )
            
    	),  $atts, 'kt_my_account' );
        
    	// Get mini cart
		ob_start();
        $myaccount_page_id = get_option( 'woocommerce_myaccount_page_id' );
        $myaccount_link = get_permalink( $myaccount_page_id );
        
        if( is_user_logged_in()){ ?>
            <?php
                if ( $myaccount_page_id ) {
                      $logout_url = wp_logout_url( get_permalink( woocommerce_get_page_id( 'shop' ) ) );
                      if ( get_option( 'woocommerce_force_ssl_checkout' ) == 'yes' ){
                        $logout_url = str_replace( 'http:', 'https:', $logout_url );
                      }
                }
            ?>
            <a href="<?php echo esc_url( $myaccount_link );?>"><?php echo esc_html( $atts['title'] ) ?></a>
            <?php if( isset( $logout_url ) && $logout_url ):?>
            </li>
            <li id="menu-item-logout" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-logout menu-item-sc"><a href="<?php echo esc_url( $logout_url );?>"><?php echo esc_html( $atts['logout'] ) ?></a>
            <?php endif;?>
        <?php }else{ ?>
            <a href="<?php echo esc_url( $myaccount_link );?>"><?php echo esc_html( $atts['login'] ) ?>/<?php echo esc_html( $atts['register'] ) ?></a>
        <?php }
        return ob_get_clean() ;
    }
    add_shortcode( 'kt_my_account', 'kt_my_account' );
    
    function kt_checkout_link( $atts ) {
        $atts = shortcode_atts( array(
    		'title' => __( 'Check Out', 'boutique' )
    	),  $atts, 'kt_checkout_link' );
        
    	// Get mini cart
		ob_start();?>
            <a href="<?php echo esc_url( wc_get_checkout_url() ); ?>"><?php echo esc_html( $atts[ 'title' ] ) ?></a>
        <?php return ob_get_clean();
    }
    add_shortcode( 'kt_checkout_link', 'kt_checkout_link' );
}
if ( kt_check_active_plugin( 'yith-woocommerce-compare/init.php' ) ) {
    if( defined( 'YITH_WOOCOMPARE' ) ){
        function kt_compare_link( $atts ) {
            $atts = shortcode_atts( array(
            	'title' => __( "Compare", 'boutique')
            ),  $atts, 'kt_compare_link' );
        
            global $yith_woocompare; 
            $count = count($yith_woocompare->obj->products_list);
        	// Compare
    		ob_start(); ?>
            <a href="#" class="yith-woocompare-open"><?php echo esc_html( $atts['title'] ) ?><span>(<?php echo esc_attr( $count ); ?>)</span></a>
    		<?php return ob_get_clean();
        }
        add_shortcode( 'kt_compare_link', 'kt_compare_link' );
    }
}
if ( kt_check_active_plugin( 'yith-woocommerce-wishlist/init.php' ) ) {
    
    if( function_exists( 'YITH_WCWL' ) ){
        function kt_wishlist_link( $atts ) {
            $atts = shortcode_atts( array(
            	'title' => __( "Wishlists", 'boutique')
            ),  $atts, 'kt_wishlist_link' );
            
            $wishlist_url = YITH_WCWL()->get_wishlist_url();
            
            ob_start(); ?>
                <a href="<?php echo esc_url( $wishlist_url );?>"><?php echo esc_html( $atts['title'] ) ?></a>
    		<?php return ob_get_clean();
        }
        add_shortcode( 'kt_wishlist_link', 'kt_wishlist_link' );
    }
}
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/header.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/footer.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/banner-title.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/blog.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/service.php';

require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/custom_menu.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/tabs.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/title.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/social.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/payment.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/newsletter.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/video.php';

require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/single_product.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/contact_info.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/text_icon.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/blockquote.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/blocktext.php';
require_once KUTETHEME_PLUGIN_PATH . '/js_composer/shortcodes/kt_featured_box.php';

