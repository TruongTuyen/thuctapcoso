<?php

// Exit if accessed directly
if ( ! defined('ABSPATH')) exit;

global $fonts_pre_icons;

vc_map( array(
    "name" => __( "KT Featured Box", 'boutique'),
    "base" => "kt_featured_box",
    "category" => __('Kute Theme', 'boutique' ),
    "description" => __( 'Display a blockquote', 'boutique' ),
    "params" => array(
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Box Style', 'boutique' ),
            'param_name'  => 'style',
            'admin_label' => true,
            'value'       => array(
                __( 'Style 1', 'boutique' ) => 'style1',
                __( 'Style 2', 'boutique' ) => 'style2',
            )
        ),
        array(
            'type' => 'dropdown',
            'heading' => __( 'Icon library', 'boutique' ),
            'value' => array(
                __( 'Font Awesome', 'boutique' ) => 'fontawesome',
                __( 'Pe icon', 'boutique' )     => 'fontpe',
            ),
            'admin_label' => true,
            'param_name' => 'icon_lib',
            'description' => __( 'Select icon library.', 'boutique' ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => __( 'Icon', 'boutique' ),
            'param_name' => 'icon_fontawesome',
            'value' => 'fa fa-adjust', // default value to backend editor admin_label
            'settings' => array(
                'emptyIcon' => false,
                'iconsPerPage' => 4000,
                // default 100, how many icons per/page to display, we use (big number) to display all icons in single page
            ),
            'dependency' => array(
                'element' => 'icon_lib',
                'value' => 'fontawesome',
            ),
            'description' => __( 'Select icon from library.', 'boutique' ),
        ),
        array(
            'type'       => 'iconpicker',
            'heading'    => esc_html__('Icon', 'boutique'),
            'param_name' => 'icon_fontpe',
            'vaule'      =>'pe-7s-album',
            'settings'   => array(
                'emptyIcon'    => false,
                'type'         => 'pre',
                'source'       => $fonts_pre_icons,                 
            ),
            'dependency' => array(
                'element' => 'icon_lib',
                'value' => 'fontpe',
            ),
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Title", 'boutique' ),
            "param_name"  => "title",
            "admin_label" => true
        ),
        array(
            "type"        => "textarea",
            "heading"     => __( "Text content", 'boutique' ),
            "param_name"  => "text",
            "admin_label" => false,
            'dependency' => array(
                'element' => 'style',
                'value' => 'style1',
            ),
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Custom link", 'boutique' ),
            "param_name"  => "link",
            "admin_label" => false
        ),
        
        array(
            "type" => "textfield",
            "heading" => __( "Extra class name", "boutique" ),
            "param_name" => "el_class",
            "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "boutique" ),
            'admin_label' => false,
        ),
        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'boutique' ),
            'param_name' => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group' => __( 'Design options', 'boutique' ),
            'admin_label' => false,
        ),
    ),
));

class WPBakeryShortCode_Kt_featured_box extends WPBakeryShortCode {
    
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'kt_featured_box', $atts ) : $atts;
        $atts = shortcode_atts( array(
            'title'            => '',
            'text'             => '',
            'link'             => '',
            'icon_lib'         =>'',
            'icon_fontawesome' =>'',
            'icon_fontpe'     =>'',
            'style'            => 'style1',
            'el_class'         => '',
            'css'              => ''
        ), $atts );
        extract($atts);
        $elementClass = array(
            'base' => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' '.$style.' ', $this->settings['base'], $atts ),
            'extra' => $this->getExtraClass( $el_class ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        $icon = '';
        if( $icon_lib && $icon_lib != ""){
            if( $icon_lib == 'fontawesome')
                $icon = $icon_fontawesome;
            elseif( $icon_lib == 'fontpe' )
                $icon = $icon_fontpe;
        }
        ob_start();
        ?>
        <div class="element-icon <?php echo esc_attr( $elementClass );?>">
            <?php if( $icon ):?>
            <div class="icon"><span class="<?php echo esc_attr($icon);?>"></span></div>
            <?php endif;?>
            <div class="content">
                <?php if( $title ):?>
                <?php if( $link):?> <a href="<?php echo esc_url( $link );?>"><?php endif;?>
                <h4 class="title"><?php echo esc_html( $title );?></h4>
                <?php if( $link ):?> </a><?php endif;?>
                <?php endif;?>
                <?php if( $text ):?>
                <div class="text"><?php echo esc_html( $text);?></div>
                <?php endif;?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}