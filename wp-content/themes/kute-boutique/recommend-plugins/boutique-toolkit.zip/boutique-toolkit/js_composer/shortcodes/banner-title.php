<?php

// Exit if accessed directly
if ( ! defined('ABSPATH')) exit;

vc_map( array(
    "name" => __( "Banner", 'boutique'),
    "base" => "kt_banner",
    "category" => __('Kute Theme', 'boutique' ),
    "description" => __( 'Display a banner', 'boutique' ),
    "params" => array(
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Style', 'boutique' ),
            'param_name'  => 'style',
            'admin_label' => true,
            'value'       => array(
                __( 'Style 1', 'boutique' ) => 'style-1',
                __( 'Style 2', 'boutique' ) => 'style-2',
        	)
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Title", 'boutique' ),
            "param_name"  => "title",
            "admin_label" => true
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "SubTitle", 'boutique' ),
            "param_name"  => "sub_title",
            "admin_label" => true
        ),
        array(
			'type' => 'autocomplete',
			'heading' => __( 'Products ID', 'boutique' ),
			'param_name' => 'product_id',
			'settings' => array(
				'multiple' => true,
				'sortable' => true,
				'unique_values' => true,
				// In UI show results except selected. NB! You should manually check values in backend
			),
            "admin_label" => true,
			'save_always' => true,
			'description' => __( 'Enter List of Products', 'boutique' )
		),
        array(
            "type"        => "textfield",
            "heading"     => __( "Button Text", 'boutique' ),
            "param_name"  => "button_text",
            "value"       => __( 'SHOP PRODUCTS', 'boutique' ),
            "admin_label" => true,
            "dependency"  => array("element" => "style", "value" => array( 'style-2' ))
        ),
        array(
            "type"        => "attach_image",
            "heading"     => __("Banner Image", 'boutique'),
            "param_name"  => "banner_image",
            "admin_label" => true,
            'description' => __( 'It shows the image of banner', 'boutique' )
        ),
        array(
            "type"        => "textfield",
            "heading"     => __("Link", 'boutique'),
            "param_name"  => "link",
            "admin_label" => false,
            'description' => __( 'It shows the link.', 'boutique' )
        ),
        array(
            "type" => "textfield",
            "heading" => __( "Extra class name", "js_composer" ),
            "param_name" => "el_class",
            "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
            'admin_label' => false,
        ),
        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'boutique' ),
            'param_name' => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group' => __( 'Design options', 'boutique' ),
            'admin_label' => false,
        ),
    ),
));

class WPBakeryShortCode_Kt_Banner extends WPBakeryShortCode {
    
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'kt_banner', $atts ) : $atts;
        $atts = shortcode_atts( array(
            'style'            => 'style-1',
            
            'title'            => '',
            'sub_title'        => '',
            'button_text'      => '',
            
            'product_id'       => '',
            'banner_image'     => '',
            'link'             => '#',
            'el_class'         => '',
            'css'              => ''
        ), $atts );
        extract($atts);
        $elementClass = array(
            'base' => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' ', $this->settings['base'], $atts ),
            'extra' => $this->getExtraClass( $el_class ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        
        $banner_url = "";
        if( $banner_image ){
            $banner = wp_get_attachment_image_src( $banner_image , 'full' );  
            $banner_url =  is_array($banner) ? esc_url($banner[0]) : '';
        }
        ob_start();
        if( $style == 'style-2' ):
            if( $product_id ):
                $meta_query = WC()->query->get_meta_query();
            
                $ids = explode( ',', $product_id );
                $args = array(
                    'post_type'           => 'product',
        			'post_status'		  => 'publish',
        			'ignore_sticky_posts' => 1,
        			'posts_per_page' 	  => 1,
        			'meta_query' 		  => $meta_query,
                    'suppress_filter'     => true,
        		);
                if( is_array( $ids ) && ! empty( $ids ) ){
                    $args[ 'post__in' ] = $ids;
                    $args [ 'orderby' ] = 'post__in';
                }
                $products = new WP_Query( apply_filters( 'woocommerce_shortcode_products_query', $args, $atts ) );
                
                if ( $products->have_posts() ) :
                    while ( $products->have_posts() ) : $products->the_post(); $link = $link ? $link : get_the_permalink( get_the_ID() ); ?>
                    <div class="banner-text style2">
                        <?php if( isset( $banner_url ) && $banner_url ): ?>
            				<div class="image">
            					<a class="banner-opacity" href="<?php echo esc_url( $link ) ?>">
                                    <img src="<?php echo esc_url( $banner_url ) ?>" alt="<?php echo esc_attr( $title ) ? esc_attr( $title ) : get_the_title() ?>" />
                                </a>
            				</div>
                        <?php elseif ( has_post_thumbnail() ): ?>
                            <div class="image">
            					<a class="banner-opacity" href="<?php echo esc_url( $link ) ?>">
                                    <?php if(  function_exists( 'woocommerce_get_product_thumbnail' ) ): ?>
                                        <?php echo woocommerce_get_product_thumbnail( 'full' ) ?>
                                    <?php else: ?>
                                        <?php echo get_the_post_thumbnail( get_the_ID(), 'full' ); ?>
                                    <?php  endif; ?>
                                </a>
            				</div>
                        <?php endif; ?>
        				<div class="content-text">
                            <?php if( $title ): ?>
                                <h3 class="title"><?php echo esc_html( $title ) ; ?></h3>
                            <?php else: ?>
                                <h3 class="title"><?php the_title() ?></h3>
                            <?php endif; ?>
                            
                            <?php if( $sub_title ): ?>
                                <span class="sub-title"><?php echo esc_html( $sub_title ) ; ?></span>
                            <?php endif; ?>
                            
                            <?php if( $button_text ): $add_to_cart_url = $products->add_to_cart_url(); ?>
        					   <a href="<?php echo esc_url( $add_to_cart_url ? $add_to_cart_url : $link ); ?>" class="button"><?php echo esc_html( $button_text ) ?></a>
                            <?php else: ?>
                                <a href="<?php echo esc_url( $add_to_cart_url ? $add_to_cart_url : $link ); ?>" class="button"><?php esc_html_e( 'SHOP PRODUCTS', 'boutique' ) ?></a>
                            <?php endif; ?>
        				</div>
        			</div>
                <?php endwhile; wp_reset_query(); wp_reset_postdata();
                else: ?>
                    <div class="banner-text style2">
                        <?php if( $banner_url ): ?>
            				<div class="image">
            					<a class="banner-opacity" href="<?php echo esc_url( $link ) ?>">
                                    <img src="<?php echo esc_url( $banner_url ) ?>" alt="<?php echo esc_attr( $title ) ?>" />
                                </a>
            				</div>
                        <?php endif; ?>
        				<div class="content-text">
                            <?php if( $title ): ?>
                                <h3 class="title"><?php echo esc_html( $title ) ; ?></h3>
                            <?php endif; ?>
                            
                            <?php if( $sub_title ): ?>
                                <span class="sub-title"><?php echo esc_html( $sub_title ) ; ?></span>
                            <?php endif; ?>
                            
                            <?php if( $button_text ): ?>
        					   <a href="<?php echo esc_url( $link ) ?>" class="button"><?php echo esc_html( $button_text ) ?></a>
                            <?php endif; ?>
        				</div>
        			</div>
                <?php endif;// End if product have post
            else: ?>
                <div class="banner-text style2">
                    <?php if( $banner_url ): ?>
        				<div class="image">
        					<a class="banner-opacity" href="<?php echo esc_url( $link ) ?>">
                                <img src="<?php echo esc_url( $banner_url ) ?>" alt="<?php echo esc_attr( $title ) ?>" />
                            </a>
        				</div>
                    <?php endif; ?>
    				<div class="content-text">
                        <?php if( $title ): ?>
                            <h3 class="title"><?php echo esc_html( $title ) ; ?></h3>
                        <?php endif; ?>
                        
                        <?php if( $sub_title ): ?>
                            <span class="sub-title"><?php echo esc_html( $sub_title ) ; ?></span>
                        <?php endif; ?>
                        
                        <?php if( $button_text ): ?>
    					   <a href="<?php echo esc_url( $link ) ?>" class="button"><?php echo esc_html( $button_text ) ?></a>
                        <?php endif; ?>
    				</div>
    			</div>
            <?php endif; //End if product
        else:
            if( $product_id ):
                $meta_query = WC()->query->get_meta_query();
            
                $ids = explode( ',', $product_id );
                $args = array(
                    'post_type'           => 'product',
        			'post_status'		  => 'publish',
        			'ignore_sticky_posts' => 1,
        			'posts_per_page' 	  => 1,
        			'meta_query' 		  => $meta_query,
                    'suppress_filter'     => true,
        		);
                if( is_array( $ids ) && ! empty( $ids ) ){
                    $args[ 'post__in' ] = $ids;
                    $args [ 'orderby' ] = 'post__in';
                }
                $products = new WP_Query( apply_filters( 'woocommerce_shortcode_products_query', $args, $atts ) );
                
                if ( $products->have_posts() ) :
                    while ( $products->have_posts() ) : $products->the_post(); ?>
                        <a href="<?php echo esc_url( $link ? $link : get_the_permalink( get_the_ID() ) ) ?>" class="banner-title <?php echo esc_attr( $elementClass ) ?>">
                            <?php if( $banner_url ): ?>
                                <img src="<?php echo esc_url( $banner_url ) ?>" alt="<?php echo esc_attr( $title ) ?>" />
                            <?php elseif ( has_post_thumbnail() ): ?>
                                <?php if(  function_exists( 'woocommerce_get_product_thumbnail' ) ): ?>
                                    <?php echo woocommerce_get_product_thumbnail( 'full' ) ?>
                                <?php else: ?>
                                    <?php echo get_the_post_thumbnail( get_the_ID(), 'full' ); ?>
                                <?php  endif; ?>
                            <?php endif; ?>
                            <?php if( $title ): ?>
                                <h3 class="text"><?php echo esc_html( $title ) ; ?></h3>
                            <?php else: ?>
                                <h3 class="text"><?php the_title() ?></h3>
                            <?php endif; ?>
        					<?php if( $sub_title ): ?>
                                <span class="price"><?php echo esc_html( $sub_title ) ; ?></span>
                            <?php else: ?>
                                <?php if ( function_exists( 'woocommerce_template_loop_price' ) ) : ?>
                                        <?php woocommerce_template_loop_price(); ?>
                                <?php endif; ?>
                            <?php endif; ?>
        				</a>
                <?php endwhile; // end of the loop.
                    wp_reset_query();
                    wp_reset_postdata();
                else: //get post
                    $args[ 'post_type' ] = 'post';
                    $args [ 'meta_query' ] = array();
                     
                    $posts = new WP_Query( apply_filters( 'woocommerce_shortcode_products_query', $args, $atts ) );
                    if ( $posts->have_posts() ) : ?>
                        <?php while ( $posts->have_posts() ) : $posts->the_post(); ?>
                            <a href="<?php echo esc_url( $link ? $link : get_the_permalink( get_the_ID() ) ) ?>" class="banner-title <?php echo esc_attr( $elementClass ) ?>">
                                <?php if( $banner_url ): ?>
                                    <img src="<?php echo esc_url( $banner_url ) ?>" alt="<?php echo esc_attr( $title ) ?>" />
                                <?php elseif ( has_post_thumbnail() ): ?>
                                    <?php echo get_the_post_thumbnail( get_the_ID(), 'full' ); ?>
                                <?php endif; ?>
                                
                                <?php if( $title ): ?>
                                    <h3 class="text"><?php echo esc_html( $title ) ; ?></h3>
                                <?php else: ?>
                                    <h3 class="text"><?php the_title() ?></h3>
                                <?php endif; ?>
                                
            					<?php if( $sub_title ): ?>
                                    <span class="price"><?php echo esc_html( $sub_title ) ; ?></span>
                                <?php endif; ?>
            				</a>
                        <?php endwhile; wp_reset_query(); wp_reset_postdata(); ?>
                     <?php else: ?>
                        <a href="<?php echo esc_url( $link ) ?>" class="banner-title <?php echo esc_attr( $elementClass ) ?>">
                            <?php if( $banner_url ): ?>
                                <img src="<?php echo esc_url( $banner_url ) ?>" alt="<?php echo esc_attr( $title ) ?>" />
                            <?php endif; ?>
                            <?php if( $title ): ?>
                                <h3 class="text"><?php echo esc_html( $title ) ; ?></h3>
                            <?php endif; ?>
            				<?php if( $sub_title ): ?>
                                <span class="price"><?php echo esc_html( $sub_title ) ; ?></span>
                            <?php endif; ?>
            			</a>
                    <?php endif;
                endif;
            else: ?>
                <a href="<?php echo esc_url( $link ) ?>" class="banner-title <?php echo esc_attr( $elementClass ) ?>">
                    <?php if( $banner_url ): ?>
                        <img src="<?php echo esc_url( $banner_url ) ?>" alt="<?php echo esc_attr( $title ) ?>" />
                    <?php endif; ?>
                    <?php if( $title ): ?>
                        <h3 class="text"><?php echo esc_html( $title ) ; ?></h3>
                    <?php endif; ?>
    				<?php if( $sub_title ): ?>
                        <span class="price"><?php echo esc_html( $sub_title ) ; ?></span>
                    <?php endif; ?>
    			</a>
            <?php
            endif;//check product id
        endif;
        return ob_get_clean();
    }
}