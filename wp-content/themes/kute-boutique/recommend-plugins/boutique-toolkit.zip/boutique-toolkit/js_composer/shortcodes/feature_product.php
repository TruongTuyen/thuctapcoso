<?php
/**
 * @author  AngelsIT
 * @package Boutique TOOLKIT
 * @version 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

vc_map( array(
    "name"        => __( "Featured Products", 'boutique'),
    "base"        => "kt_featured_products",
    "category"    => __('Kute Theme', 'boutique' ),
    "description" => __( "Display Featured Products", 'boutique'),
    "params"      => array(
        array(
            "type"        => "textfield",
            "heading"     => __( "Title", 'boutique' ),
            "param_name"  => "title",
            "admin_label" => true,
            'description' => __( 'Display title box featured', 'boutique' )
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Subtitle", 'boutique' ),
            "param_name"  => "subtitle",
            "admin_label" => true,
            'description' => __( 'Display subtitle box featured', 'boutique' )
        ),
        array(
            "type"        => "dropdown",
            "heading"     => __("Box Style", 'boutique'),
            "param_name"  => "box_style",
            "admin_label" => false,
            'std'         => '',
            'value'       => array(
                __( 'Default', 'boutique' ) => '',
                __( 'Style 2', 'boutique' )   => 'style2',
            ),
        ),
        array(
            "type"        => "dropdown",
            "heading"     => __("Head Position", 'boutique'),
            "param_name"  => "head_position",
            "admin_label" => false,
            'std'         => 'left',
            'value'       => array(
                __( 'Left', 'boutique' )  => 'left',
                __( 'Right', 'boutique' ) => 'right',
            ),
        ),    
        array(
            "type"        => "dropdown",
            "heading"     => __("Target", 'boutique'),
            "param_name"  => "target",
            "admin_label" => true,
            'std'         => 'featured',
            'value'       => array(
                __( 'Featured', 'boutique' ) => 'featured',
                __( 'By IDs', 'boutique' )   => 'by_id',
            ),
        ),
        array(
            'type' => 'autocomplete',
            'heading' => __( 'Products', 'boutique' ),
            'param_name' => 'ids',
            'settings' => array(
                'multiple' => true,
                'sortable' => true,
                'unique_values' => true,
                // In UI show results except selected. NB! You should manually check values in backend
            ),
            'save_always' => true,
            'description' => __( 'Enter List of Products', 'boutique' ),
            "dependency"  => array("element" => "target", "value" => array( 'by_id' )),
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __( "Per page", 'boutique' ),
            "param_name"  => "per_page",
            "value"       => "4",
            "admin_label" => true,
            'description' => __( 'The number of products put out from your store.', 'boutique' ),
            "dependency"  => array("element" => "box_type","value" => array('featured'))
        ),
        array(
            "type"       => "dropdown",
            "heading"    => __("Product style display", 'boutique'),
            "param_name" => "product_style",
            "value"      => array(
                __('Style 1', 'boutique')  => '1',
                __('Style 2', 'boutique')  => '2',
                __('Style 3', 'boutique')  => '3',
                __('Style 4', 'boutique')  => '4',
                __('Style 5', 'boutique')  => '5',
            ),
            'std'         => '1',
        ),
        array(
            "type"       => "dropdown",
            "heading"    => __("Order by", 'boutique'),
            "param_name" => "orderby",
            "value"      => array(
                __('None', 'boutique')       => 'none',
                __('ID', 'boutique')         => 'ID',
                __('Author', 'boutique')     => 'author',
                __('Name', 'boutique')       => 'name',
                __('Date', 'boutique')       => 'date',
                __('Modified', 'boutique')   => 'modified',
                __('Rand', 'boutique')       => 'rand',
                __('Sale Price', 'boutique') => '_sale_price'
        	),
            'std'         => 'date',
            "description" => __("Select how to sort retrieved posts.", 'boutique' ),
        ),
        array(
            "type"       => "dropdown",
            "heading"    => __("Order", 'boutique'),
            "param_name" => "order",
            "value"      => array(
                __('ASC', 'boutique')  => 'ASC',
                __('DESC', 'boutique') => 'DESC'
        	),
            'std'         => 'DESC',
            "description" => __( "Designates the ascending or descending order.", 'boutique' )
        ),
        
        array(
            'type'        => 'attach_image',
            'heading'     => __( 'Background Image', 'boutique' ),
            'param_name'  => 'bg_left',
            'description' => __( 'Setup background left for box', 'boutique' )
    	),
        array(
            "type"        => "textfield",
            "heading"     => __( "Link more items", 'boutique' ),
            "param_name"  => "link",
            "admin_label" => true,
            'description' => __( 'When you click "see more items" to direct with the link', 'boutique' )
        ),
        // Carousel
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'AutoPlay', 'boutique' ),
            'param_name'  => 'autoplay',
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false
        ),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'Navigation', 'boutique' ),
            'param_name'  => 'navigation',
            'description' => __( "Show buton 'next' and 'prev' buttons.", 'boutique' ),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
        ),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'Loop', 'boutique' ),
            'param_name'  => 'loop',
            'description' => __( "Inifnity loop. Duplicate last and first items to get loop illusion.", 'boutique' ),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __("Slide Speed", 'boutique'),
            "param_name"  => "slidespeed",
            "value"       => "200",
            "suffix"      => __("milliseconds", 'boutique'),
            "description" => __('Slide speed in milliseconds', 'boutique'),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __("Margin", 'boutique'),
            "param_name"  => "margin",
            "value"       => "30",
            "suffix"      => __("px", 'boutique'),
            "description" => __('Distance( or space) between 2 item', 'boutique'),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
        ),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 1,
                __( 'No', 'boutique' )  => 0
            ),
            'std'         => 1,
            'heading'     => __( 'Use Carousel Responsive', 'boutique' ),
            'param_name'  => 'use_responsive',
            'description' => __( "Try changing your browser width to see what happens with Items and Navigations", 'boutique' ),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on destop (Screen resolution of device >= 992px )", 'boutique'),
            "param_name"  => "items_destop",
            "value"       => "3",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The number of items on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on tablet (Screen resolution of device >=768px and < 992px )", 'boutique'),
            "param_name"  => "items_tablet",
            "value"       => "2",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The number of items on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on mobile (Screen resolution of device < 768px)", 'boutique'),
            "param_name"  => "items_mobile",
            "value"       => "1",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The numbers of item on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Extra class name", 'boutique' ),
            "param_name"  => "el_class",
            "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
        ),
        array(
            'type'           => 'css_editor',
            'heading'        => __( 'Css', 'boutique' ),
            'param_name'     => 'css',
            'group'          => __( 'Design options', 'boutique' )
        )
    )
));

class WPBakeryShortCode_Kt_Featured_Products extends WPBakeryShortCode {
    
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'kt_featured_products', $atts ) : $atts;
                        
        $atts = shortcode_atts( array(
            'title'         => '',
            'subtitle'      => '',
            'box_style'     => '',
            'ids'           => '',
            'orderby'       => 'date',
            'order'         => 'desc',
            'per_page'      => 4,
            'bg_left'       => '',
            'link'          => '',
            'product_style' => '1',
            'target'        =>'featured',
            'head_position' =>'left',
            
            'css_animation' => '',
            'el_class'      => '',
            'css'           => '',
            //Carousel            
            'autoplay'       => 'false', 
            'navigation'     => 'false',
            'margin'         => 30,
            'slidespeed'     => 200,
            'css'            => '',
            'loop'           => 'false',
            //Default
            'use_responsive' => 1,
            'items_destop'   => 3,
            'items_tablet'   => 2,
            'items_mobile'   => 1,
            
        ), $atts );
        extract($atts);
        
        $elementClass = array(
            'base'             => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' featured ', $this->settings['base'], $atts ),
            'extra'            => $this->getExtraClass( $el_class ),
            'css_animation'    => $this->getCSSAnimation( $css_animation ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        $data_carousel = array(
            "autoplay"           => $autoplay,
            "nav"                => $navigation,
            "margin"             => $margin,
            "slidespeed"         => $slidespeed,
            "theme"              => 'style-navigation-bottom',
            "autoheight"         => 'false',
            'dots'               => 'false',
            'loop'               => $loop,
            'autoplayTimeout'    => 1000,
            'autoplayHoverPause' => 'true'
        );
        ob_start();
        
        $query_args = array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $per_page,
			'orderby'             => $orderby,
			'order'               => $order,
		);
        
		$meta_query   = WC()->query->get_meta_query();
        if( $target == 'featured' ){
            $meta_query[] = array(
    			'key'   => '_featured',
    			'value' => 'yes'
    		);
        }else{
            $query_args[ 'post__in' ] = explode(',', $ids);
        }
        $query_args[ 'meta_query' ]  = $meta_query;
        
        $products                    = new WP_Query( apply_filters( 'woocommerce_shortcode_products_query', $query_args, $atts ) );
		$columns                     = absint( $items_destop );
		$woocommerce_loop['columns'] = $columns;

        if( $products->post_count <= 1 ){
            $data_carousel['loop'] = 'false';
        }
        if( $use_responsive == '1' ):
            $arr = array( 
                '0'   => array ( 
                    "items" => $items_mobile
                ), 
                '768' => array ( 
                    "items" => $items_tablet
                ), 
                '992' => array (
                    "items" => $items_destop
                )
            );
            $data_responsive = json_encode($arr);
            $data_carousel["responsive"] = $data_responsive;
        else:
            $data_carousel['items'] = $items_destop;
        endif;
        ?>
        <div class="box-product-featured <?php echo esc_attr( $head_position);?> <?php echo esc_attr( $box_style);?> <?php echo esc_attr( $elementClass ) ?>">
        	<div class="box-head">
        		<?php if( isset( $bg_left ) && $bg_left ): ?>
                    <?php 
                        $att_bg     = wp_get_attachment_image_src( $bg_left , 'full' );  
                        $att_bg_url =  is_array($att_bg) ? esc_url($att_bg[0]) : ""; 
                    ?>
                    <?php if( $att_bg_url ): ?>
                        <img src="<?php echo esc_url( $att_bg_url ) ?>" alt="<?php esc_attr( $title ) ?>" />
                    <?php else: ?>
                        <img src="<?php echo KUTETHEME_PLUGIN_URL. 'js_composer/assets/imgs/left-bg-featured.png' ?>" alt="bg-left-feature" />
                    <?php endif; ?>
                <?php else: ?>
                    <img src="<?php echo KUTETHEME_PLUGIN_URL. 'js_composer/assets/imgs/left-bg-featured.png' ?>" alt="bg-feature" />
                <?php endif;  ?>
        		<div class="inner">
        			<h2 class="box-title"><?php echo esc_html( $title ) ?></h2>
        			<span class="box-sub-title"><?php echo esc_html( $subtitle ) ?></span>
        			<a href="<?php echo esc_url( $link ); ?>" class="box-link"><?php _e( 'SHOP MORE ITEMS', 'boutique' ) ?></a>
        		</div>
        	</div>
        	<div class="box-content">
        		<div class="box-content-inner woocommerce">
                    <?php 
                    if ( $products->have_posts() ) :
                    $kt_woo_flash_style = kt_option('kt_woo_flash_style','flash1');
                    ?>
        			<ul class="box-product-list owl-carousel nav-style2 nav-center-outside" <?php echo _data_carousel($data_carousel); ?>>
        				<?php while ( $products->have_posts() ) : $products->the_post(); ?>
                            <?php
                            if( ! in_array( intval( $product_style ), array( 1, 2, 3, 4, 5 ) ) ){
                                $product_style = 1;
                            }
                            $item_class = 'product-item style'.$product_style . " " . $kt_woo_flash_style;
                            $template = 'style-'.$product_style;
                            ?>
                            <li <?php post_class($item_class)?>>
                                <?php wc_get_template_part( 'content-product', $template ); ?>
            				</li>
                        <?php endwhile; ?>
        			</ul>
                    <?php else:?>
                        <p><?php _e('No product');?></p>
                    <?php endif;?>
        		</div>
        	</div>
        </div>
        <?php
		woocommerce_reset_loop();
		wp_reset_postdata();
        $result = ob_get_clean();
        return $result;
    }
}