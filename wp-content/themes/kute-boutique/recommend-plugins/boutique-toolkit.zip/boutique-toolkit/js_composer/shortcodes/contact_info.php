<?php

// Exit if accessed directly
if ( ! defined('ABSPATH')) exit;

vc_map( array(
    "name" => __( "Contact Info", 'boutique'),
    "base" => "kt_info",
    "category" => __('Kute Theme', 'boutique' ),
    "description" => __( 'Display address and phone number', 'boutique' ),
    "params" => array(
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Style', 'boutique' ),
            'param_name'  => 'style',
            'admin_label' => true,
            'group'       => __( 'Style', 'boutique' ),
            'value'       => array(
                'Style 1' => 'style_1',
                'Style 2' => 'style_2'
            )  
        ),
        array(
            'type'        => 'textfield',
            'heading'     => __( 'Address', 'boutique' ),
            'param_name'  => 'address',
            'admin_label' => true,
            'group'       => __( 'Address', 'boutique' ),
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Phone Number", 'boutique' ),
            "param_name"  => "phone_number",
            "admin_label" => true,
            'group'       => __( 'Phone Number', 'boutique' ),
        ),
        array(
            "type"        => "textfield",
            "heading"     => __("Icon font awesome", 'boutique'),
            "param_name"  => "icon_fa",
            "admin_label" => true,
            "value"       => "phone",  
            'description' => __( 'It shows the image of banner', 'boutique' ),
            'group'       => __( 'Phone Number', 'boutique' ),
            "dependency"  => array("element" => "style", "value" => array( 'style_1' ))
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Email", 'boutique' ),
            "param_name"  => "email",
            "admin_label" => true,
            "group"       => __( 'Email', 'boutique' ),
            "dependency"  => array("element" => "style", "value" => array( 'style_2' ))
        ),
        array(
            "type" => "textfield",
            "heading" => __( "Extra class name", "js_composer" ),
            "param_name" => "el_class",
            "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
            'admin_label' => false,
            'group' => __( 'Design options', 'boutique' ),
        ),
        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'boutique' ),
            'param_name' => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group' => __( 'Design options', 'boutique' ),
            'admin_label' => false,
        ),
    ),
));

class WPBakeryShortCode_Kt_Info extends WPBakeryShortCode {
    
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'kt_info', $atts ) : $atts;
        $atts = shortcode_atts( array(
            'style'            => 'style_1',      
            'address'          => '',
            'phone_number'     => '',
            'icon_fa'          => '',
            'email'            => '', 
            'el_class'         => '',
            'css'              => ''
        ), $atts );
        extract($atts);
        $elementClass = array(
            'base' => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' ', $this->settings['base'], $atts ),
            'extra' => $this->getExtraClass( $el_class ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        
        ob_start(); ?>
        <div class="contact-info <?php echo esc_attr( $elementClass ); ?>">
            <div class="content <?php echo esc_attr( $style ); ?>">
                <?php if( $style === 'style_1' ) : ?>
                	<?php if( $address ) : ?><p class="address"><?php echo esc_html( $address ); ?></p><?php endif; ?>
                	<?php if( $phone_number ) : ?><p class="phone"><i class="fa fa-<?php echo ( isset( $icon_fa ) ) ? esc_html( $icon_fa ) : "phone"; ?>"></i><?php echo esc_html( $phone_number ); ?></p><?php endif; ?>
                    <?php if( $email ):  ?><p class="email"><?php echo esc_html( $email ); ?></p><?php endif; ?>
                <?php else : ?>
                    <?php if( $address ): ?><p class="address"><strong><?php _e( "ADDRESS", "boutique" ); ?></strong> <span><?php echo esc_html( $address ); ?></span></p><?php endif; ?>
					<?php if( $phone_number ): ?><p><strong><?php _e( "Call US NOW ", "boutique" ); ?></strong> <span> <?php echo esc_html( $phone_number ); ?></span></p><?php endif; ?>
					<?php if( $email ):  ?><p class="mail"><strong><?php _e( "EMAIL", "boutique" ); ?> </strong> <span><?php echo esc_html( $email ); ?></span></p><?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}