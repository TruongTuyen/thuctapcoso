<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

vc_map( array(
	'name' => __( 'KT Tabs', 'js_composer' ),
	'base' => 'kt_tabs',
	'icon' => 'icon-wpb-ui-tab-content',
	'is_container' => true,
	'show_settings_on_create' => false,
	'as_parent' => array(
		'only' => 'vc_tta_section',
	),
	"category"    => __('Kute Theme', 'kutetheme' ),
	'description' => __( 'Tabbed content', 'js_composer' ),
	'params' => array(
		array(
			'type' => 'dropdown',
			'param_name' => 'style',
			'value' => array(
                __( 'Default', 'js_composer' )   => '',
			),
			'heading'     => __( 'Tab display style', 'js_composer' ),
			'description' => __( 'Select tabs display style.', 'js_composer' ),
		),
		array(
			'type' => 'dropdown',
			'param_name' => 'tab_position',
			'value' => array(
				__( 'Top', 'js_composer' ) => 'top',
				__( 'Bottom', 'js_composer' ) => 'bottom',
			),
			'heading' => __( 'Position', 'js_composer' ),
			'description' => __( 'Select tabs navigation position.', 'js_composer' ),
		),
		array(
            "type"        => "kt_animate",
            "heading"     => __("Tabs animate", 'boutique'),
            "param_name"  => "tab_animate",
            "value"       => "",
            'admin_label' => false,
        ),
		array(
			'type' => 'textfield',
			'param_name' => 'active_section',
			'heading' => __( 'Active section', 'js_composer' ),
			'value' => 1,
			'description' => __( 'Enter active section number (Note: to have all sections closed on initial load enter non-existing number).', 'js_composer' ),
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'js_composer' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'js_composer' ),
			'param_name' => 'css',
			'group' => __( 'Design Options', 'js_composer' ),
		),
	),
	'js_view' => 'VcBackendTtaTabsView',
	'custom_markup' => '
<div class="vc_tta-container" data-vc-action="collapse">
	<div class="kt-tabs vc_general vc_tta vc_tta-tabs vc_tta-color-backend-tabs-white vc_tta-style-flat vc_tta-shape-rounded vc_tta-spacing-1 vc_tta-tabs-position-top vc_tta-controls-align-left">
		<div class="vc_tta-tabs-container">'
           . '<ul class="vc_tta-tabs-list">'
           . '<li class="vc_tta-tab" data-vc-tab data-vc-target-model-id="{{ model_id }}" data-element_type="vc_tta_section"><a href="javascript:;" data-vc-tabs data-vc-container=".vc_tta" data-vc-target="[data-model-id=\'{{ model_id }}\']" data-vc-target-model-id="{{ model_id }}"><span class="vc_tta-title-text">{{ section_title }}</span></a></li>'
           . '</ul>
		</div>
		<div class="vc_tta-panels vc_clearfix {{container-class}}">
		  {{ content }}
		</div>
	</div>
</div>',
	'default_content' => '
[vc_tta_section title="' . sprintf( '%s %d', __( 'Tab', 'js_composer' ), 1 ) . '"][/vc_tta_section]
[vc_tta_section title="' . sprintf( '%s %d', __( 'Tab', 'js_composer' ), 2 ) . '"][/vc_tta_section]
	',
	'admin_enqueue_js' => array(
		vc_asset_url( 'lib/vc_tabs/vc-tabs.min.js' ),
	),
) );

VcShortcodeAutoloader::getInstance()->includeClass( 'WPBakeryShortCode_VC_Tta_Accordion' );

class WPBakeryShortCode_KT_Tabs extends WPBakeryShortCode_VC_Tta_Accordion {
    public $layout = 'tabs';

	public function enqueueTtaScript() {
		wp_register_script( 'vc_tabs_script', vc_asset_url( 'lib/vc_tabs/vc-tabs.min.js' ), array( 'vc_accordion_script' ), WPB_VC_VERSION, true );
		parent::enqueueTtaScript();
		wp_enqueue_script( 'vc_tabs_script' );
	}

	public function getWrapperAttributes() {
		$attributes = array(); 
		$attributes[] = 'class="kt-tabs"';
		$attributes[] = 'data-vc-action="collapse"';
		return implode( ' ', $attributes );
	}

	public function getTtaGeneralClasses() {
		
		$classes ="";
		$classes .= ' kt-inner-tabs';
		return $classes;
	}


	/**
	 * @param $atts
	 * @param $content
	 *
	 * @return string|null
	 */
	public function getParamTabsListTop( $atts, $content ) {

		if ( empty( $atts['tab_position'] ) || 'top' !== $atts['tab_position'] ) {
			return null;
		}
		return $this->getParamTabsList( $atts, $content );
	}

	/**
	 * @param $atts
	 * @param $content
	 *
	 * @return string|null
	 */
	public function getParamTabsListBottom( $atts, $content ) {
		if ( empty( $atts['tab_position'] ) || 'bottom' !== $atts['tab_position'] ) {
			return null;
		}

		return $this->getParamTabsList( $atts, $content );
	}

	/**
	 * Pagination is on top only if tabs are at bottom
	 *
	 * @param $atts
	 * @param $content
	 *
	 * @return string|null
	 */
	public function getParamPaginationTop( $atts, $content ) {
		if ( empty( $atts['tab_position'] ) || 'bottom' !== $atts['tab_position'] ) {
			return null;
		}

		return $this->getParamPaginationList( $atts, $content );
	}

	/**
	 * @param $atts
	 * @param $content
	 *
	 * @return string
	 */
	public function getParamTabsList( $atts, $content ) {
		$class_tabs = array('vc_tta-tabs-list kt-tabs-list');
		$tab_attr = '';
		if( $atts['tab_animate'] && $atts['tab_animate']!=""){
			$class_tabs[] = 'kt-tabs-animate';
			$tab_attr = 'data-animate="'.$atts['tab_animate'].'"';
		}

		$isPageEditabe = vc_is_page_editable();
		$html = array();
		$html[] = '<ul class="'.implode(' ', $class_tabs ).'" >';
		if ( ! $isPageEditabe ) {
			$strict_bounds = ( 'vc_tta_tabs' === $this->shortcode );
			$active_section = $this->getActiveSection( $atts, $strict_bounds );

			foreach ( WPBakeryShortCode_VC_Tta_Section::$section_info as $nth => $section ) {
				$classes = array( 'vc_tta-tab', 'kt-tab' );
				if ( ( $nth + 1 ) === $active_section ) {
					$classes[] = $this->activeClass;
				}
				$title = $section['title'];

				$a_html = '<a href="#' . $section['tab_id'] . '" data-vc-tabs data-vc-container=".vc_tta" '.$tab_attr.'>' . $title . '</a>';
				$html[] = '<li class="' . implode( ' ', $classes ) . '" data-vc-tab>' . $a_html . '</li>';
			}
		}
		$html[] = '</ul>';

		return implode( '', apply_filters( 'vc-tta-get-params-tabs-list', $html, $atts, $content, $this ) );
	}
}
