<?php

// Exit if accessed directly
if ( ! defined('ABSPATH')) exit;

vc_map( array(
    "name" => __( "Title", 'boutique'),
    "base" => "kt_title",
    "category" => __('Kute Theme', 'boutique' ),
    "description" => __( 'Display a title', 'boutique' ),
    "params" => array(
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Style', 'boutique' ),
            'param_name'  => 'style',
            'admin_label' => true,
            'value'       => array(
                __( 'Default', 'boutique' ) => 'style-default',
                __( 'Style 1', 'boutique' ) => 'style-1',
                __( 'Style 2', 'boutique' ) => 'style-2',
                __( 'Style 3', 'boutique' ) => 'style-3',
        	)
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Title", 'boutique' ),
            "param_name"  => "title",
            "admin_label" => true
        ),
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Text align', 'boutique' ),
            'param_name'  => 'text_align',
            'admin_label' => true,
            'value'       => array(
                __( 'Left', 'boutique' ) => 'text-left',
                __( 'Center', 'boutique' ) => 'text-center',
                __( 'Right', 'boutique' ) => 'text-right',
            )
        ),
        array(
            "type"       => "dropdown",
            "heading"    => __("Heading", 'boutique'),
            "param_name" => "heading",
            "value"      => array(
                __('Heading 1', 'boutique') => 'h1',
                __('Heading 2', 'boutique') => 'h2',
                __('Heading 3', 'boutique') => 'h3',
                __('Heading 4', 'boutique') => 'h4',
                __('Heading 5', 'boutique') => 'h5',
                __('Heading 6', 'boutique') => 'h6',
                __('Span'     , 'boutique') => 'span',
                __('Paragraph', 'boutique') => 'p',
        	),
            'std'         => 'h3',
            "description" => __("Select how to sort retrieved posts.", 'boutique' ),
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Icon font awesome", 'boutique' ),
            "param_name"  => "icon_fa",
            "admin_label" => false
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "SubTitle", 'boutique' ),
            "param_name"  => "sub_title",
            "admin_label" => true,
            "dependency"  => array("element" => "style", "value" => array( 'style-default', 'style-1', 'style-2' ))
        ),
        array(
            "type"        => "attach_image",
            "heading"     => __("Banner Image", 'boutique'),
            "param_name"  => "banner_image",
            "admin_label" => true,
            'description' => __( 'It shows the image of banner', 'boutique' ),
            "dependency"  => array("element" => "style", "value" => array( 'style-1', 'style-2' ))
        ),
        array(
            "type"        => "textfield",
            "heading"     => __("Link", 'boutique'),
            "param_name"  => "link",
            "admin_label" => false,
            'description' => __( 'It shows the link.', 'boutique' ),
        ),
        array(
            "type" => "textfield",
            "heading" => __( "Extra class name", "js_composer" ),
            "param_name" => "el_class",
            "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
            'admin_label' => false,
        ),
        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'boutique' ),
            'param_name' => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group' => __( 'Design options', 'boutique' ),
            'admin_label' => false,
        ),
    ),
));

class WPBakeryShortCode_Kt_Title extends WPBakeryShortCode {
    
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'kt_title', $atts ) : $atts;
        $atts = shortcode_atts( array(
            'style'            => 'style-default',
            
            'title'            => '',
            'icon_fa'          => '',
            'sub_title'        => '',
            'text_align'       =>'text_center',
            'heading'          => 'h3',
            'banner_image'     => '',
            'link'             => '#',
            'el_class'         => '',
            'css'              => ''
        ), $atts );
        extract($atts);
        $elementClass = array(
            'base' => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' ', $this->settings['base'], $atts ),
            'extra' => $this->getExtraClass( $el_class ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        
        $banner_url = "";
        if( $banner_image ) {
            $banner     = wp_get_attachment_image_src( $banner_image , 'full' );  
            $banner_url =  is_array($banner) ? esc_url($banner[0]) : ''; 
        }
        ob_start();
        if( $style == 'style-1' ):?>
            <div class="section-title style2 <?php echo esc_attr($text_align)?> <?php echo esc_attr( $elementClass ); ?>" <?php if( $banner_url ): ?> style="background-image: url('<?php echo esc_url( $banner_url ); ?>');" <?php endif; ?>>
                <?php if( $sub_title ): ?>
                    <span class="sub-title"><?php echo esc_html( $sub_title ) ; ?></span>
                <?php endif; ?>
                <?php if( $title ): ?>
                    <a href="<?php echo esc_url( $link ) ?>">
                        <<?php echo esc_attr( $heading ) ?> class="title <?php if( $icon_fa ): ?> <?php echo esc_attr( $icon_fa ) ?> <?php endif; ?>"> <?php if( $icon_fa ): ?> <i class="fa fa-<?php echo esc_attr( $icon_fa ) ?>"></i> <?php endif; ?> <?php echo esc_html( $title ) ; ?> </<?php echo esc_attr( $heading ) ?>>
                    </a>
                <?php endif; ?>
    		</div>
        <?php elseif( $style == 'style-2' ) : ?>   
             <div class="sc-title style2 text-center <?php echo esc_attr( $elementClass ); ?>" <?php if( $banner_url ): ?> style="background: url('<?php echo esc_url( $banner_url ); ?>') no-repeat bottom center; padding-bottom:7px;" <?php endif; ?> >
                 <?php if( $sub_title ): ?>
    				<p class="text-primary PlayfairDisplay"><?php echo esc_html( $sub_title ); ?></p>
                 <?php endif; ?>   
                 <?php if( $title ): ?>
                    <a href="<?php echo esc_url( $link ) ?>">
                        <<?php echo esc_attr( $heading ) ?> class="widget-title <?php if( $icon_fa ): ?> <?php echo esc_attr( $icon_fa ) ?> <?php endif; ?>"> <?php if( $icon_fa ): ?> <i class="fa fa-<?php echo esc_attr( $icon_fa ) ?>"></i> <?php endif; ?>  <?php echo esc_html( $title ) ; ?> </<?php echo esc_attr( $heading ) ?>>
                    </a>
                 <?php endif; ?>   
			</div>
        <?php elseif( $style == 'style-3' ) : ?>
            <<?php echo esc_attr( $heading ) ?> class="sc-title style-3 <?php echo esc_attr( $elementClass ); ?> <?php if( $icon_fa ): ?> <?php echo esc_attr( $icon_fa ) ?> <?php endif; ?>"><?php if( $icon_fa ): ?><i class="fa fa-<?php echo esc_attr( $icon_fa ) ?>"></i> <?php endif; ?><?php echo esc_html( $title ) ; ?></<?php echo esc_attr( $heading ) ?>>
        <?php else: ?>
            <div class="section-title <?php echo esc_attr($text_align)?> heading <?php echo esc_attr( $elementClass ) ?>">
                <a href="<?php echo esc_url( $link ) ?>">
        		  <<?php echo esc_attr( $heading ) ?> <?php if( $icon_fa ): ?> class="<?php echo esc_attr( $icon_fa ) ?>" <?php endif; ?>> <?php if( $icon_fa ): ?> <i class="fa fa-<?php echo esc_attr( $icon_fa ) ?>"></i> <?php endif; ?>  <?php echo esc_html( $title ) ?></<?php echo esc_attr( $heading ) ?>>
                </a>
                <?php if( $sub_title ) : ?>
        		  <span class="sub-title"><?php echo esc_html( $sub_title ) ?></span>
                <?php endif; ?>
        	</div>
        <?php endif;
        return ob_get_clean();
    }
}