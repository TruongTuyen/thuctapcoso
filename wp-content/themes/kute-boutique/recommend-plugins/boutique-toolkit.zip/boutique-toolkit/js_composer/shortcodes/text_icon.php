<?php

// Exit if accessed directly
if ( ! defined('ABSPATH')) exit;

vc_map( array(
    "name" => __( "Text Icon", 'boutique'),
    "base" => "kt_text_icon",
    "category" => __('Kute Theme', 'boutique' ),
    "description" => __( 'Display text with icon', 'boutique' ),
    "params" => array(
        array(
            "type"        => "textfield",
            "heading"     => __( "Title", 'boutique' ),
            "param_name"  => "title",
            "admin_label" => true
        ),
        array(
            "type"        => "dropdown",
            "heading"     => __( "Heading", 'boutique' ),
            "param_name"  => "html_heading",
            "admin_label" => true,
            "value"       => array(
                __( 'h1', 'boutique' )     => 'h1',
                __( 'h2', 'boutique' )     => 'h2',
                __( 'h3', 'boutique' )     => 'h3',
                __( 'h4', 'boutique' )     => 'h4',
                __( 'h5', 'boutique' )     => 'h5',
                __( 'h6', 'boutique' )     => 'h6',
            ),
            "std"        => "h4"    
        ),
         
        array(
            "type"       => "textarea",
            "heading"    => __("Text", 'boutique'),
            "param_name" => "text",
            "admin_label"=> false
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __( "Font size for text", 'boutique' ),
            "param_name"  => "text_font_size",
            "admin_label" => false,
            "suffix"      => __("px", 'boutique'),
        ),
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Icon', 'boutique' ),
            'param_name'  => 'icon',
            'admin_label' => true,
            'value'       => array(
                __( 'Using Image', 'boutique' ) => 'image',
                __( 'Using Font Awesome', 'boutique' )  => 'font',
        	)
        ),
        array(
            "type"        => "attach_image",
            "heading"     => __("Image", 'boutique'),
            "param_name"  => "icon_image",
            "admin_label" => true,
            'description' => __( 'Choose an image which display as an icon ( Size: 49x49 px)', 'boutique' ),
            "dependency"  => array( "element" => "icon", "value" => array( 'image' ) )
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Icon font awesome", "boutique" ),
            "param_name"  => "icon_font_awesome",
            "admin_label" => "false",
            "description" => __( "Using font awesome, views more icon at: <a href=\"https://fortawesome.github.io/Font-Awesome/icons/\" target=\"_blank\">https://fortawesome.github.io/Font-Awesome/icons/</a>", "boutique" ),
            "dependency"  => array( "element"=> "icon", "value" => array( "font") )   
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __("Font Awesome Icon Size", 'boutique'),
            "param_name"  => "font_icon_size",
            "suffix"      => __("px", 'boutique'),            
            "admin_label" => false,
            "dependency"  => array( "element" => "icon", "value" => array( 'font' ) )
        ),        
        array(
            "type"          => "textfield",
            "heading"       => __( "Extra class name", "js_composer" ),
            "param_name"    => "el_class",
            "description"   => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
            'admin_label'   => false,
            'group'         => __( 'Design options', 'boutique' ),
        ),
        array(
            'type'          => 'css_editor',
            'heading'       => __( 'Css', 'boutique' ),
            'param_name'    => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group'         => __( 'Design options', 'boutique' ),
            'admin_label'   => false,
        ),
    ),
));

class WPBakeryShortCode_Kt_Text_Icon extends WPBakeryShortCode {
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'kt_text_icon', $atts ) : $atts;
        $atts = shortcode_atts( array(
            'title'            => '',
            'html_heading'     => '', 
            'text'             => '', 
            'text_font_size'   => '', 
            'icon'             => 'image',
            'icon_font_awesome'=> '',
            'font_icon_size'   => '',
            'icon_image'       => '', 
            'el_class'         => '',
            'css'              => ''
        ), $atts );
        extract($atts);
        $elementClass = array(
            'base'              => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' ', $this->settings['base'], $atts ),
            'extra'             => $this->getExtraClass( $el_class ),
            'shortcode_custom'  => vc_shortcode_custom_css_class( $css, ' ' )
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        
        $banner_url = "";
        if( $icon_image ) {
            $banner     = wp_get_attachment_image_src( $icon_image , 'full' );  
            $banner_url = is_array( $banner ) ? esc_url( $banner[0] ) : ''; 
        }
        ob_start(); ?>
        <div class="element-icon <?php echo esc_attr( $elementClass ); ?>">
			<div class="icon">
                <?php if( $icon && $icon === 'image') : ?>
                    <?php if( $banner_url != '' ) : ?>
                        <img src="<?php echo esc_url( $banner_url ); ?>" alt="" />
                    <?php else : ?>
                        <img src="<?php echo KUTETHEME_PLUGIN_URL;  ?>assets/images/icons/icon-document.png" alt="" />
                    <?php endif; ?>
                <?php elseif( $icon && $icon === 'font' ) : ?>
                    <?php if( $icon_font_awesome ) : ?>    
                        <i class="fa fa-<?php echo esc_attr( $icon_font_awesome ); ?>" <?php if( $font_icon_size ){ echo 'style="font-size: '. esc_attr( $font_icon_size ) .'px;"'; } ?> ></i>
                    <?php else : ?>
                        <i class="fa fa-pencil" <?php if( $font_icon_size ){ echo 'style="font-size: '. esc_attr( $font_icon_size ) .'px;"'; } ?> ></i>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
			<div class="content">
				<<?php echo esc_attr( $html_heading ); ?> class="title"><?php if( $title ){ echo esc_html( $title ); }  ?></<?php echo esc_attr( $html_heading ); ?>>
			    <div class="text">
                    <p <?php if( $text_font_size ){ echo 'style="font-size: '. esc_attr( $text_font_size ) .'px"'; } ?>><?php if( $text ){ echo esc_html( $text ); } ?></p>
                </div>
			</div>
		</div>
<?php   return ob_get_clean();
    }
}