<?php
if( function_exists( 'vc_map' ) ){
    vc_map( array(
            'name' => __( 'Header', 'boutique' ),
			'base' => 'kt_header',
			"category"    => __('Kute Theme', 'boutique' ),
			'description' => __( 'The header is showed by your design in post type template', 'boutique' ),
			'params' => array(
				array(
					'type'      => 'kt_posts',
					'heading'   => __( 'Header', 'boutique' ),
					'post_type' => 'template',
					'param_name'  => 'id',
                    'admin_label' => true,
					'description' => __( 'Choose a header ', 'boutique' )
				),
                
                array(
                    "type"        => "textfield",
                    "heading"     => __( "Extra class name", "js_composer" ),
                    "param_name"  => "el_class",
                    "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
                    'admin_label' => false,
                    "dependency"  => array("element" => "carousel", "value" => array( 'enable' )),
                ),
                
            )
        )
    );
}
