<?php
/**
 * @author  AngelsIT
 * @package BOUTIQUE TOOLKIT
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
vc_map( array(
    "name"        => __( "Brands", 'boutique'),
    "base"        => "brand",
    "category"    => __('Kute Theme', 'boutique' ),
    "description" => __( "Display brand showcase", 'boutique'),
    "params"      => array(
        array(
            "type"        => "kt_taxonomy",
            "taxonomy"    => "product_brand",
            "class"       => "",
            "heading"     => __("Brands", 'boutique'),
            "param_name"  => "taxonomy",
            "value"       => '',
            'parent'      => 0,
            'multiple'    => true,
            'placeholder' => __('Choose categoy', 'boutique'),
            "description" => __("Note: Selected categories will be hide if it empty. Only selected categories will be displayed.", 'boutique'),
            'admin_label' => true
        ),
        array(
            "type"       => "dropdown",
            "heading"    => __("Hide Empty", 'boutique'),
            "param_name" => "hide_empty",
            "value"      => array(
        		__('Yes', 'boutique') => 1,
                __('No', 'boutique')  => 0,
        	),
            'std'         => 1,
            "description" => __( "Whether to not return empty", 'boutique' ),
            'admin_label' => true
        ),
        array(
            "type"       => "dropdown",
            "heading"    => __("Order by", 'boutique'),
            "param_name" => "orderby",
            "value"      => array(
        		__('None', 'boutique')     => 'none',
                __('ID', 'boutique')       => 'ID',
                __('Author', 'boutique')   => 'author',
                __('Name', 'boutique')     => 'name',
                __('Date', 'boutique')     => 'date',
                __('Modified', 'boutique') => 'modified',
                __('Rand', 'boutique')     => 'rand',
        	),
            'std'         => 'date',
            "description" => __("Select how to sort retrieved posts.",'boutique'),
            'admin_label' => true
        ),
        array(
            "type"       => "dropdown",
            "heading"    => __("Order", 'boutique'),
            "param_name" => "order",
            "value"      => array(
                __('ASC', 'boutique')  => 'ASC',
                __('DESC', 'boutique') => 'DESC'
        	),
            'std'         => 'DESC',
            "description" => __("Designates the ascending or descending order.",'boutique'),
            'admin_label' => true
        ),

        // Carousel
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'AutoPlay', 'boutique' ),
            'param_name'  => 'autoplay',
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false
		),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'Navigation', 'boutique' ),
            'param_name'  => 'navigation',
            'description' => __( "Show buton 'next' and 'prev' buttons.", 'boutique' ),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
		),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'Loop', 'boutique' ),
            'param_name'  => 'loop',
            'description' => __( "Inifnity loop. Duplicate last and first items to get loop illusion.", 'boutique' ),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
		),
        array(
            "type"        => "kt_number",
            "heading"     => __("Slide Speed", 'boutique'),
            "param_name"  => "slidespeed",
            "value"       => "250",
            "suffix"      => __("milliseconds", 'boutique'),
            "description" => __('Slide speed in milliseconds', 'boutique'),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
	  	),
        array(
            "type"        => "kt_number",
            "heading"     => __("Margin", 'boutique'),
            "param_name"  => "margin",
            "value"       => 100,
            "suffix"      => __("px", 'boutique'),
            "description" => __('Distance( or space) between 2 item', 'boutique'),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
	  	),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'yes',
                __( 'No', 'boutique' )  => 'no'
            ),
            'std'         => 1,
            'heading'     => __( 'Use Carousel Responsive', 'boutique' ),
            'param_name'  => 'use_responsive',
            'description' => __( "Try changing your browser width to see what happens with Items and Navigations", 'boutique' ),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
		),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on destop (Screen resolution of device >= 992px )", 'boutique'),
            "param_name"  => "items_destop",
            "value"       => "5",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The number of items on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
	  	),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on tablet (Screen resolution of device >=768px and < 992px )", 'boutique'),
            "param_name"  => "items_tablet",
            "value"       => "3",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The number of items on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
	  	),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on mobile (Screen resolution of device < 768px)", 'boutique'),
            "param_name"  => "items_mobile",
            "value"       => "2",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The numbers of item on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
	  	),
        array(
            'type'           => 'css_editor',
            'heading'        => __( 'Css', 'boutique' ),
            'param_name'     => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group'          => __( 'Design options', 'boutique' )
		),
        array(
            "type"        => "textfield",
            "heading"     => __( "Extra class name", 'boutique' ),
            "param_name"  => "el_class",
            "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
        )
    )
));
class WPBakeryShortCode_Brand extends WPBakeryShortCode {
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'brand', $atts ) : $atts;
                        
        $atts = shortcode_atts( array(
            'taxonomy'       => '',
            'hide_empty'     => 1,
            'orderby'        => 'date',
            'order'          => 'desc',
            
            //Carousel            
            'autoplay'       => 'false', 
            'navigation'     => 'false',
            'margin'         => 100,
            'slidespeed'     => 250,
            'loop'           => 'true',
            //Default
            'use_responsive' => 'yes',
            'items_destop'   => 5,
            'items_tablet'   => 3,
            'items_mobile'   => 2,
            
            'css'            => '',
            'css_animation'  => '',
            'el_class'       => '',
            
        ), $atts );
        extract($atts);
        
        $elementClass = array(
            'base'             => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'brand ', $this->settings['base'], $atts ),
            'extra'            => $this->getExtraClass( $el_class ),
            'css_animation'    => $this->getCSSAnimation( $css_animation ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        $data_carousel = array(
            "autoplay"           => $autoplay,
            "nav"                => $navigation,
            "margin"             => $margin,
            "slidespeed"         => $slidespeed,
            "theme"              => 'style-navigation-bottom',
            "autoheight"         => 'false',
            'dots'               => 'false',
            'loop'               => $loop,
            'autoplayTimeout'    => 1000,
            'autoplayHoverPause' => 'true'
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        ob_start();
        
        $args_term = array( 
            'hide_empty' => $hide_empty, 
            'orderby'    => $orderby, 
            'order'      => $order,
        );
        
        if( taxonomy_exists( 'product_brand' ) && $taxonomy ):
            $taxonomy = explode(",", $taxonomy);
           
            if( count( $taxonomy ) > 0 ){
                $args_term[ 'include' ] = $taxonomy;
            }
            
        endif;//if( $tax ):
        
		$terms = get_terms( 'product_brand', $args_term);
        //print_r($terms);
        $count_term = count( $terms ); ?>
        <?php if( ! is_wp_error($terms) && $count_term > 0 ) :
            if( $count_term <  $items_mobile ){
                $data_carousel['loop'] = 'false';
            }
            if( $use_responsive == 'yes' ):
                $arr = array( 
                    '0'   => array( 
                        "items" => $items_mobile
                    ), 
                    '768' => array( 
                        "items" => $items_tablet
                    ), 
                    '992' => array(
                        "items" => $items_destop
                    )
                );
                $data_responsive = json_encode($arr);
                $data_carousel["responsive"] = $data_responsive;
                
            else:
                $data_carousel['items'] = $items_destop;
            endif;// ?>
            <div class="section-brand-slide <?php echo esc_attr( $elementClass ) ?>">
        		<div class="brands-slide owl-carousel nav-center-center nav-style7" <?php echo _data_carousel($data_carousel); ?> >
        			<?php foreach($terms as $term): $term_link = get_term_link( $term ); ?>
                        <?php
                            $thumbnail_id = absint( get_woocommerce_term_meta( $term->term_id, 'thumbnail_id', true ) );
                    		if ( $thumbnail_id ) {
                    		  $image = wp_get_attachment_image( intval( $thumbnail_id ), 'full', 0, array( ) );
                    		} else {
                    			$image = "";
                    		}
                         ?>
                        <?php if( $image ): ?>
                            <a href="<?php echo esc_url( $term_link ) ?>">
                                <?php echo apply_filters( 'kt_brand_image_' . $term->slug, $image ) ?>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; ?>
        		</div>
        	</div>
            
                
            
        <?php endif;//if( ! is_wp_error($terms) && count( $terms ) > 0 ) : ?>
        <?php $result = ob_get_clean();
        return $result;
    }
}