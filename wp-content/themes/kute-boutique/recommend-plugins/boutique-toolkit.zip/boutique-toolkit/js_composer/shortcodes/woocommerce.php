<?php
/**
 * @author  AngelsIT
 * @package KUTE TOOLKIT
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$attributes_tax = wc_get_attribute_taxonomies();
$attributes = array();
foreach ( $attributes_tax as $attribute ) {
	$attributes[ $attribute->attribute_label ] = $attribute->attribute_name;
}
vc_map( array(
    "name"        => __( "Woocommerce", 'boutique'),
    "base"        => "kt_woocommerce",
    "category"    => __('Kute Theme', 'boutique' ),
    "description" => __( 'Multi purpose to show products of woocommerce', 'boutique' ),
    "params"      => array(
        array(
            'type'        => 'textfield',
            'heading'     => __( 'Title', 'boutique' ),
            'param_name'  => 'title',
            'description' => __( 'The title of shortcode', 'boutique' ),
            'admin_label' => true,
		),
        array(
            "type"        => "kt_taxonomy",
            "taxonomy"    => "product_cat",
            "class"       => "",
            "heading"     => __("Category", 'boutique'),
            "param_name"  => "taxonomy",
            "value"       => '',
            'parent'      => '',
            'multiple'    => true,
            'hide_empty'  => false,
            'admin_label' => true,
            'placeholder' => __('Choose category', 'boutique'),
            "description" => __("Note: If you want to narrow output, select category(s) above. Only selected categories will be displayed.", 'boutique')
        ),
        
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Template', 'boutique' ),
            'param_name'  => 'template',
            'admin_label' => false,
            'value'       => array(
                __( 'Grid product', 'boutique' ) => 'grid',
                __( 'Owl Carousel one row', 'boutique' ) => 'owlcarousel',
                __( 'Owl Carousel two row', 'boutique' ) => 'owlcarousel2',
        	),
        	'description' => __( 'Select template loop', 'boutique' )
        ),

        array(
           'type'        => 'dropdown',
            'heading'     => __( 'Target', 'boutique' ),
            'param_name'  => 'target',
            'admin_label' => true,
            'value'       => array(
                __( 'Best Selling Products', 'boutique' ) => 'best-selling',
                __( 'Top Rated Products', 'boutique' )    => 'top-rated',
                __( 'Recent Products', 'boutique' )       => 'recent-product',
                __( 'Product Category', 'boutique' )      => 'product-category',
                __( 'Products', 'boutique' )              => 'products',
                __( 'Featured Products', 'boutique' )     => 'featured_products',
                __( 'Attribute Products', 'boutique' )    => 'product_attribute',
            ),
            'description' => __( 'Choose the target to filter products', 'boutique' ),
        ),
		array(
			'type' => 'autocomplete',
			'heading' => __( 'Products', 'boutique' ),
			'param_name' => 'ids',
			'settings' => array(
				'multiple' => true,
				'sortable' => true,
				'unique_values' => true,
				// In UI show results except selected. NB! You should manually check values in backend
			),
			'save_always' => true,
			'description' => __( 'Enter List of Products', 'boutique' ),
            "dependency"  => array("element" => "target", "value" => array( 'products' )),
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Attribute', 'boutique' ),
			'param_name' => 'attribute',
			'value' => $attributes,
			'save_always' => true,
			'description' => __( 'List of product taxonomy attribute', 'boutique' ),
            "dependency"  => array("element" => "target", "value" => array( 'product_attribute' )),
		),
		array(
			'type' => 'checkbox',
			'heading' => __( 'Filter', 'boutique' ),
			'param_name' => 'filter',
			'value' => array( 'empty' => 'empty' ),
			'save_always' => true,
			'description' => __( 'Taxonomy values', 'boutique' ),
			"dependency"  => array("element" => "target", "value" => array( 'product_attribute' )),
		),
        array(
            "type"       => "dropdown",
            "heading"    => __("Order by", 'boutique'),
            "param_name" => "orderby",
            "value"      => array(
    			'',
    			__( 'Date', 'boutique' )      => 'date',
    			__( 'ID', 'boutique' )        => 'ID',
    			__( 'Author', 'boutique' )    => 'author',
    			__( 'Title', 'boutique' )     => 'title',
    			__( 'Modified', 'boutique' )  => 'modified',
    			__( 'Random', 'boutique' )    => 'rand',
    			__( 'Comment count', 'boutique' ) => 'comment_count',
    			__( 'Menu order', 'boutique' )    => 'menu_order',
    		),
            'std'         => 'date',
            "description" => __("Select how to sort retrieved posts.",'boutique'),
            "dependency"  => array("element" => "target", "value" => array( 'top-rated', 'products', 'featured_products' )),
        ),
        array(
            "type"       => "dropdown",
            "heading"    => __("Order", 'boutique'),
            "param_name" => "order",
            "value"      => array(
                __('ASC', 'boutique')  => 'ASC',
                __('DESC', 'boutique') => 'DESC'
        	),
            'std'         => 'DESC',
            "description" => __("Designates the ascending or descending order.",'boutique'),
            "dependency"  => array("element" => "target", "value" => array( 'top-rated', 'products', 'featured_products' )),
        ),
        array(
            'type'        => 'textfield',
            'heading'     => __( 'Per page', 'boutique' ),
            'value'       => 6,
            'param_name'  => 'per_page',
            'description' => __( 'The "per_page" shortcode determines how many products to show on the page', 'boutique' ),
            'admin_label' => true,
		),
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Columns on Destop (Screen resolution of device >= 992px and < 1200px )', 'boutique' ),
            'value'       => array(
                __( '1 Column - 1/12', 'boutique' )   => '1',
                __( '2 Columns - 1/6', 'boutique' )   => '2',
                __( '3 Columns - 1/4', 'boutique' )   => '3',
                __( '4 Columns - 1/3', 'boutique' )   => '4',
                __( '5 Columns - 5/12', 'boutique' )  => '5',
                __( '6 Columns - 1/2', 'boutique' )   => '6',
                __( '7 Columns - 7/12', 'boutique' )  => '7',
                __( '8 Columns - 2/3', 'boutique' )   => '8',
                __( '9 Columns - 3/4', 'boutique' )   => '9',
                __( '10 Columns - 5/6', 'boutique' )  => '10',
                __( '11 Columns - 11/12', 'boutique') => '11',
                __( '12 Columns - 1/1', 'boutique' )  => '12',
            ),
            'default'     =>'3',
            'param_name'  => 'columns_destop',
            'description' => __( 'The columns attribute controls how many columns on destop wide the products should be before wrapping.', 'boutique' ),
            'admin_label' => false,
            'group'       => __( 'Responsive settings', 'boutique' ),
            "dependency"  => array("element" => "template", "value" => array( 'grid' )),
		),
        
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Columns on Tablet (Screen resolution of device >=768px and < 992px )', 'boutique' ),
            'value'       => array(
                __( '1 Column - 1/12', 'boutique' )   => '1',
                __( '2 Columns - 1/6', 'boutique' )   => '2',
                __( '3 Columns - 1/4', 'boutique' )   => '3',
                __( '4 Columns - 1/3', 'boutique' )   => '4',
                __( '5 Columns  - 5/12', 'boutique' ) => '5',
                __( '6 Columns - 1/2', 'boutique' )   => '6',
                __( '7 Columns  - 7/12', 'boutique' ) => '7',
                __( '8 Columns - 2/3', 'boutique' )   => '8',
                __( '9 Columns - 3/4', 'boutique' )   => '9',
                __( '10 Columns - 5/6', 'boutique' )  => '10',
                __( '11 Columns - 11/12', 'boutique') => '11',
                __( '12 Columns - 1/1', 'boutique' )  => '12',
            ),
            'default'     =>'6',
            'param_name'  => 'columns_tablet',
            'description' => __( 'The columns attribute controls how many columns on tablet wide the products should be before wrapping.', 'boutique' ),
            'admin_label' => false,
            'group'       => __( 'Responsive settings', 'boutique' ),
            "dependency"  => array("element" => "template", "value" => array( 'grid' )),
		),
        
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Columns on Mobile (Screen resolution of device < 768px )', 'boutique' ),
            'value'       => array(
                __( '1 Column - 1/12', 'boutique' )   => '1',
                __( '2 Columns - 1/6', 'boutique' )   => '2',
                __( '3 Columns - 1/4', 'boutique' )   => '3',
                __( '4 Columns - 1/3', 'boutique' )   => '4',
                __( '5 Columns  - 5/12', 'boutique' ) => '5',
                __( '6 Columns - 1/2', 'boutique' )   => '6',
                __( '7 Columns  - 7/12', 'boutique' ) => '7',
                __( '8 Columns - 2/3', 'boutique' )   => '8',
                __( '9 Columns - 3/4', 'boutique' )   => '9',
                __( '10 Columns - 5/6', 'boutique' )  => '10',
                __( '11 Columns - 11/12', 'boutique') => '11',
                __( '12 Columns - 1/1', 'boutique' )  => '12',
            ),
            'default'     => '12',
            'param_name'  => 'columns_mobile',
            'description' => __( 'The columns attribute controls how many columns on mobile wide the products should be before wrapping.', 'boutique' ),
            'admin_label' => false,
            'group'       => __( 'Responsive settings', 'boutique' ),
            "dependency"  => array("element" => "template", "value" => array( 'grid' )),
		),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'yes',
                __( 'No', 'boutique' )  => 'no'
            ),
            'std'         => 'no',
            'heading'     => __( 'Enable Owl Carousel on mobile', 'boutique' ),
            'param_name'  => 'enable_owl_mobile',
            'group'       => __( 'Responsive settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "template", "value" => array( 'grid' )),
            'description' => __( 'Use setting colums on mobile', 'boutique' ),
        ),
        // Carousel
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'AutoPlay', 'boutique' ),
            'param_name'  => 'autoplay',
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "template", "value" => array( 'owlcarousel','owlcarousel2' )),
		),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'No', 'boutique' )  => 'false',
                __( 'Yes', 'boutique' ) => 'true'
            ),
            'std'         => 'false',
            'heading'     => __( 'Navigation', 'boutique' ),
            'param_name'  => 'navigation',
            'description' => __( "Show buton 'next' and 'prev' buttons.", 'boutique' ),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "template", "value" => array( 'owlcarousel','owlcarousel2' )),
		),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Navigation Style 1', 'boutique' )  => 'nav-style1',
                __( 'Navigation Style 2', 'boutique' )  => 'nav-style2',
                __( 'Navigation Style 3', 'boutique' )  => 'nav-style3',
                __( 'Navigation Style 4', 'boutique' )  => 'nav-style4',
                __( 'Navigation Style 5', 'boutique' )  => 'nav-style5',
                __( 'Navigation Style 6', 'boutique' )  => 'nav-style6',
                __( 'Navigation Style 7', 'boutique' )  => 'nav-style7',
            ),
            'std'         => 'nav-style1',
            'heading'     => __( 'Navigation', 'boutique' ),
            'param_name'  => 'navigation_style',
            'description' => __( "Buton 'next' and 'prev' buttons style.", 'boutique' ),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "navigation", "value" => array( 'true' )),
        ),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Top left', 'boutique' )       => 'nav-top-left',
                __( 'Top right', 'boutique' )      => 'nav-top-right',
                __( 'Center inline', 'boutique' )  => 'nav-center-center',
                __( 'Center outline', 'boutique' ) => 'nav-center-outside',
            ),
            'std'         => 'nav-style1',
            'heading'     => __( 'Navigation position', 'boutique' ),
            'param_name'  => 'navigation_postion',
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "navigation", "value" => array( 'true' )),
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __("Navigation margin", 'boutique'),
            "param_name"  => "navigation_margin",
            "value"       => "",
            "suffix"      => __("px", 'boutique'),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "navigation_postion", "value" => array( 'nav-top-left','nav-top-right' )),
        ),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'Loop', 'boutique' ),
            'param_name'  => 'loop',
            'description' => __( "Inifnity loop. Duplicate last and first items to get loop illusion.", 'boutique' ),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "template", "value" => array( 'owlcarousel','owlcarousel2' )),
		),
        array(
            "type"        => "kt_number",
            "heading"     => __("Slide Speed", 'boutique'),
            "param_name"  => "slidespeed",
            "value"       => "200",
            "suffix"      => __("milliseconds", 'boutique'),
            "description" => __('Slide speed in milliseconds', 'boutique'),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "template", "value" => array( 'owlcarousel','owlcarousel2' )),
	  	),
        array(
            "type"        => "kt_number",
            "heading"     => __("Margin", 'boutique'),
            "param_name"  => "margin",
            "value"       => "30",
            "suffix"      => __("px", 'boutique'),
            "description" => __('Distance( or space) between 2 item', 'boutique'),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "template", "value" => array( 'owlcarousel','owlcarousel2' )),
	  	),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 1,
                __( 'No', 'boutique' )  => 0
            ),
            'std'         => 1,
            'heading'     => __( 'Use Carousel Responsive', 'boutique' ),
            'param_name'  => 'use_responsive',
            'description' => __( "Try changing your browser width to see what happens with Items and Navigations", 'boutique' ),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "template", "value" => array( 'owlcarousel','owlcarousel2' )),
		),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on destop (Screen resolution of device >= 992px )", 'boutique'),
            "param_name"  => "items_destop",
            "value"       => "4",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The number of items on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "use_responsive", "value" => array( '1' )),
	  	),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on tablet (Screen resolution of device >=768px and < 992px )", 'boutique'),
            "param_name"  => "items_tablet",
            "value"       => "2",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The number of items on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "use_responsive", "value" => array( '1' )),
	  	),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on mobile (Screen resolution of device < 768px)", 'boutique'),
            "param_name"  => "items_mobile",
            "value"       => "1",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The numbers of item on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array("element" => "use_responsive", "value" => array( '1' )),
	  	),
        array(
            "type"       => "dropdown",
            "heading"    => __("Product style display", 'boutique'),
            "param_name" => "product_style_display",
            "value"      => array(
                __('Style 1', 'boutique')  => '1',
                __('Style 2', 'boutique')  => '2',
                __('Style 3', 'boutique')  => '3',
                __('Style 4', 'boutique')  => '4',
                __('Style 5', 'boutique')  => '5',
            ),
            'std'         => '1',
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Extra class name", "js_composer" ),
            "param_name"  => "el_class",
            "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
            'admin_label' => false,
        ),
        
        array(
            'type'           => 'css_editor',
            'heading'        => __( 'Css', 'boutique' ),
            'param_name'     => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group'          => __( 'Design options', 'boutique' ),
            'admin_label'    => false,
		),
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'CSS Animation', 'boutique' ),
            'param_name'  => 'css_animation',
            'admin_label' => false,
            'value'       => array(
                __( 'No', 'boutique' )                 => '',
                __( 'Top to bottom', 'boutique' )      => 'top-to-bottom',
                __( 'Bottom to top', 'boutique' )      => 'bottom-to-top',
                __( 'Left to right', 'boutique' )      => 'left-to-right',
                __( 'Right to left', 'boutique' )      => 'right-to-left',
                __( 'Appear from center', 'boutique' ) => "appear"
        	),
        	'description' => __( 'Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'boutique' )
        ),
    ),
));

class WPBakeryShortCode_KT_Woocommerce extends WPBakeryShortCode {
    
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'kt_woocommerce', $atts ) : $atts;
        $atts = shortcode_atts( array(
            'title'                 => '',
            'style_title'           => 'text-center',
            'taxonomy'              => '',
            'template'              => 'grid',
            'ids'                   => '',
            'skus'                  => '',
            'target'                => 'best-selling',
            'per_page'              => 6,
            
            'orderby'               => 'date',
            'order'                 => 'desc',
            'product_style_display' =>'1',
            
            //Carousel            
            'autoplay'              => 'false', 
            'navigation'            => 'false',
            'margin'                => 30,
            'slidespeed'            => 200,
            'nav'                   => 'true',
            'loop'                  => 'false',
            'navigation_postion'    =>'nav-center-center',
            'navigation_style'      =>'nav-style1',
            'navigation_margin'     =>'',
            
            'columns_destop'        => 3,
            'columns_tablet'        => 6,
            'columns_mobile'        => 12,
            'enable_owl_mobile'     =>'no',
            //Default
            'use_responsive'        => 1,
            'items_destop'          => 4,
            'items_tablet'          => 2,
            'items_mobile'          => 1,
            
            'css_animation'         => '',
            'el_class'              => '',
            'css'                   => '',   
            
        ), $atts );
        extract($atts);
        
        global $woocommerce_loop;
        
        $elementClass = array(
            'base'             => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'kt-woocommerce', $this->settings['base'], $atts ),
            'extra'            => $this->getExtraClass( $el_class ),
            'css_animation'    => $this->getCSSAnimation( $css_animation ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        
        $elementClass = apply_filters( 'kt_product_tab_class_container', $elementClass );
        
        $meta_query = WC()->query->get_meta_query();
        $query_args = array(
			'post_type'				=> 'product',
			'post_status'			=> 'publish',
			'ignore_sticky_posts'	=> 1,
			'posts_per_page' 		=> $per_page,
			'meta_query' 			=> $meta_query,
            'suppress_filter'       => true,
		);
        if( $taxonomy ){
            $query_args['tax_query'] = 
                array(
            		array(
            			'taxonomy' => 'product_cat',
            			'field'    => 'slug',
            			'terms'    => array_map( 'sanitize_title', explode( ',', $taxonomy ) 
                    )
            	)
            );
        }
        
        $data_carousel = array(
            "autoplay"           => $autoplay,
            "navigation"         => $navigation,
            "margin"             => $margin,
            "slidespeed"         => $slidespeed,
            "theme"              => 'style-navigation-bottom',
            "autoheight"         => 'false',
            'nav'                => $navigation,
            'dots'               => 'false',
            'loop'               => $loop,
            'autoplayTimeout'    => 1000,
            'autoplayHoverPause' => 'true'
        );
        
        switch( $target ):
            case 'best-selling' : 
                $query_args[ 'meta_key' ] = 'total_sales'; 
                $query_args[ 'orderby' ]  = 'meta_value_num';
                
                $return = self::product_loop( $query_args, $data_carousel, $atts, 'best_selling_products' );
                break;
            case 'top-rated' : 
                $query_args[ 'orderby' ] = $orderby;
                $query_args[ 'order' ]   = $order;
                
                add_filter( 'posts_clauses', array( __CLASS__, 'order_by_rating_post_clauses' ) );
                
                $return = self::product_loop( $query_args, $data_carousel, $atts, 'top_rated_products' );
                
                remove_filter( 'posts_clauses', array( __CLASS__, 'order_by_rating_post_clauses' ) );
                break;
            case 'product-category' : 
                $ordering_args = WC()->query->get_catalog_ordering_args( $atts['orderby'], $atts['order'] );
                
                $query_args[ 'orderby' ] = $ordering_args['orderby'];
                $query_args[ 'order' ]   = $ordering_args['order'];
                
                $return = self::product_loop( $query_args, $data_carousel, $atts, 'product_cat' );
                break;
            case 'products' : 
                $query_args[ 'orderby' ] = $orderby;
                $query_args[ 'order' ]   = $order;
                
                if ( ! empty( $ids ) ) {
        			$query_args['post__in'] = array_map( 'trim', explode( ',', $ids ) );
        		}
                if ( ! empty( $skus ) ) {
        			$query_args['meta_query'][] = array(
        				'key'     => '_sku',
        				'value'   => array_map( 'trim', explode( ',', $skus ) ),
        				'compare' => 'IN'
        			);
        		}
                $return = self::product_loop( $query_args, $data_carousel, $atts, 'recent_products' );
                break;
            case 'featured_products' : 
                $meta_query[] = array(
        			'key'   => '_featured',
        			'value' => 'yes'
        		);
                
                $query_args[ 'meta_query' ]   = $meta_query;
                
                $return = self::product_loop( $query_args, $data_carousel, $atts, 'featured_products' );
                break;
            case 'product_attribute' : 
                //'recent-product' 
                $query_args[ 'tax_query' ] =  array(
    				array(
    					'taxonomy' => strstr( $atts['attribute'], 'pa_' ) ? sanitize_title( $atts['attribute'] ) : 'pa_' . sanitize_title( $atts['attribute'] ),
    					'terms'    => array_map( 'sanitize_title', explode( ',', $atts['filter'] ) ),
    					'field'    => 'slug'
    				)
    			);
                $return = self::product_loop( $query_args, $data_carousel, $atts, 'product_attribute' );
                break;
            default :
                //'recent-product' 
                $query_args[ 'orderby' ] = $orderby;
                $query_args[ 'order' ]   = $order;
                
                if ( isset( $ordering_args['meta_key'] ) ) {
        			$query_args['meta_key'] = $ordering_args['meta_key'];
        		}
                                
                $return = self::product_loop( $query_args, $data_carousel, $atts, 'recent_products' );
                
                // Remove ordering query arguments
		        WC()->query->remove_ordering_args();
                break;
        endswitch; ?>
        <?php 
        return '<div class="kt-woocommerce-container ' . esc_attr( $elementClass ) . '">' . $return . '</div>';
    }
    
    /**
	 * Loop over found products
	 * @param  array $query_args
	 * @param  array $atts
	 * @param  string $loop_name
	 * @return string
	 */
	private static function product_loop( $query_args, $carousel, $atts, $loop_name ) {
		global $woocommerce_loop;

		$products = new WP_Query( apply_filters( 'woocommerce_shortcode_products_query', $query_args, $atts ) );

        $classes = array('product-item');
        $before_loop ="";
        $after_loop ="</ul>";
        // Setup owl
        if( $products->post_count <= 1 ){
            $carousel['loop'] = 'false';
        }
        $arr = array(
            '0' => array(
                "items" => $atts[ 'items_mobile' ]
            ), 
            '768' => array(
                "items" => $atts[ 'items_tablet' ]
            ), 
            '992' => array(
                "items" => $atts[ 'items_destop' ]
            )
        );
        $data_responsive = json_encode($arr);
        $carousel[ "responsive" ] = $data_responsive;

        // Set template
        $template = 'grid';
        if( $atts['template'] ){
            $template = $atts['template'];
        }
        if( $template == 'grid'){
            // Set columns
            $boostrap_columns_destop = round( 12 / $atts['columns_destop'] );

            $classes[] = 'col-md-'.$boostrap_columns_destop;
            
            $boostrap_columns_tablet = round( 12 / $atts['columns_tablet'] );
            $classes[] = 'col-sm-'.$boostrap_columns_tablet;

            $boostrap_columns_mobile = round( 12 / $atts['columns_mobile'] );

            $classes[] = 'col-xs-'.$boostrap_columns_mobile;

            $grid_class = array('product-list-grid');

            $grid_class[] = 'desktop-columns-'. $atts['columns_destop'] ;
            $grid_class[] = 'tablet-columns-'. $atts['columns_tablet'] ;
            $grid_class[] = 'mobile-columns-'. $atts['columns_mobile'] ;

            // Set owl on mobile
            $grid_attr = '';
            if( $atts['enable_owl_mobile'] && $atts['enable_owl_mobile'] == 'yes' ){
                $grid_class[] = 'owl-carousel-mobile nav-center-center nav-style7';
                $grid_attr = 'data-nav="true" data-dots="false" data-margin="10" data-items="'.$atts['columns_mobile'].'"';
                $classes[] = 'mobile-slide-item';
            }
            $before_loop = '<ul class="'.implode(' ', $grid_class ).'" '.$grid_attr.'>';

        }else{
            $owl_class = array('owl-carousel');
            if( !$atts['navigation_postion'] || $atts['navigation_postion'] == "" ){
                $navigation_postion = 'nav-center-center';
            }else{
                $navigation_postion = $atts['navigation_postion'];
            }
            if( !$atts['navigation_style'] || $atts['navigation_style'] == "" ){
                $navigation_style = 'nav-style1';
            }else{
                $navigation_style = $atts['navigation_style'];
            }
            $owl_class[] = $navigation_postion;
            $owl_class[] = $navigation_style;
            // navigation_margin
            if( $atts['navigation_margin'] && $atts['navigation_margin'] != "" ){
                $carousel['navigation_margin'] = $atts['navigation_margin'];
                $owl_class[] = 'owl-custom-nav-postion';
            }
            $before_loop = '<ul class="'.implode(' ', $owl_class ).'" '._data_carousel( $carousel ).'>';
        }

        // Set product display
        if( ! $atts['product_style_display'] || $atts['product_style_display'] == "" || ! in_array( intval( $atts['product_style_display'] ), array( 1, 2, 3, 4, 5 ) )){
            $product_style_display = 1;
        }else{
            $product_style_display = $atts['product_style_display'];
        }
        $kt_woo_flash_style = kt_option('kt_woo_flash_style','flash1');
        $classes[] = 'style'.$product_style_display;
        $classes[] = $kt_woo_flash_style;
		ob_start();
        if( $products->have_posts() ){
            $toal_product = $products->post_count;
            ?>
            <?php if( $atts['template'] == 'owlcarousel2'):?>
            <!-- Loop grid end owl 2 row-->
            <?php
            $i = 1;
            echo $before_loop;
            echo '<li class="owl-one-row">';
            while ( $products->have_posts() ){

                $products->the_post();
                ?>
                <div <?php post_class( $classes ); ?>>
                   <?php wc_get_template_part( 'content-product', 'style-'.$product_style_display ); ?>
                </div>
                <?php
                if( $i%2 == 0 && $i < $toal_product ){
                    echo '</li><li class="owl-one-row">';
                }
                $i++;
            }
            echo '</li>';
            echo $after_loop;
            ?>
            <!-- ./Loop grid end owl 2 row-->
            <?php else:?>
            <!-- Loop grid end owl 1 row-->
            <?php echo $before_loop;?>
            <?php while ( $products->have_posts() ) : $products->the_post(); ?>
                <li <?php post_class( $classes ); ?>>
                   <?php wc_get_template_part( 'content-product', 'style-'.$product_style_display ); ?>
                </li>
            <?php endwhile; // end of the loop. ?>
            <?php echo $after_loop; ?>
            <!-- ./Loop grid end owl 1 row-->
            <?php endif;?>
            <?php
        }else{
            _e('No Product','boutique');
        }

		woocommerce_reset_loop();
		wp_reset_postdata();

		return '<div class="woocommerce">' . ob_get_clean() . '</div>';
	}
    
    /**
	 * woocommerce_order_by_rating_post_clauses function.
	 *
	 * @param array $args
	 * @return array
	 */
	public static function order_by_rating_post_clauses( $args ) {
		global $wpdb;

		$args['where']   .= " AND $wpdb->commentmeta.meta_key = 'rating' ";
		$args['join']    .= "LEFT JOIN $wpdb->comments ON($wpdb->posts.ID               = $wpdb->comments.comment_post_ID) LEFT JOIN $wpdb->commentmeta ON($wpdb->comments.comment_ID = $wpdb->commentmeta.comment_id)";
		$args['orderby'] = "$wpdb->commentmeta.meta_value DESC";
		$args['groupby'] = "$wpdb->posts.ID";

		return $args;
	}
}


