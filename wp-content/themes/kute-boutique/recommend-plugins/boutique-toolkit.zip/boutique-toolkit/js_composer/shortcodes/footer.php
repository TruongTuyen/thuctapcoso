<?php
if( function_exists( 'vc_map' ) ){
    vc_map( array(
            'name' => __( 'Footer', 'boutique' ),
			'base' => 'kt_footer',
			"category"    => __('Kute Theme', 'boutique' ),
			'description' => __( 'The footer is showed by your design in post type template', 'boutique' ),
			'params' => array(
				array(
					'type'      => 'kt_posts',
					'heading'   => __( 'Footer', 'boutique' ),
					'post_type' => 'template',
					'param_name'  => 'id',
                    'admin_label' => true,
					'description' => __( 'Choose a footer ', 'boutique' )
				),
                array(
                    "type"        => "textfield",
                    "heading"     => __( "Extra class name", "js_composer" ),
                    "param_name"  => "el_class",
                    "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
                    'admin_label' => false
                ),
                
            )
        )
    );
}
