<?php
// Exit if accessed directly
if ( ! defined('ABSPATH')) exit;

function kt_get_template_mailchimp_id(){
    global $post;
    $template_id = null;
    
    $query = array(
    		'post_status'    => 'publish', 
    		'post_type'      => 'mc4wp-form', //This post type is created by plugin: "Mailchimp For Wordpress"
    		'posts_per_page' => 1, 
    );
    $myposts = get_posts( $query );
    
    if( !empty( $myposts ) ){
        foreach ( $myposts as $post ){
            setup_postdata( $post );
            $template_id = get_the_ID();
        }
    }
    wp_reset_postdata();
    return $template_id;
}
    
        
vc_map( array(
    "name" => __( "Newsletter", 'boutique'),
    "base" => "kt_newsletter",
    "category" => __('Kute Theme', 'boutique' ),
    "description" => __( 'Newsletter using mailchimp', 'boutique' ),
    "params" => array(
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Style', 'boutique' ),
            'param_name'  => 'style',
            'admin_label' => false,
            'value'       => array(
                __( 'Style 1', 'boutique' ) => 'style1',
                __( 'Style 2', 'boutique' ) => 'style2',
            ),
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Title", 'boutique' ),
            "param_name"  => "newsletter_title",
            "admin_label" => true,
            "value"       => __( "NEWSLETTER", "boutique" ),
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "SubTitle", "boutique" ),
            "param_name"  => "sub_title",
            "admin_label" => true,
            "value"       => __( "Sign up for Our Newsletter & Promotions", "boutique" ), 
        ),
        array(
            'type'          => 'css_editor',
            'heading'       => __( 'Css', 'boutique' ),
            'param_name'    => 'css',
            'admin_label'   => false,
            'group'          => __( 'Design options', 'boutique' )
        ),
        array(
            "type"          => "textfield",
            "heading"       => __( "Extra class name", "js_composer" ),
            "param_name"    => "el_class",
            "admin_labe"    => false,
            "description"   => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
            'group'          => __( 'Design options', 'boutique' )
            
        )
    ),
));

class WPBakeryShortCode_Kt_Newsletter extends WPBakeryShortCode {
    
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'kt_newsletter', $atts ) : $atts;
        $atts = shortcode_atts( array(
            'newsletter_title' => '',
            'style'            =>'',
            'css'              => '',
            'el_class'         => '', 
            'sub_title'        => '',
        ), $atts );
        extract($atts);
        $elementClass = array(
            'base' => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' '.' '.$style.' ', $this->settings['base'], $atts ),
            'extra' => $this->getExtraClass( $el_class ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        
        ob_start(); ?>
		<div class="newsletter <?php if( $elementClass ){ echo esc_attr( $elementClass ); } ?>">
            <div class="section-title text-center"><?php if( $newsletter_title ) : ?><h3><?php echo esc_html( $newsletter_title ); ?></h3><?php endif; ?></div>
            <?php if( $sub_title ) : ?><i class="newsletter-info"><?php echo esc_html( $sub_title ); ?></i><?php endif; ?>
            <?php $shortcode_id = kt_get_template_mailchimp_id(); ?>
            <?php if( !is_null( $shortcode_id ) ){ echo do_shortcode("[mc4wp_form id=\"$shortcode_id\"]"); } ?>
        </div>
        <?php
        return ob_get_clean();
    }
}