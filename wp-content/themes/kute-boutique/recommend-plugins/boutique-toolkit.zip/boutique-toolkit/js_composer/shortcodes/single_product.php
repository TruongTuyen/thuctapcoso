<?php
/**
 * @author  AngelsIT
 * @package Boutique TOOLKIT
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

vc_map( array(
    "name"        => __( "Single Product", 'boutique'),
    "base"        => "kt_single_product",
    "category"    => __('Kute Theme', 'boutique' ),
    "description" => __( 'Multi purpose to show single product', 'boutique' ),
    "params"      => array(
        array(
            'type'        => 'textfield',
            'heading'     => __( 'Title', 'boutique' ),
            'param_name'  => 'title',
            'description' => __( 'Show title of shortcode. If it isn\'t empty, product title will be insteaded', 'boutique' ),
            'admin_label' => true,
		),
        array(
            'type'        => 'textfield',
            'heading'     => __( 'Subtitle', 'boutique' ),
            'param_name'  => 'subtitle',
            'description' => __( 'Show price or something sample that in the shortcode when you don\'n want show price of product', 'boutique' ),
            'admin_label' => true,
		),
        array(
            'type'        => 'textarea',
            'heading'     => __( 'Short Description', 'boutique' ),
            'param_name'  => 'short_desc',
            'description' => __( 'Show short description of product if you don\'t want to show real short description of product', 'boutique' ),
            'admin_label' => false,
		),
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Style', 'boutique' ),
            'param_name'  => 'style',
            'admin_label' => true,
            'value'       => array(
                __( 'Full', 'boutique' )              => 'style-1',
                __( 'without Thumbnail', 'boutique' ) => 'style-2',
        	)
        ),
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Float', 'boutique' ),
            'param_name'  => 'float',
            'admin_label' => true,
            'value'       => array(
                __( 'Left', 'boutique' )  => 'left',
                __( 'Right', 'boutique' ) => 'right',
        	),
            "dependency"  => array("element" => "style", "value" => array( 'style-1' )),
        ),
		array(
			'type' => 'hidden',
			// This will not show on render, but will be used when defining value for autocomplete
			'param_name' => 'sku',
		),
        array(
			'type' => 'autocomplete',
			'heading' => __( 'Select identificator', 'boutique' ),
			'param_name' => 'id',
            'admin_label' => true,
			'description' => __( 'Input product ID or product SKU or product title to see suggestions', 'boutique' ),
		),
        array(
            "type"        => "attach_image",
            "heading"     => __("Thumbnail", 'boutique'),
            "param_name"  => "thumbnail",
            "admin_label" => true,
            'description' => __( 'Show replace thumbnail of product if you don\'t want to show real thumbanail of product', 'boutique' )
        ),
        array(
            "type"        => "textfield",
            "heading"     => __("Link", 'boutique'),
            "param_name"  => "link",
            "admin_label" => false,
            'description' => __( 'Show link instead of real link add to cart of product', 'boutique' )
        ),
        array(
            'type'        => 'textfield',
            'heading'     => __( 'Text Link', 'boutique' ),
            'param_name'  => 'text_link',
            'description' => __( 'Show text link when you entered the link above', 'boutique' ),
            'admin_label' => false,
		),
        array(
            "type"        => "textfield",
            "heading"     => __( "Extra class name", "boutique" ),
            "param_name"  => "el_class",
            "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
            'admin_label' => false,
            "dependency"  => array("element" => "carousel", "value" => array( 'enable' )),
        ),
        array(
            'type'           => 'css_editor',
            'heading'        => __( 'Css', 'boutique' ),
            'param_name'     => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group'          => __( 'Design options', 'boutique' ),
            'admin_label'    => false,
		),
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'CSS Animation', 'boutique' ),
            'param_name'  => 'css_animation',
            'admin_label' => false,
            'value'       => array(
                __( 'No', 'boutique' )                 => '',
                __( 'Top to bottom', 'boutique' )      => 'top-to-bottom',
                __( 'Bottom to top', 'boutique' )      => 'bottom-to-top',
                __( 'Left to right', 'boutique' )      => 'left-to-right',
                __( 'Right to left', 'boutique' )      => 'right-to-left',
                __( 'Appear from center', 'boutique' ) => "appear"
        	),
        	'description' => __( 'Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'boutique' )
        ),
    ),
));

class WPBakeryShortCode_KT_Single_Product extends WPBakeryShortCode {
    
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'kt_single_product', $atts ) : $atts;
        $atts = shortcode_atts( array(
            'title'          => '',
            'subtitle'       => '',
            'short_desc'     => '',
            
            'id'             => '',
            'sku'            => '',
            
            'style'          => 'style-1',
            'float'          => 'left',
            
            'thumbnail'      => '',
            'link'           => '',
            'text_link'      => '',
            'css_animation'  => '',
            'el_class'       => '',
            'css'            => '',   
            
        ), $atts );
        extract($atts);
        
        global $woocommerce_loop;
        
        $elementClass = array(
            'base'             => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'kt-sc-single-product', $this->settings['base'], $atts ),
            'extra'            => $this->getExtraClass( $el_class ),
            'css_animation'    => $this->getCSSAnimation( $css_animation ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        $banner_url = "";
        if( $thumbnail ){
            $banner = wp_get_attachment_image_src( $thumbnail , 'full' );  
            $banner_url =  is_array($banner) ? esc_url($banner[0]) : ''; 
        }
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        
        $elementClass = apply_filters( 'kt_product_tab_class_container', $elementClass ); 
        
        $meta_query = WC()->query->get_meta_query();

		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => 1,
			'no_found_rows'  => 1,
			'post_status'    => 'publish',
			'meta_query'     => $meta_query
		);

		if ( $sku ) {
			$args['meta_query'][] = array(
				'key'     => '_sku',
				'value'   => $sku,
				'compare' => '='
			);
		}

		if ( $id ) {
			$args['p'] = $id;
		}

		ob_start();
        
		$products = new WP_Query( apply_filters( 'woocommerce_shortcode_products_query', $args, $atts ) ); ?>
        <?php if ( $products->have_posts() ) : ?>
            <?php if( $style == 'style-1' ): ?>
                <?php while ( $products->have_posts() ) : $products->the_post(); $permalink = $link ? $link : get_the_permalink(); ?>
                    <!-- Section single product-->
                    <div class="single-product <?php echo esc_attr( $elementClass ) ?>">
                        <div class="container">
                            <div class="block-single-product row">
                                <?php if( $float == 'left' ): ?>
                                    <div class="product-image col-sm-5">
                                        <?php if( isset( $banner_url ) && $banner_url ): ?>
                                            <img src="<?php echo esc_url( $banner_url ) ?>" alt="<?php the_title(); ?>" />
                                        <?php elseif( has_post_thumbnail() ): ?>
                                            <?php if(  function_exists( 'woocommerce_get_product_thumbnail' ) ): ?>
                                                <?php echo woocommerce_get_product_thumbnail( 'full' ) ?>
                                            <?php else: ?>
                                                <?php echo get_the_post_thumbnail( get_the_ID(), 'full' ); ?>
                                            <?php  endif; ?>
                                        <?php endif; ?>
                                    </div>
                                    <div class="product-info col-sm-7">
                                        <h3 class="product-name">
                                            <?php if( $title ): ?>
                                                <a href="<?php echo esc_url( $permalink ) ?>"><?php echo esc_html( $title ) ?></a> 
                                            <?php else: ?>
                                                <a href="<?php echo esc_url( $permalink ) ?>"><?php the_title() ?></a> 
                                            <?php endif; ?>
                                        </h3>
                                        
                                        <div class="desc">
                                            <?php if( $short_desc ): ?>
                                                <?php echo balanceTags( $short_desc ); ?>
                                            <?php elseif( function_exists( 'woocommerce_template_single_excerpt' ) ): ?>
                                                <?php woocommerce_template_single_excerpt(); ?>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <?php if( $subtitle ): ?>
                                            <span class="price"><?php echo esc_html( $subtitle ); ?></span>
                                        <?php elseif( function_exists( 'woocommerce_template_single_price' ) ): ?>
                                            <?php woocommerce_template_single_price(); ?>
                                        <?php endif; ?>
                                        
                                        <?php if( $link ): ?>
                                            <a href="<?php echo esc_url( $permalink ) ?>" class="addtocart">
                                                <span class="pe-7s-cart"></span>
                                                <?php if( $text_link ): ?>
                                                    <?php echo esc_html( $text_link ); ?>
                                                <?php else: ?>
                                                    <?php esc_html_e( '+ADD TO CART', 'boutique' ) ?>
                                                <?php endif; ?>
                                            </a>
                                        <?php elseif( function_exists( 'woocommerce_template_single_add_to_cart' ) ): ?>
                                            <?php woocommerce_template_single_add_to_cart(); ?>
                                        <?php endif; ?>
                                    </div>
                                <?php else: //If($float==left)?>
                                    <div class="product-info col-sm-7">
                                        <h3 class="product-name">
                                            <?php if( $title ): ?>
                                                <a href="<?php echo esc_url( $permalink ) ?>"><?php echo esc_html( $title ) ?></a> 
                                            <?php else: ?>
                                                <a href="<?php echo esc_url( $permalink ) ?>"><?php the_title() ?></a> 
                                            <?php endif; ?>
                                        </h3>
                                        
                                        <div class="desc">
                                            <?php if( $short_desc ): ?>
                                                <?php echo balanceTags( $short_desc ); ?>
                                            <?php elseif( function_exists( 'woocommerce_template_single_excerpt' ) ): ?>
                                                <?php woocommerce_template_single_excerpt(); ?>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <?php if( $subtitle ): ?>
                                            <span class="price"><?php echo esc_html( $subtitle ); ?></span>
                                        <?php elseif( function_exists( 'woocommerce_template_single_price' ) ): ?>
                                            <?php woocommerce_template_single_price(); ?>
                                        <?php endif; ?>
                                        
                                        <?php if( $link ): ?>
                                            <a href="<?php echo esc_url( $permalink ) ?>" class="addtocart">
                                                <span class="pe-7s-cart"></span>
                                                <?php if( $text_link ): ?>
                                                    <?php echo esc_html( $text_link ); ?>
                                                <?php else: ?>
                                                    <?php esc_html_e( '+ADD TO CART', 'boutique' ) ?>
                                                <?php endif; ?>
                                            </a>
                                        <?php elseif( function_exists( 'woocommerce_template_single_add_to_cart' ) ): ?>
                                            <?php woocommerce_template_single_add_to_cart(); ?>
                                        <?php endif; ?>
                                    </div>
                                    <div class="product-image col-sm-5">
                                        <?php if( isset( $banner_url ) && $banner_url ): ?>
                                            <img src="<?php echo esc_url( $banner_url ) ?>" alt="<?php the_title(); ?>" />
                                        <?php elseif( has_post_thumbnail() ): ?>
                                            <?php if(  function_exists( 'woocommerce_get_product_thumbnail' ) ): ?>
                                                <?php echo woocommerce_get_product_thumbnail( 'full' ) ?>
                                            <?php else: ?>
                                                <?php echo get_the_post_thumbnail( get_the_ID(), 'full' ); ?>
                                            <?php  endif; ?>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- Section single product-->
                <?php endwhile; ?>
            <?php else: //if( $style == 'style-2' ): ?>
                <?php while ( $products->have_posts() ) : $products->the_post(); $permalink = $link ? $link : get_the_permalink(); ?>
                    <!-- Section single product-->
                    <div class="single-product <?php echo esc_attr( $elementClass ) ?>">
                        <div class="block-single-product">
                            <div class="product-info">
                                <h3 class="product-name">
                                    <?php if( $title ): ?>
                                        <a href="<?php echo esc_url( $permalink ) ?>"><?php echo esc_html( $title ) ?></a> 
                                    <?php else: ?>
                                        <a href="<?php echo esc_url( $permalink ) ?>"><?php the_title() ?></a> 
                                    <?php endif; ?>
                                </h3>
                                
                                <div class="desc">
                                    <?php if( $short_desc ): ?>
                                        <?php echo balanceTags( $short_desc ); ?>
                                    <?php elseif( function_exists( 'woocommerce_template_single_excerpt' ) ): ?>
                                        <?php woocommerce_template_single_excerpt(); ?>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if( $subtitle ): ?>
                                    <span class="price"><?php echo esc_html( $subtitle ); ?></span>
                                <?php elseif( function_exists( 'woocommerce_template_single_price' ) ): ?>
                                    <?php woocommerce_template_single_price(); ?>
                                <?php endif; ?>
                                
                                <?php if( $link ): ?>
                                    <a href="<?php echo esc_url( $permalink ) ?>" class="addtocart">
                                        <span class="pe-7s-cart"></span>
                                        <?php if( $text_link ): ?>
                                            <?php echo esc_html( $text_link ); ?>
                                        <?php else: ?>
                                            <?php esc_html_e( '+ADD TO CART', 'boutique' ) ?>
                                        <?php endif; ?>
                                    </a>
                                <?php elseif( function_exists( 'woocommerce_template_single_add_to_cart' ) ): ?>
                                    <?php woocommerce_template_single_add_to_cart(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div><!-- Section single product-->
                <?php endwhile; ?>
            <?php endif; //if( $style == 'style-1' ):?>
        <?php else: //if ( $products->have_posts() )?>
            <div class="single-product <?php echo esc_attr( $elementClass ) ?>">
                <div class="block-single-product row">
                    <div class="product-info">
                        <?php if( $title ): ?>
                            <h3 class="product-name">
                                <a href="<?php echo esc_url( $link ) ?>"><?php echo esc_html( $title ) ?></a> 
                            </h3>
                        <?php endif; ?>
                        <?php if( $short_desc ): ?>
                            <div class="desc">
                                <?php echo balanceTags( $short_desc ); ?>
                            </div>
                        <?php endif; ?>
                        <?php if( $subtitle ): ?>
                            <span class="price"><?php echo esc_html( $subtitle ); ?></span>
                        <?php endif; ?>
                        
                        <?php if( $link ): ?>
                            <a href="<?php echo esc_url( $link ) ?>" class="addtocart">
                                <span class="pe-7s-cart"></span>
                                <?php if( $text_link ): ?>
                                    <?php echo esc_html( $text_link ); ?>
                                <?php else: ?>
                                    <?php esc_html_e( '+ADD TO CART', 'boutique' ) ?>
                                <?php endif; ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php
        woocommerce_reset_loop();
		wp_reset_postdata();
    }
    
}


