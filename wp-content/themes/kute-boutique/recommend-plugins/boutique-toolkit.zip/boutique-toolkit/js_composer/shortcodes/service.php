<?php
/**
 * @author  AngelsIT
 * @package BOUTIQUE TOOLKIT
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// Setting shortcode service
vc_map( array(
    "name"        => __( "Service", 'boutique'),
    "base"        => "service",
    "category"    => __('Kute Theme', 'boutique' ),
    "description" => __( "Display service box", 'boutique'),
    "params"      => array(
        array(
            "type"        => "textfield",
            "heading"     => __( "Id", 'boutique' ),
            "param_name"  => "service_id",
            "admin_label" => true,
            "description" => __( "Get service by id.", 'boutique' ),
        ),
        array(
            'type'           => 'css_editor',
            'heading'        => __( 'Css', 'boutique' ),
            'param_name'     => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group'          => __( 'Design options', 'boutique' )
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Extra class name", 'boutique' ),
            "param_name"  => "el_class",
            "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
        )
    )
));
class WPBakeryShortCode_Service extends WPBakeryShortCode {
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'service', $atts ) : $atts;
        $atts = shortcode_atts( array(  
            'service_id'    => '',       
            'css_animation' => '',
            'el_class'      => '',
            'css'           => ''
            
        ), $atts );
        extract($atts);
        
        $elementClass = array(
            'base' => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' ', $this->settings['base'], $atts ),
            'extra' => $this->getExtraClass( $el_class ),
            'css_animation' => $this->getCSSAnimation( $css_animation ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        
        ob_start();
        if( $service_id ):
        $service_query = new WP_Query( apply_filters( 'woocommerce_shortcode_products_query', array( 'post_type' => 'service', 'p' => $service_id ), $atts ) ); ?>
        
        <?php if( $service_query->have_posts() ): ?>
            <?php while ( $service_query->have_posts()) : $service_query->the_post(); ?>
                <div class="element-icon style2" <?php echo esc_attr( $elementClass ); ?>>
                    <?php if(has_post_thumbnail()):?>
					   <div class="icon"><?php the_post_thumbnail( 'full' );?></div>
                    <?php endif;?>
					<div class="content">
						<a href="<?php the_permalink();?>"><h4 class="title"><?php the_title();?></h4> </a>
					</div>
				</div>
            <?php endwhile; ?>
        <?php endif;//$service_query
        
        wp_reset_postdata();
        wp_reset_query();
        endif;
        $result = ob_get_clean();
        return $result;
    }
}