<?php
// Exit if accessed directly
if ( ! defined('ABSPATH')) exit;

vc_map( array(
    "name" => __( "Social", 'boutique'),
    "base" => "kt_social",
    "category" => __('Kute Theme', 'boutique' ),
    "description" => __( 'Display social icon in footer', 'boutique' ),
    "params" => array(
        array(
            "type"        => "textfield",
            "heading"     => __( "Title", 'boutique' ),
            "param_name"  => "title",
            "admin_label" => true
        ),
        array(
            "type" => "textfield",
            "heading" => __( "Extra class name", 'boutique' ),
            "param_name" => "el_class",
            "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'boutique' ),
            'admin_label' => false,
        ),
        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'boutique' ),
            'param_name' => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group' => __( 'Design options', 'boutique' ),
            'admin_label' => false,
        ),
    ),
));

class WPBakeryShortCode_Kt_Social extends WPBakeryShortCode {
    
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'kt_social', $atts ) : $atts;
        $atts = shortcode_atts( array(
            'title'            => '',
            
            'el_class'         => '',
            'css'              => ''
        ), $atts );
        extract($atts);
        $elementClass = array(
            'base' => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' social ', $this->settings['base'], $atts ),
            'extra' => $this->getExtraClass( $el_class ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        
        $facebook   = kt_option('kt_facebook_link_id');
        $twitter    = kt_option('kt_twitter_link_id');
        $pinterest  = kt_option('kt_pinterest_link_id');
        $dribbble   = kt_option('kt_dribbble_link_id');
        $vimeo      = kt_option('kt_vimeo_link_id');
        $tumblr     = kt_option('kt_tumblr_link_id');
        $skype      = kt_option('kt_skype_link_id');
        $linkedin   = kt_option('kt_linkedIn_link_id');
        $vk         = kt_option('kt_vk_link_id');
        $googleplus = kt_option('kt_google_plus_link_id');
        $youtube    = kt_option('kt_youtube_link_id');
        $instagram  = kt_option('kt_instagram_link_id');
        
        $social_icons = '';
        ob_start(); ?>
        
        <div class="<?php echo esc_attr( $elementClass ) ?>">
            <?php if( $title ): ?>
            <div class="section-title hide">
                <h3><?php echo esc_html( $title ) ?></h3>
            </div>
            <?php endif; ?>
            <div class="section-icon">
                <?php 
                    if ($facebook) {
                       echo '<a target="_blank" href="'.esc_url($facebook).'" title ="'.__( 'Facebook', 'boutique' ).'" ><i class="fa fa-facebook"></i></a>';
                    }
                    if ($twitter) {
                        echo '<a target="_blank" href="http://www.twitter.com/'.esc_attr($twitter).'" title = "'.__( 'Twitter', 'boutique' ).'" ><i class="fa fa-twitter"></i></a>';
                    }
                    if ($dribbble) {
                        echo '<a target="_blank" href="http://www.dribbble.com/'.esc_attr($dribbble).'" title ="'.__( 'Dribbble', 'boutique' ).'" ><i class="fa fa-dribbble"></i></a>';
                    }
                    if ($vimeo) {
                        echo '<a target="_blank" href="http://www.vimeo.com/'.esc_attr($vimeo).'" title ="'.__( 'Vimeo', 'boutique' ).'" ><i class="fa fa-vimeo-square"></i></a>';
                    }
                    if ($tumblr) {
                        echo '<a target="_blank" href="http://'.esc_attr($tumblr).'.tumblr.com/" title ="'.__( 'Tumblr', 'boutique' ).'" ><i class="fa fa-tumblr"></i></a>';
                    } 
                    if ($skype) {
                        echo '<a target="_blank" href="skype:'.esc_attr($skype).'" title ="'.__( 'Skype', 'boutique' ).'" ><i class="fa fa-skype"></i></a>';
                    }
                    if ($linkedin) {
                        echo '<a target="_blank" href="'.esc_attr($linkedin).'" title ="'.__( 'Linkedin', 'boutique' ).'" ><i class="fa fa-linkedin"></i></a>';
                    }
                    if ($googleplus) {
                        echo '<a target="_blank" href="'.esc_url( $googleplus ).'" title ="'.__( 'Google Plus', 'boutique' ).'" ><i class="fa fa-google-plus"></i></a>';
                    }
                    if ($youtube) {
                        echo '<a target="_blank" href="http://www.youtube.com/user/'.esc_attr( $youtube ).'" title ="'.__( 'Youtube', 'boutique' ).'"><i class="fa fa-youtube"></i></a>';
                    }
                    if ($pinterest) {
                        echo '<a target="_blank" href="http://www.pinterest.com/'.esc_attr( $pinterest ).'/" title ="'.__( 'Pinterest', 'boutique' ).'" ><i class="fa fa-pinterest-p"></i></a>';
                    }
                    if ($instagram) {
                        echo '<a target="_blank" href="http://instagram.com/'.esc_attr( $instagram ).'" title ="'.__( 'Instagram', 'boutique' ).'" ><i class="fa fa-instagram"></i></a>';
                    }
                    
                    if ($vk) {
                        echo '<a target="_blank" href="https://vk.com/'.esc_attr( $vk ).'" title ="'.__( 'Vk', 'boutique' ).'" ><i class="fa fa-vk"></i></a>';
                    }
                ?>
            </div>
        </div>
        <?php return ob_get_clean();
    }
}