<?php
// Exit if accessed directly
if ( ! defined('ABSPATH')) exit;

vc_map( array(
    "name" => __( "Video", 'boutique'),
    "base" => "kt_video",
    "category" => __('Kute Theme', 'boutique' ),
    "description" => __( 'Display a video', 'boutique' ),
    "params" => array(
        array(
            "type"        => "attach_image",
            "heading"     => __( "Preview Image", 'boutique' ),
            "param_name"  => "preview_img",
            "admin_label" => true,
            "group"       => __( "Video", "boutique" ),
        ),
        array(
            "type"        => "dropdown",
            "heading"     => __( "Video", 'boutique' ),
            "param_name"  => "video_type",
            "admin_label" => true,
            "group"       => __( "Video", "boutique" ),
            "value"       => array(
                __( "Video Youtube", "boutique" ) => "youtube",
                __( "Video Vimeo", "boutique" )   => "vimeo",
            ),
            "std"         => "vimeo"
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Youtube Video ID", 'boutique' ),
            "param_name"  => "youtube_id",
            "admin_label" => true,
            "group"       => __( "Video", "boutique" ),
            "dependency"  => Array( 
                "element"    =>  "video_type", 
                "value"      =>  Array( "youtube" ) 
            ),
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __( "Vimeo Video ID", 'boutique' ),
            "param_name"  => "vimeo_id",
            "admin_label" => true,
            "group"       => __( "Video", "boutique" ),
            "dependency"  => Array( 
                "element"    =>  "video_type", 
                "value"      =>  Array( "vimeo" ) 
            ),
        ),
        array(
            'type'          => 'css_editor',
            'heading'       => __( 'Css', 'boutique' ),
            'param_name'    => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group'         => __( 'Design options', 'boutique' ),
            'admin_label'   => false,
        ),
        array(
            "type"          => "textfield",
            "heading"       => __( "Extra class name", "js_composer" ),
            "param_name"    => "el_class",
            "admin_labe"    => false,
            "group"         => __( "Extra CSS", "boutique" ),
            "description"   => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
            
        )
    ),
));

class WPBakeryShortCode_Kt_Video extends WPBakeryShortCode {
    
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'kt_video', $atts ) : $atts;
        $atts = shortcode_atts( array(
            'preview_img'               => '',
            'video_type'                => '',
            'youtube_id'                => '',
            'vimeo_id'                  => '',
            'css'                       => '',
            'el_class'                  => '',
        ), $atts );
        extract($atts);
        $elementClass = array(
            'base' => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' ', $this->settings['base'], $atts ),
            'extra' => $this->getExtraClass( $el_class ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        $banner_url = "";
        if( $preview_img ){
            $banner = wp_get_attachment_image_src( $preview_img , 'full' );  
            $banner_url =  is_array($banner) ? esc_url($banner[0]) : ''; 
        }
        ob_start(); ?>
		<div class="video video-lightbox <?php if( $elementClass ){ echo esc_attr( $elementClass ); } ?> ">
            <?php if( $banner_url != '') : ?>
			<img src="<?php echo esc_url( $banner_url ); ?>" alt="">
            <?php else : ?>
            <img src="<?php echo KUTETHEME_PLUGIN_URL . 'assets/images/bg_video.png'; ?>" alt="">
            <?php endif; ?>
			<div class="overlay"></div>
            <?php if( $video_type && $video_type == 'vimeo' ) : ?>
			<a href="#" class="link-lightbox button-play" data-videoid="<?php if( $vimeo_id && absint( $vimeo_id ) ){ echo esc_attr( $vimeo_id ); } ?>" data-videosite="vimeo"></a>
		    <?php elseif( $video_type && $video_type == 'youtube') : ?>
            <a href="#" class="link-lightbox button-play" data-videoid="<?php if( $youtube_id ){ echo esc_attr( $youtube_id ); } ?>" data-videosite="youtube"></a>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
}