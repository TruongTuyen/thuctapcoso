<?php
// Exit if accessed directly
if ( ! defined('ABSPATH')) exit;

vc_map( array(
    "name" => __( "Payment", 'boutique'),
    "base" => "kt_payment",
    "category" => __('Kute Theme', 'boutique' ),
    "description" => __( 'Display payment methods', 'boutique' ),
    "params" => array(
        array(
            "type"        => "textfield",
            "heading"     => __( "Title", 'boutique' ),
            "param_name"  => "title",
            "admin_label" => true
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "SubTitle", 'boutique' ),
            "param_name"  => "sub_title",
            "admin_label" => true
        ),
        array(
            "type"        => "attach_images",
            "heading"     => __("Banner Images", 'boutique'),
            "param_name"  => "banner_image",
            "admin_label" => true,
            'description' => __( 'It shows the images of banner', 'boutique' )
        ),
        array(
            "type" => "textfield",
            "heading" => __( "Extra class name", "js_composer" ),
            "param_name" => "el_class",
            "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "js_composer" ),
            'admin_label' => false,
        ),
        array(
            'type' => 'css_editor',
            'heading' => __( 'Css', 'boutique' ),
            'param_name' => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group' => __( 'Design options', 'boutique' ),
            'admin_label' => false,
        ),
    ),
));

class WPBakeryShortCode_Kt_Payment extends WPBakeryShortCode {
    
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'kt_payment', $atts ) : $atts;
        $atts = shortcode_atts( array(
            'title'            => __( 'WE ACCEPT', 'boutique'),
            'sub_title'        => __( 'Online Payment Be Secured', 'boutique' ),
            'banner_image'     => '',
            'el_class'         => '',
            'css'              => ''
        ), $atts );
        extract($atts);
        $elementClass = array(
            'base' => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' ', $this->settings['base'], $atts ),
            'extra' => $this->getExtraClass( $el_class ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        
        if( $banner_image ){
            $img_id = explode(",",$banner_image);
            $img_url = array();
            if( is_array( $img_id ) && !empty( $img_id ) ){
                foreach( $img_id as $value ){
                    $banner = wp_get_attachment_image_src( $value, 'full' );
                    $img_url[] = is_array( $banner ) ? esc_url( $banner[0]) : '';
                }
            }
        }
        ob_start(); ?>
        <div class="payment <?php echo esc_attr( $elementClass ); ?>">
			<div class="head">
                <?php if( $title ) : ?>
                    <span><?php echo esc_html( $title ); ?></span>
                <?php endif; ?>
                <?php if( $sub_title ) : ?>
                    <span class="PlayfairDisplay"><?php echo esc_html( $sub_title ); ?></span>
                <?php endif; ?>
            </div>
            <?php if( isset( $img_url ) && !empty( $img_url ) ) : ?>
			<div class="list">
                <?php foreach( $img_url as $url ) : ?>
                    <span class="item">    
				    <img src="<?php echo esc_url( $url ); ?>" alt="<?php echo esc_html( $title ); ?>" />
                    </span>
                <?php endforeach; ?>
			</div>
            <?php endif; ?>
		</div>
        <?php
        return ob_get_clean();
    }
}