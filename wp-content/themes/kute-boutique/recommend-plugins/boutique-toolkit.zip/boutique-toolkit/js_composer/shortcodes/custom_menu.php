<?php
/**
 * @author  AngelsIT
 * @package Boutique TOOLKIT
 * @version 1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

vc_map( array(
    "name"        => __( "Custome Menu", 'boutique'),
    "base"        => "ktcustommenu",
    "category"    => __('Kute Theme', 'boutique' ),
    "description" => __( "Display custom menu for boutique theme", 'boutique'),
    "params"      => array(
        array(
            "type"        => "kt_nav_menu",
            "heading"     => __( "Menu", 'boutique' ),
            "param_name"  => "nav_menu",
            "admin_label" => true,
            'description' => __( 'Select menu to display.', 'boutique' )
        ),
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Style', 'boutique' ),
            'param_name'  => 'style',
            'admin_label' => false,
            'value'       => array(
                __( 'Style 1', 'boutique' ) => 'style-1',
                __( 'Style 2', 'boutique' ) => 'style-2',
                __( 'Style 3', 'boutique' ) => 'style-3',
                __( 'Style 4', 'boutique' ) => 'style-4',
        	),
        	'description' => __( 'Select template loop', 'boutique' )
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Title", 'boutique' ),
            "param_name"  => "title",
            "admin_label" => true,
            "dependency"  => array("element" => "style", "value" => array( 'style-2', 'style-4' )),
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "SubTitle", 'boutique' ),
            "param_name"  => "sub_title",
            "admin_label" => true,
            "dependency"  => array("element" => "style", "value" => array( 'style-2', 'style-4' )),
        ),
        array(
            "type"        => "attach_image",
            "heading"     => __("Bakground Image", 'boutique'),
            "param_name"  => "banner_image",
            "admin_label" => true,
            'description' => __( 'It shows the image of background', 'boutique' ),
            "dependency"  => array("element" => "style", "value" => array( 'style-2', 'style-4' )),
        ),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'on-carousel',
                __( 'No', 'boutique' )  => 'off-carousel'
            ),
            'std'         => 'on-carousel',
            'heading'     => __( 'Use Carousel', 'boutique' ),
            'param_name'  => 'carousel',
            'description' => __( "Use carousel to slip menu horizontal", 'boutique' ),
            'admin_label' => true,
            "dependency"  => array("element" => "style", "value" => array( 'style-1')),
        ),
        
        // Carousel
        array(
            "type"        => "kt_number",
            "heading"     => __("Margin", 'boutique'),
            "param_name"  => "margin",
            "value"       => "30",
            "suffix"      => __("px", 'boutique'),
            "description" => __('Distance( or space) between 2 item', 'boutique'),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array( "element" => "carousel", "value" => array( 'on-carousel' ) ),
        ),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'AutoPlay', 'boutique' ),
            'param_name'  => 'autoplay',
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array( "element" => "carousel", "value" => array( 'on-carousel' ) ),
        ),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'Navigation', 'boutique' ),
            'param_name'  => 'navigation',
            'description' => __( "Show buton 'next' and 'prev' buttons.", 'boutique' ),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array( "element" => "carousel", "value" => array( 'on-carousel' ) ),
        ),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'Loop', 'boutique' ),
            'param_name'  => 'loop',
            'description' => __( "Inifnity loop. Duplicate last and first items to get loop illusion.", 'boutique' ),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array( "element" => "carousel", "value" => array( 'on-carousel' ) ),
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __("Slide Speed", 'boutique'),
            "param_name"  => "slidespeed",
            "value"       => "250",
            "suffix"      => __("milliseconds", 'boutique'),
            "description" => __('Slide speed in milliseconds', 'boutique'),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array( "element" => "carousel", "value" => array( 'on-carousel' ) ),
        ),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 1,
                __( 'No', 'boutique' )  => 0
            ),
            'std'         => 1,
            'heading'     => __( 'Use Carousel Responsive', 'boutique' ),
            'param_name'  => 'use_responsive',
            'description' => __( "Try changing your browser width to see what happens with Items and Navigations", 'boutique' ),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
            
            "dependency"  => array( "element" => "carousel", "value" => array( 'on-carousel' ) ),
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on destop (Screen resolution of device >= 992px )", 'boutique'),
            "param_name"  => "items_destop",
            "value"       => "4",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The number of items on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
            "dependency"  => array( "element" => "carousel", "value" => array( 'on-carousel' ) ),
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on tablet (Screen resolution of device >=768px and < 992px )", 'boutique'),
            "param_name"  => "items_tablet",
            "value"       => "2",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The number of items on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
            
            "dependency"  => array("element" => "carousel","value" => array( 'on-carousel' )),
        ),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on mobile (Screen resolution of device < 768px)", 'boutique'),
            "param_name"  => "items_mobile",
            "value"       => "1",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The numbers of item on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
            
            "dependency"  => array( "element" => "carousel", "value" => array( 'on-carousel' ) ),
        ),
        array(
            'type'           => 'css_editor',
            'heading'        => __( 'Css', 'boutique' ),
            'param_name'     => 'css',
            'group'          => __( 'Design options', 'boutique' )
        )
    )
));

class WPBakeryShortCode_KTCustomMenu extends WPBakeryShortCode {
    
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'ktcustommenu', $atts ) : $atts;
                        
        $atts = shortcode_atts( array(
            'nav_menu'      => '',
            'style'         => 'style-1',
            'title'         => '',
            'sub_title'     => '',
            'banner_image'  => '',
            'depth'         => 1,
            'carousel'      => 'on-carousel',
            
            //Carousel            
            'margin'         => 30,
            'autoplay'       => 'false', 
            'navigation'     => 'false',
            'slidespeed'     => 250,
            'loop'           => 'true',
            //Default
            'use_responsive' => 1,
            'items_destop'   => 4,
            'items_tablet'   => 2,
            'items_mobile'   => 1,
            
            'css_animation' => '',
            'el_class'      => '',
            'css'           => '',
            
        ), $atts );
        extract($atts);
        
        $elementClass = array(
            'base'             => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, ' ', $this->settings['base'], $atts ),
            'extra'            => $this->getExtraClass( $el_class ),
            'css_animation'    => $this->getCSSAnimation( $css_animation ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' custom-menu ', '' ), implode( ' ', $elementClass ) );
        
        $data_carousel = array(
            "autoplay"           => $autoplay,
            "nav"                => $navigation,
            "margin"             => $margin,
            'dots'               => 'false',
            'loop'               => $loop,
            'autoplayHoverPause' => 'true'
        );

        $banner_url = "";
        if( $banner_image ){
            $banner = wp_get_attachment_image_src( $banner_image , 'full' );  
            $banner_url =  is_array($banner) ? esc_url($banner[0]) : ''; 
        }
        if( $nav_menu ){

            $nav_menu = array_map( 'trim', explode( ',', $nav_menu ) );
        }
        ob_start(); ?>
        <?php if( $nav_menu && is_array( $nav_menu ) ): ?>
            <?php if( $style == 'style-1' ): ?>
                <?php
                    if( $use_responsive ):
                        $arr = array( 
                            '0'   => array ( 
                                "items" => $items_mobile
                            ), 
                            '768' => array ( 
                                "items" => $items_tablet
                            ), 
                            '992' => array (
                                "items" => $items_destop
                            )
                        );
                        $data_responsive = json_encode($arr);
                        $data_carousel["responsive"] = $data_responsive;
                        
                    else:
                        $data_carousel['items'] = $items_destop;
                    endif;
                    foreach( $nav_menu as $menu ):
                        if( $carousel =='on-carousel'){
                            $defaults = array(
                                'menu'            => $menu,
                                'container'       => false,
                                'menu_class'      => 'category-menu category-carousel owl-carousel nav-style2 nav-center-outside',
                                'items_wrap'      => '<ul '._data_carousel($data_carousel).' id="%1$s" class="%2$s">%3$s</ul>',
                                'depth'           => $depth,
                                'walker'          => new wp_bootstrap_navwalker(),
                            );
                        }else{
                            $defaults = array(
                                'menu'            => $menu,
                                'container'       => false,
                                'menu_class'      => 'category-menu',
                                'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                                'depth'           => $depth,
                                'walker'          => new wp_bootstrap_navwalker(),
                            );
                        }
                        wp_nav_menu( $defaults );
                    endforeach; 
            ?>
            <?php elseif( $style == 'style-2' ): ?>
                <div class="block-category-carousel style-2 <?php echo esc_attr( $elementClass ) ?>" <?php if( isset( $banner_url ) && $banner_url ) : ?>style="background-image: url('<?php echo esc_url( $banner_url ) ?>');"<?php endif; ?>>
                    <div class="block-inner">
                        <?php if( $title ): ?>
                        <h3 class="title"><?php echo esc_html( $title ) ?></h3>
                        <?php endif; ?>
                        <?php if( $sub_title ): ?>
                            <span class="sub-title"><?php echo esc_html( $sub_title ) ?></span>
                        <?php endif; ?>
                        <div class="block-inner">
                            <?php  foreach( $nav_menu as $menu ):
                                    wp_nav_menu( array(
                                        'menu'        => $menu,
                                        'fallback_cb' => '',
                                        'menu_class'  => 'list-cat',
                                        'container'   => false,
                                        'depth'       => $depth,
                                        'walker'      => new wp_bootstrap_navwalker()
                                    ) );
                            endforeach; ?>
                        </div>
                    </div>
    			</div>
            <?php elseif( $style == 'style-3' ): ?>
                <div class="content-custom-menu style-3 <?php echo esc_attr( $elementClass ); ?>">
					<?php foreach( $nav_menu as $menu ):
                            wp_nav_menu( array(
                				'menu'        => $menu,
                				'fallback_cb' => '',
                				'menu_class'  => 'menu-footer',
                				'container'   => false,
                                'depth'       => $depth,
                                'walker'      => new wp_bootstrap_navwalker()
                			) );
                    endforeach; ?>
				</div>
            <?php elseif( $style == 'style-4' ): ?>
                <?php $data_carousel['items'] = 1; ?>
                <div class="header-categoy-menu style-4 <?php echo esc_attr( $elementClass ) ?>" <?php if( isset( $banner_url ) && $banner_url ) : ?>style="background-image: url('<?php echo esc_url( $banner_url ) ?>');"<?php endif; ?>>
                	<span class="close-header-sidebar"><span class="icon pe-7s-close"></span></span>
                	<span class="open-header-sidebar"><i class="fa fa-angle-double-left"></i></span>
                	<div class="inner">
                		<div class="block-category-carousel">
                            <?php if( $title ): ?>
                			     <h3 class="title"><?php echo esc_html( $title ) ?></h3>
                            <?php endif; ?>
                            <?php if( $sub_title ): ?>
                			     <span class="sub-title"><?php echo esc_html( $sub_title ) ?></span>
                            <?php endif; ?>
                			<div class="block-inner">
                				<?php foreach( $nav_menu as $menu ): ?>
                                <?php 
                                    wp_nav_menu( array(
                        				'menu'        => $menu,
                        				'fallback_cb' => '',
                        				'menu_class'  => 'list-cat',
                        				'container'   => false,
                                        'depth'       => $depth,
                                        'walker'      => new wp_bootstrap_navwalker()
                        			) );
                                ?>
                                <?php endforeach; ?>
                			</div>
                		</div>
                	</div>
                </div>
            <?php endif; ?>
        <?php endif;//if( $nav_menu ): 
        return ob_get_clean();
    }
}