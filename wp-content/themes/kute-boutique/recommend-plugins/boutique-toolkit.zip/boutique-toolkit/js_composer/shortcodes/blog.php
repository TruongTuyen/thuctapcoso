<?php
/**
 * @author  AngelsIT
 * @package BOUTIQUE TOOLKIT
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

vc_map( array(
     "name"        => __( "Blogs", 'boutique'),
     "base"        => "blog_carousel",
     "category"    => __('Kute Theme', 'boutique' ),
     "description" => __( "Display blog by carousel", 'boutique'),
     "params"      => array(
        // array(
        //     "type"        => "textfield",
        //     "heading"     => __( "Title", 'boutique' ),
        //     "param_name"  => "title",
        //     "admin_label" => true,
        // ),
        array(
            "type"       => "dropdown",
            "heading"    => __("Style", 'boutique'),
            "param_name" => "style",
            "value"      => array(
        		__('Full', 'boutique')    => 'style-1',
                __('Sidebar', 'boutique') => 'style-2'
        	),
            'std'         => 'style-1',
            "description" => __("Select how to show posts.",'boutique'),
        ),
        array(
            "type"        => "textfield",
            "heading"     => __( "Number Post", 'boutique' ),
            "param_name"  => "per_page",
            'std'         => 10,
            "admin_label" => false,
            'description' => __( 'Number post in a slide', 'boutique' )
        ),
        array(
            "type"       => "dropdown",
            "heading"    => __("Order by", 'boutique'),
            "param_name" => "orderby",
            "value"      => array(
        		__('None', 'boutique')     => 'none',
                __('ID', 'boutique')       => 'ID',
                __('Author', 'boutique')   => 'author',
                __('Name', 'boutique')     => 'name',
                __('Date', 'boutique')     => 'date',
                __('Modified', 'boutique') => 'modified',
                __('Rand', 'boutique')     => 'rand',
        	),
            'std'         => 'date',
            "description" => __("Select how to sort retrieved posts.",'boutique'),
        ),
        array(
            "type"       => "dropdown",
            "heading"    => __("Order", 'boutique'),
            "param_name" => "order",
            "value"      => array(
                __('ASC', 'boutique') => 'ASC',
                __('DESC', 'boutique') => 'DESC'
        	),
            'std'         => 'DESC',
            "description" => __("Designates the ascending or descending order.",'boutique')
        ),
        // Carousel
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'AutoPlay', 'boutique' ),
            'param_name'  => 'autoplay',
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false
		),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'Navigation', 'boutique' ),
            'param_name'  => 'navigation',
            'description' => __( "Show buton 'next' and 'prev' buttons.", 'boutique' ),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
		),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 'true',
                __( 'No', 'boutique' )  => 'false'
            ),
            'std'         => 'false',
            'heading'     => __( 'Loop', 'boutique' ),
            'param_name'  => 'loop',
            'description' => __( "Inifnity loop. Duplicate last and first items to get loop illusion.", 'boutique' ),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
		),
        array(
            "type"        => "kt_number",
            "heading"     => __("Slide Speed", 'boutique'),
            "param_name"  => "slidespeed",
            "value"       => "250",
            "suffix"      => __("milliseconds", 'boutique'),
            "description" => __('Slide speed in milliseconds', 'boutique'),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
	  	),
        array(
            "type"        => "kt_number",
            "heading"     => __("Margin", 'boutique'),
            "param_name"  => "margin",
            "value"       => "30",
            "suffix"      => __("px", 'boutique'),
            "description" => __('Distance( or space) between 2 item', 'boutique'),
            'group'       => __( 'Carousel settings', 'boutique' ),
            'admin_label' => false,
	  	),
        array(
            'type'  => 'dropdown',
            'value' => array(
                __( 'Yes', 'boutique' ) => 1,
                __( 'No', 'boutique' )  => 0
            ),
            'std'         => 1,
            'heading'     => __( 'Use Carousel Responsive', 'boutique' ),
            'param_name'  => 'use_responsive',
            'description' => __( "Try changing your browser width to see what happens with Items and Navigations", 'boutique' ),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
		),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on destop (Screen resolution of device >= 992px )", 'boutique'),
            "param_name"  => "items_destop",
            "value"       => "2",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The number of items on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
	  	),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on tablet (Screen resolution of device >=768px and < 992px )", 'boutique'),
            "param_name"  => "items_tablet",
            "value"       => "1",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The number of items on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
	  	),
        array(
            "type"        => "kt_number",
            "heading"     => __("The items on mobile (Screen resolution of device < 768px)", 'boutique'),
            "param_name"  => "items_mobile",
            "value"       => "1",
            "suffix"      => __("item", 'boutique'),
            "description" => __('The numbers of item on destop', 'boutique'),
            'group'       => __( 'Carousel responsive', 'boutique' ),
            'admin_label' => false,
	  	),
        array(
            'type'           => 'css_editor',
            'heading'        => __( 'Css', 'boutique' ),
            'param_name'     => 'css',
            // 'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'boutique' ),
            'group'          => __( 'Design options', 'boutique' ),
            'admin_label'    => false,
		),
        
    )
));

class WPBakeryShortCode_Blog_Carousel extends WPBakeryShortCode {
    protected function content($atts, $content = null) {
        $atts = function_exists( 'vc_map_get_attributes' ) ? vc_map_get_attributes( 'blog_carousel', $atts ) : $atts;
        extract( shortcode_atts( array(
            'title'          => __( 'Our BLog', 'boutique' ),
            
            'per_page'       => 10,
            'orderby'        => 'date',
            'order'          => 'desc',
            
            'style'          => 'style-1',
            //Carousel            
            'autoplay'       => 'false', 
            'navigation'     => 'false',
            'margin'         => 30,
            'slidespeed'     => 250,
            'css'            => '',
            'css_animation'  => '',
            'el_class'       => '',
            'loop'           => 'true',
            //Default
            'use_responsive' => 1,
            'items_destop'   => 2,
            'items_tablet'   => 1,
            'items_mobile'   => 1,
        ), $atts ) );
        
         global $woocommerce_loop;
        
        $elementClass = array(
            'base'             => apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, '', $this->settings['base'], $atts ),
            'extra'            => $this->getExtraClass( $el_class ),
            'css_animation'    => $this->getCSSAnimation( $css_animation ),
            'shortcode_custom' => vc_shortcode_custom_css_class( $css, ' ' )
        );
        
        $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), implode( ' ', $elementClass ) );
        
        $data_carousel = array(
            "autoplay"           => $autoplay,
            "nav"                => $navigation,
            "margin"             => $margin,
            "slidespeed"         => $slidespeed,
            "theme"              => 'style-navigation-bottom',
            "autoheight"         => 'false',
            'dots'               => 'false',
            'loop'               => $loop,
            'autoplayTimeout'    => 1000,
            'autoplayHoverPause' => 'true'
        );
        
        
        $args = array(
			'post_type'				=> 'post',
			'post_status'			=> 'publish',
			'ignore_sticky_posts'	=> 1,
			'posts_per_page' 		=> $per_page,
            'suppress_filter'       => true,
            'orderby'               => $orderby,
            'order'                 => $order
		);
        $posts = new WP_Query( apply_filters( 'woocommerce_shortcode_products_query', $args, $atts ) );
        
        ob_start();
        if( $posts->have_posts() ):
            if( $posts->post_count <= 1){
                $data_carousel['loop'] = 'false';
            }
            if( $use_responsive ){
                $arr = array( 
                    '0'   => array( 
                        "items" => $items_mobile 
                    ), 
                    '768' => array( 
                        "items" => $items_tablet 
                    ), 
                    '992' => array(
                        "items" => $items_destop
                    )
                );
                $data_responsive = json_encode($arr);
                $data_carousel["responsive"] = $data_responsive;
                
            }else{
                $data_carousel['items'] = $items_destop;
            }
        ?>
        <?php add_filter( 'excerpt_length', 'kt_custom_blog_excerpt_length' ); ?>
        <?php if( $style == 'style-1' ): ?>
            <div class="<?php echo esc_attr( $elementClass ) ?>">
        		<div class="lastest-blog nav-center-center nav-style7 owl-carousel" <?php echo _data_carousel($data_carousel); ?> >
        			<?php while( $posts->have_posts() ): $posts->the_post(); ?>
                        <div class="item-blog">
            				<div class="left">
            					<div class="blog-date">
            						<span class="day"><?php echo get_the_date('d');?></span>
            						<span class="month"><?php echo __('/', 'boutique' ) ?><?php echo get_the_date( 'M' );?></span><br />
            						<span class="year"><?php echo get_the_date('Y');?></span>
            					</div>
            					<h3 class="blog-title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
            					<div class="meta">
            						<span class="author"><?php echo get_the_author(); ?></span>
            						<span class="comment">
                                        <i class="fa fa-comment"></i> 
                                        <?php comments_number(
                                            __('0 Comment', 'boutique'),
                                            __('1 Comment', 'boutique'),
                                            __('% Comments', 'boutique')
                                        ); ?>
                                    </span>
            					</div>
            				</div>
                            <?php if( has_post_thumbnail() ): ?>
                				<div class="right">
                					<a class="banner-border" href="<?php the_permalink() ?>"><?php the_post_thumbnail( 'post-270x270', array() ); ?></a>
                				</div>
                            <?php else: ?>
                                <div class="right">
                                    <a class="banner-border" href="<?php the_permalink() ?>">
                                        <img width="auto" height="auto" src="<?php echo get_template_directory_uri() . '/images/post-placeholder-270x270.png'; ?>" alt="<?php the_title() ?>" />
                                    </a>
                                </div>
                            <?php endif; ?>
            			</div>
                    <?php endwhile; ?>
        		</div>
        	</div>
        <?php else: ?>
            <div class="lastest-blog style2 owl-carousel nav-style5" <?php echo _data_carousel($data_carousel); ?>>
            	<?php while( $posts->have_posts() ): $posts->the_post(); ?>
                    <div class="item-blog">
    					<div class="right">
                            <?php if( has_post_thumbnail() ): ?>
    						  <a href="<?php the_permalink() ?>"><?php the_post_thumbnail( 'kt-post-270x270' ) ?></a>
                            <?php else: ?>
                                <a href="<?php the_permalink() ?>">
                                    <img src="<?php echo get_template_directory_uri() . '/images/post-placeholder-270x270.png'; ?>" alt="<?php the_title() ?>" />
                                </a>
    						<?php endif; ?>
                            <div class="blog-date">
    							<span class="day"><?php echo get_the_date('d');?></span>
    							<span class="group">
    								<span class="month"><?php echo __('/', 'boutique' ) ?><?php echo get_the_date('M');?></span>
    								<span class="year"><?php echo get_the_date('Y');?></span>
    							</span>
    						</div>
    						<div class="left">
    							<h3 class="blog-title">
                                    <a href="<?php the_permalink() ?>"><?php the_title(); ?></a>
                                </h3>
    							<div class="meta">
    								<span class="author"><?php echo get_the_author(); ?></span>
    								<span class="comment"><i class="fa fa-comment"></i> 
                                        <?php comments_number(
                                            __('0 Comment', 'boutique'),
                                            __('1 Comment', 'boutique'),
                                            __('% Comments', 'boutique')
                                        ); ?>
                                    </span>
    							</div>
    						</div>
    					</div>
    				</div>
                <?php endwhile; ?>
			</div>
        <?php endif; ?>
        <?php remove_filter( 'excerpt_length', 'kt_custom_blog_excerpt_length' ); ?>  
        <?php
        endif;
        wp_reset_query();
        wp_reset_postdata();
        
        $result = ob_get_clean();
        return $result;
    }
}