<?php
if( ! function_exists( 'kt_footer' ) ){
    function kt_footer( $atts ) {
        $atts = shortcode_atts( array(
        	'id' => '',
            'el_class' => ''
        ),  $atts, 'kt_footer' );
        
        if( ! $atts[ 'id' ] || intval( $atts[ 'id' ] ) <= 0 ){
            $kt_footer_style = get_post_meta( get_the_ID(), 'kt_page_footer', '' );
            
            if( ! $kt_footer_style ){
                $kt_footer_style = kt_option( 'kt_footer_style' );
            }
        }else{
            $kt_footer_style = $atts[ 'id' ];
        }
        
        ob_start();
        if( $kt_footer_style ){
            $query = new WP_Query( array( 'p' => $kt_footer_style , 'post_type' => 'template', 'posts_per_page' => 1 ) );
            if( $query->have_posts() ):
                while( $query->have_posts() ): $query->the_post(); ?>
                    <?php 
                        // $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), $atts[ 'el_class' ] );
                        // $custom_css = get_post_meta( get_the_ID(), '_wpb_shortcodes_custom_css', true );
                        // wp_add_inline_style( 'custom-style-vc', $custom_css );
                        
                    ?>
                    <footer class="footer <?php echo esc_attr( $elementClass ); ?>">
                        <div class="container">
                            <?php the_content(); ?>
                        </div>
                    </footer>
                <?php endwhile;
            endif;
            wp_reset_postdata();
            wp_reset_query();
        }
        echo ob_get_clean();
    }
}
add_shortcode( 'kt_footer', 'kt_footer' );

if( ! function_exists( 'kt_header' ) ){
    function kt_header( $atts ) {
        $atts = shortcode_atts( array(
        	'id' => '',
            'el_class' => ''
        ),  $atts, 'kt_header' );
        
        
        ob_start();
        //Option header template file in page
        $kt_used_header = kt_get_post_meta( get_the_ID(), 'kt_page_header', '' );
        //Option header built in page
        $kt_header      = kt_get_post_meta( get_the_ID(), 'kt_header', '' );
        
        if( ! $atts[ 'id' ] || intval( $atts[ 'id' ] ) <= 0 ) {
            if( ! $kt_header ) {
                kt_theme_option_header_template( $kt_used_header, $atts );
            } else {
                kt_page_header_template( $kt_header, $kt_used_header, $atts );
            }
        }else{//Has ID
            kt_page_header_template( $atts[ 'id' ], $kt_used_header, $atts );
        }
        echo ob_get_clean();
    }
}
if( ! function_exists( 'kt_page_header_template' ) ){
    /**
     * kt_page_header_template
     * Header by id setting in page
     * 
     * @param $kt_footer_style id header is built
     * @param $kt_used_header file name template
     * */
    function kt_page_header_template( $kt_footer_style, $kt_used_header, $atts = array() ){
        $query = new WP_Query( array( 'p' => $kt_footer_style , 'post_type' => 'template', 'posts_per_page' => 1 ) );
        if( $query->have_posts() ):
            while( $query->have_posts() ): $query->the_post(); ?>
                <?php 
                    // $elementClass = preg_replace( array( '/\s+/', '/^\s|\s$/' ), array( ' ', '' ), $atts[ 'el_class' ] );
                    
                    // $custom_css = get_post_meta( get_the_ID(), '_wpb_shortcodes_custom_css', true );
                    // wp_add_inline_style( 'custom-style-vc', $custom_css );
                ?>
                
                <header id="header" class="header built-style <?php echo esc_attr( $elementClass ); ?>">
                    <div class="container">
                        <?php the_content(); ?>
                    </div>
                </header>
            <?php endwhile;
        else:
            kt_file_header_template( $kt_used_header );
        endif;
        wp_reset_postdata();
        wp_reset_query();
    }
}
if( ! function_exists( 'kt_theme_option_header_template' ) ){
    /**
     * kt_theme_option_header_template
     * Get Header by file header
     * 
     * @param $kt_used_header file id
     * */
    function kt_theme_option_header_template( $kt_used_header, $atts = array() ){
        if( ! $kt_used_header ) {
            //Option header built in theme option
            $kt_header_style = kt_option( 'kt_header_style', false );
            //Option header template file in theme option
            $kt_used_header = kt_option( 'kt_used_header', 1 );
            
            if( $kt_header_style  ) { 
               kt_page_header_template( $kt_header_style, $kt_used_header, $atts );
            } else {
                get_template_part( 'templates/headers/header',  $kt_used_header);
            }
        }else{
            //Has post meta template file
            get_template_part( 'templates/headers/header',  $kt_used_header);
        }
    }
}
    
add_shortcode( 'kt_header', 'kt_header' );


if ( !function_exists( 'kt_load_custom_css_header_footer' ) ){
    function kt_load_custom_css_header_footer(){
        $shortcodes_custom_css ='';
        $query = new WP_Query( array( 'post_type' => 'template') );
        if( $query->have_posts() ):
            while( $query->have_posts() ): $query->the_post(); ?>
                <?php 
                    
                    $shortcodes_custom_css.= get_post_meta( get_the_ID(), '_wpb_shortcodes_custom_css', true );
                ?>
            <?php endwhile;
        endif;
    
        if ( ! empty( $shortcodes_custom_css ) ) {
            $shortcodes_custom_css = strip_tags( $shortcodes_custom_css );
            echo '<style type="text/css" data-type="kt_template_shortcodes_custom_css">';
            echo $shortcodes_custom_css;
            echo '</style>';
        }
        wp_reset_postdata();
        wp_reset_query();
    }
}

add_action( 'wp_head','kt_load_custom_css_header_footer',100 );