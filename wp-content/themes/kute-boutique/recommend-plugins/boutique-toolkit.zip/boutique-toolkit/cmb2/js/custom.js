(function($){
    $('document').ready(function() {
        $(document).on('click','.kt_group_menu .arow',function(){
            $(this).closest('.kt_item_menu').toggleClass('show-submenu');
        });

        jQuery( '*[data-dependency="on"]' ).each(function(){
            var $this = jQuery( this );
            var equalval = $this.data( 'dval' ).split(',');
            var operator = $this.data( 'operator' );
            
            $row = $this.closest( '.cmb-row' );
            $parent = jQuery( '*[name="' + $this.data( 'did' ) +'"]' );
            if( $parent.attr( 'type' ) == 'radio' ){
                $radio = jQuery( '*[name="' + $this.data( 'did' ) +'"]:checked' );
                
                if( operator == 'equal' ){
                    if( jQuery.inArray( $radio.val(), equalval ) != -1 ){
                        $row.slideDown();
                    }else{
                        $row.slideUp();
                    }
                }else{
                    if( jQuery.inArray( $radio.val(), equalval ) == -1 ){
                        $row.slideDown();
                    }else{
                        $row.slideUp();
                    }
                }
                
            }else{
                if( operator == 'equal' ){
                    if( jQuery.inArray( $parent.val(), equalval ) != -1 ){
                        $row.slideDown();
                    }else{
                        $row.slideUp();
                    }
                }else{
                    if( jQuery.inArray( $parent.val(), equalval ) == -1 ){
                        $row.slideDown();
                    }else{
                        $row.slideUp();
                    }
                }
            }
            
            $parent.change( function() {
                var $e_parant = jQuery( this );
                var $row = jQuery( '*[data-did="' + $e_parant.attr( 'name' ) + '"]' ).closest( '.cmb-row' );
                $val = $e_parant.val();
                
                if( operator == 'equal' ){
                    if( jQuery.inArray( $val, equalval ) != -1 ){
                        $row.slideDown();
                    }else{
                        $row.slideUp();
                    }
                }else{
                    if( jQuery.inArray( $val, equalval ) == -1 ){
                        $row.slideDown();
                    }else{
                        $row.slideUp();
                    }
                }
            });
        });
    });
})(jQuery);