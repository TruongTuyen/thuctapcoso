<?php
$prefix = 'kt_';

$key    = 'kt_options';

global $wp_registered_sidebars;

$sidebars = array();

foreach ( $wp_registered_sidebars as $sidebar ) {
    $sidebars[ $sidebar['id'] ] = $sidebar['name'];
}
/**
 * Add new mimes for custom font upload
 */
if( ! function_exists( 'kt_upload_mimes' ) )
{
	function kt_upload_mimes( $existing_mimes=array() ){
		$existing_mimes['woff'] = 'font/woff';
		$existing_mimes['ttf'] 	= 'font/ttf';
		$existing_mimes['svg'] 	= 'font/svg';
		$existing_mimes['eot'] 	= 'font/eot';
		return $existing_mimes;
	}
}
add_filter('upload_mimes', 'kt_upload_mimes');

$config = array(
    //General
    $prefix . 'generals' => array(
        'title'   => 'General',
        'type'    => 'wrapper',
        'cmb'     => array (
            //Logo
            $prefix . 'logo_favicon' =>  array(
                'setting' => array(
                    'id'      => $prefix . 'logo_favicon',
                    'title'   => 'Logo & Favicon',
                    'hookup'  => false,
                    'show_on' => array(
                        // These are important, don't remove
                        'key'   => 'options-page',
                        'value' => array( $key )
                    )
                ),
                'fields'    => array(
                    array(
                        'name'    => __( 'Logo', 'boutique' ),
                        'id'      => 'kt_logo',
                        'type'    => 'file',
                        'desc'    => __( 'Setting your site\'s logo', 'boutique' ),
                    ),
                    array(
                        'name'    => __( 'Favicon', 'boutique' ),
                        'id'      => 'kt_favicon',
                        'type'    => 'file',
                        'desc'    => __( 'Setting your site\'s favicon', 'boutique' ),
                    )
                )
            ),
            //Color
            $prefix . 'theme_color' =>  array(
                'setting' => array(
                    'id'      => $prefix . 'theme_color',
                    'title'   => 'Theme Color',
                    'hookup'  => false,
                    'show_on' => array(
                        // These are important, don't remove
                        'key'   => 'options-page',
                        'value' => array( $key )
                    )
                ),
                'fields'    => array(
                    array(
                        'name'    => 'Main Color',
                        'id'      => 'kt_main_color',
                        'type'    => 'colorpicker',
                        'default' => '#c99947',
                    ),
                )
            ),
		)
    ),
    
    //Blogs
    $prefix . 'blog_settings' =>  array(
        'setting' => array(
            'id'      => $prefix . 'blog_settings',
            'title'   => 'Blog settings',
            'hookup'  => false,
            'show_on' => array(
                // These are important, don't remove
                'key'   => 'options-page',
                'value' => array( $key )
            )
        ),
        'fields'    => array(
            array(
                'name'    => __( 'Sidebar position', 'boutique' ),
                'id'      => 'kt_blog_layout',
                'type'    => 'radio_image',
                'desc'    => __( 'Setting sidebar postion.', 'boutique' ),
                'show_option_none' => 0,
                'default' => 'left',
                'options' => array(
                    'left'  => KUTETHEME_PLUGIN_URL .'/assets/images/2cl.png',
                    'right' => KUTETHEME_PLUGIN_URL .'/assets/images/2cr.png',
                    'full'  => KUTETHEME_PLUGIN_URL .'/assets/images/1column.png',
                )
            ),
            array(
                'name'    => __( 'Sidebar use for blog', 'boutique' ),
                'id'      => 'kt_blog_used_sidebar',
                'type'    => 'sidebar_select',
                'default' => 'sidebar-primary',
                'desc'    => __( 'Setting sidebar in the area sidebar', 'boutique' ),
                'dependency' => array(
                    'id'    => 'kt_blog_layout',
                    'value' => array( 'left', 'right' )
                )
            ),
            array(
                'name'    => 'Show placehold image',
                'id'      => 'kt_blog_placehold',
                'type'    => 'radio_inline',
                'default' =>'no',
                'options' => array(
                    'yes' => __( 'Yes', 'boutique' ),
                    'no'   => __( 'No', 'boutique' ),
                ),
            ),

            array(
                'name'    => __( 'Blog list style', 'boutique' ),
                'id'      => 'kt_blog_list_style',
                'type'    => 'radio_image',
                'desc'    => __( 'Setting display blog style.', 'boutique' ),
                'show_option_none' => 0,
                'default' => 'list',
                'options' => array(
                    'list'    => KUTETHEME_PLUGIN_URL .'/assets/images/blog-standard.jpg',
                    'grid'    => KUTETHEME_PLUGIN_URL .'/assets/images/blog-grid.png',
                    'masonry' => KUTETHEME_PLUGIN_URL .'/assets/images/blog-masonry.jpg',
                )
            ),
            array(
                'name'             => 'Blog columns',
                'id'               => 'kt_blog_list_columns',
                'type'             => 'select',
                'show_option_none' => true,
                'default'          => '3',
                'options'          => array(
                    '2' => __( '2 Columns', 'boutique' ),
                    '3' => __( '3 Columns', 'boutique' ),
                    '4' => __( '4 Columns', 'boutique' ),
                    '5' => __( '5 Columns', 'boutique' ),
                ),
                'dependency' => array(
                    'id'    => 'kt_blog_list_style',
                    'value' => array( 'grid', 'masonry' )
                )
            ),
            array(
                'name'    => 'Show About author',
                'id'      => 'kt_display_about_author',
                'type'    => 'radio_inline',
                'default' =>'yes',
                'options' => array(
                    'yes' => __( 'Yes', 'boutique' ),
                    'no'   => __( 'No', 'boutique' ),
                ),
            ),
            array(
                'name'    => 'Enable related post',
                'id'      => 'kt_enable_related_post',
                'type'    => 'radio_inline',
                'default' =>'yes',
                'options' => array(
                    'yes' => __( 'Yes', 'boutique' ),
                    'no'   => __( 'No', 'boutique' ),
                ),
            ),
            array(
                'name'    => 'Related posts per page',
                'id'      => 'kt_related_posts_per_page',
                'type'    => 'text',
                'default' =>'3',
                'dependency' => array(
                    'id'    => 'kt_enable_related_post',
                    'value' => array( 'yes' )
                )
            ),
            array(
                'name'    => __( 'Related posts columns', 'boutique' ),
                'id'      => 'kt_related_colums',
                'type'    => 'select',
                'show_option_none' => 0,
                'default' => '3',
                'options' => array(
                    '2'  => '2 Columns',
                    '3'  => '3 Columns',
                    '4'  => '4 Columns',
                    '6'  => '6 Columns'
                ),
                'dependency' => array(
                    'id'    => 'kt_enable_related_post',
                    'value' => array( 'yes' )
                )
            )
        )
    ),
    
    //Header
    $prefix . 'header' => array(
        'title'   => 'Header',
        'type'    => 'wrapper',
        
        'cmb'     => array (
            $prefix . 'default_header' => array(
                'setting' => array( 
                    'id'      => $prefix . 'default_header',
        			'hookup'  => false,
                    'title'   => 'General',
        			'show_on' => array(
        				// These are important, don't remove
        				'key'   => 'options-page',
        				'value' => array( $key )
        			) 
                ),
                'fields'    => array(
                    array(
                		'name'             => __( 'Header', 'boutique' ),
                		'id'               => 'kt_header_style',
                		'type'             => 'post_select',
                        'post_type'        => 'template',
                        'desc'             => __( 'Setting header style display', 'boutique' ),
                        'show_option_none' => __( 'Choose header', 'boutique'),
                	),
                    array(
                        'name'    => 'Header Sticky',
                        'id'      => 'kt_enable_sticky_header',
                        'type'    => 'radio_inline',
                        'default' =>'yes',
                        'options' => array(
                            'yes' => __( 'Yes', 'boutique' ),
                            'no'   => __( 'No', 'boutique' ),
                        ),
                    ),
                    array(
                		'name'    => __( 'Header', 'boutique' ),
                		'id'      => 'kt_used_header',
                		'type'    => 'radio_image',
                        'desc'    => __( 'Setting header style display', 'boutique' ),
                        'show_option_none' => 0,
                        'default' => '1',
                        'options' => array(
                			'1' => KUTETHEME_PLUGIN_URL .'/assets/images/v1.jpg',
                            '2' => KUTETHEME_PLUGIN_URL .'/assets/images/v2.jpg',
                            '3' => KUTETHEME_PLUGIN_URL .'/assets/images/v3.jpg',
                            '4' => KUTETHEME_PLUGIN_URL .'/assets/images/v4.jpg',
                            '5' => KUTETHEME_PLUGIN_URL .'/assets/images/v5.jpg',
                            '6' => KUTETHEME_PLUGIN_URL .'/assets/images/v6.jpg',
                            '7' => KUTETHEME_PLUGIN_URL .'/assets/images/v7.jpg',
                		),
                	)
                )
            ),
            $prefix . 'header_2' => array(
                'setting' => array( 
                    'id'      => $prefix . 'header_2',
        			'hookup'  => false,
                    'title'   => 'Header 2',
        			'show_on' => array(
        				// These are important, don't remove
        				'key'   => 'options-page',
        				'value' => array( $key )
        			) 
                ),
                'fields'    => array(
                    array(
                        'name' => __( 'Ads text', 'boutique' ),
                        'desc' => __( 'Display ads text only header style 2', 'boutique' ),
                        'id'   => 'kt_header_message',
                        'type' => 'textarea',
                    )
                )
            ),
            $prefix . 'header_3' => array(
                'setting' => array( 
                    'id'      => $prefix . 'header_3',
        			'hookup'  => false,
                    'title'   => 'Header 3',
        			'show_on' => array(
        				// These are important, don't remove
        				'key'   => 'options-page',
        				'value' => array( $key )
        			) 
                ),
                'fields'    => array(
                    array(
                        'name' => __( 'Slogan', 'boutique' ),
                        'desc' => __( 'Display slogan text only header style 3', 'boutique' ),
                        'id'   => 'kt_header_slogan',
                        'type' => 'textarea',
                    )
                )
            ),
            $prefix . 'header_5' => array(
                'setting' => array( 
                    'id'      => $prefix . 'header_5',
        			'hookup'  => false,
                    'title'   => 'Header 5',
        			'show_on' => array(
        				// These are important, don't remove
        				'key'   => 'options-page',
        				'value' => array( $key )
        			) 
                ),
                'fields'    => array(
                    array(
                        'name'             => 'Category Menu',
                        'id'               => 'kt_header_5_menu_cate',
                        'type'             => 'menu_select',
                        'show_option_none' => 'Choose Menu'
                    ),
                    array(
                        'name'    => 'Title Menu Category',
                        'id'      => 'kt_header_5_menu_title',
                        'type'    => 'text',
                        'dependency' => array(
                            'id'    => 'kt_header_5_menu_cate',
                            'value' => array( '' ),
                            'operator' => 'not_equal'
                        )
                    ),
                    array(
                        'name' => __( 'Subtitle Menu Category', 'boutique' ),
                        'desc' => __( 'Display subtitle of menu category', 'boutique' ),
                        'id'   => 'kt_header_5_menu_subtitle',
                        'type' => 'textarea',
                        'dependency' => array(
                            'id'    => 'kt_header_5_menu_cate',
                            'value' => array( '' ),
                            'operator' => 'not_equal'
                        )
                    ),
                    array(
                        'name'    => 'Depth Menu Category',
                        'id'      => 'kt_header_5_menu_depth',
                        'desc'    => '(integer)How many levels of the hierarchy are to be included. 1 means all. Default 1',
                        'type'    => 'numeric',
                        'default' => 1,
                        'dependency' => array(
                            'id'     => 'kt_header_5_menu_cate',
                            'value'  => array( '' ),
                            'operator' => 'not_equal'
                        )
                    ),
                    array(
                        'name'    => __( 'Background Menu Category', 'boutique' ),
                        'id'      => 'kt_header_5_menu_bg',
                        'type'    => 'file',
                        'desc'    => __( 'Setting your background menu category', 'boutique' ),
                        'dependency' => array(
                            'id'    => 'kt_header_5_menu_cate',
                            'value' => array( '' ),
                            'operator' => 'not_equal'
                        )
                    ),
                )
            ),
		),
    ),
    //Footer
    $prefix . 'footer' => array(
        'title'   => 'Footer',
        'type'    => 'wrapper',
        'cmb'     => array (
            $prefix . 'default_footer' => array(
                'setting' => array( 
                    'id'      => $prefix . 'default_footer',
        			'hookup'  => false,
                    'title'   => 'General',
        			'show_on' => array(
        				// These are important, don't remove
        				'key'   => 'options-page',
        				'value' => array( $key )
        			) 
                ),
                'fields'    => array(
                    array(
                		'name'             => __( 'Footer', 'boutique' ),
                		'id'               => 'kt_footer_style',
                		'type'             => 'post_select',
                        'post_type'        => 'template',
                        'desc'             => __( 'Setting footer style display', 'boutique' ),
                        'show_option_none' => __( 'Choose footer', 'boutique'),
                	),
                    array(
                		'name' => __( 'Copyrights', 'boutique' ),
                		'desc' => __( 'Copyrights your site', 'boutique' ),
                		'id'   => 'kt_copyrights',
                		'type' => 'textarea',
                	)
                )
            ),
            $prefix . 'footer_2' => array(
                'setting' => array( 
                    'id'      => $prefix . 'footer_2',
        			'hookup'  => false,
                    'title'   => 'Footer 2',
        			'show_on' => array(
        				// These are important, don't remove
        				'key'   => 'options-page',
        				'value' => array( $key )
        			) 
                ),
                'fields'    => array(
                     array(
                        'name'    => __( 'Footer Background', 'boutique' ),
                        'id'      => 'kt_footer_background',
                        'type'    => 'file',
                        'desc'    => __( 'Display Background on footer style 2', 'boutique' ),
                    ),
                    array(
                        'name'    => __( 'Footer Payment logo', 'boutique' ),
                        'id'      => 'kt_footer_payment_logo',
                        'type'    => 'file',
                        'desc'    => __( 'Display payment logo on footer style 2', 'boutique' ),
                    ),
                    array(
                        'name'    => __( 'Subscribe newsletter title', 'boutique' ),
                        'desc'    => __( 'Subscribe newsletter title display on footer style 2', 'boutique' ),
                        'id'      => 'kt_footer_subscribe_newsletter_title',
                        'type'    => 'text',
                        'default' => 'SIGN UP BELOW FOR EARLY UPDATES'
                    ),
                    array(
                        'name'    => __( 'Subscribe newsletter description', 'boutique' ),
                        'desc'    => __( 'Subscribe newsletter description display on footer style 2', 'boutique' ),
                        'id'      => 'kt_footer_subscribe_newsletter_description',
                        'type'    => 'text',
                        'default' => 'You a Client , large or small, and want to participate in this adventure, please send us an email to support@kuteshop.com'
                    )
                )
            ),
            $prefix . 'footer_4' => array(
                'setting' => array( 
                    'id'      => $prefix . 'footer_4',
                    'hookup'  => false,
                    'title'   => 'Footer 4, 5',
                    'show_on' => array(
                        // These are important, don't remove
                        'key'   => 'options-page',
                        'value' => array( $key )
                    ) 
                ),
                'fields'    => array(
                    array(
                        'name'    => __( 'Footer Payment logos', 'boutique' ),
                        'id'      => 'kt_footer_payment_logos',
                        'type'    => 'file_list',
                        'desc'    => __( 'Display payment logos on footer style 4, 5', 'boutique' ),
                        'options' => array(
                            'url' => false, // Hide the text input for the url
                            'add_upload_file_text' => 'Add payment images' // Change upload button text. Default: "Add or Upload File"
                        ),
                    ),
                )
            ),
		),
    ),
    //Woocommerce
    $prefix . 'woocommerce' => array(
        'title'   => 'Woocommerce',
        'type'    => 'wrapper',
        'cmb'     => array (
            $prefix . 'default_woocommerce' => array(
                'setting' => array( 
                    'id'      => $prefix . 'default_woocommerce',
                    'hookup'  => false,
                    'title'   => 'General',
                    'show_on' => array(
                        'key'   => 'options-page',
                        'value' => array( $key )
                    ) 
                ),
                'fields'    => array(
                    array(
                        'name'    => __( 'Number of days newness', 'boutique' ),
                        'id'      => 'kt_woo_newness',
                        'type'    => 'text',
                        'default' => '7',
                        'desc'    => __( 'Number of days to treat as new product', 'boutique' ),
                    ),
                    array(
                        'name'    => 'Use secondary image',
                        'id'      => 'kt_using_two_image',
                        'type'    => 'radio_inline',
                        'default' =>'yes',
                        'options' => array(
                            'yes' => __( 'Yes', 'boutique' ),
                            'no'   => __( 'No', 'boutique' ),
                        ),
                    ),
                    array(
                        'name'    => 'Short product name',
                        'id'      => 'kt_short_product_name',
                        'type'    => 'radio_inline',
                        'default' =>'yes',
                        'options' => array(
                            'yes' => __( 'Yes', 'boutique' ),
                            'no'   => __( 'No', 'boutique' ),
                        ),
                    ),
                    array(
                        'name'    => __( 'Product style', 'boutique' ),
                        'id'      => 'kt_woo_product_style',
                        'type'    => 'radio_image',
                        'default' => '1',
                        'options' => array(
                            '1' => KUTETHEME_PLUGIN_URL .'/assets/images/p1.png',
                            '2' => KUTETHEME_PLUGIN_URL .'/assets/images/p2.png',
                            '3' => KUTETHEME_PLUGIN_URL .'/assets/images/p3.png',
                            '4' => KUTETHEME_PLUGIN_URL .'/assets/images/p4.png',
                            '5' => KUTETHEME_PLUGIN_URL .'/assets/images/p5.png',
                        ),
                        'desc'    => __( 'Select a product style', 'boutique' )
                    ),
                    array(
                        'name'    => __( 'Flash Ion', 'boutique' ),
                        'id'      => 'kt_woo_flash_style',
                        'type'    => 'radio_image',
                        'default' => 'flash1',
                        'options' => array(
                            'flash1' => KUTETHEME_PLUGIN_URL .'/assets/images/flash1.png',
                            'flash2' => KUTETHEME_PLUGIN_URL .'/assets/images/flash2.png',
                        ),
                        'desc'    => __( 'Select a Flash icon style', 'boutique' )
                    ),
                )
            ),
            // Shop page
            $prefix . 'shop_page' => array(
                'setting' => array( 
                    'id'      => $prefix . 'shop_page',
                    'hookup'  => false,
                    'title'   => 'Shop Page',
                    'show_on' => array(
                        // These are important, don't remove
                        'key'   => 'options-page',
                        'value' => array( $key )
                    ) 
                ),
                'fields'    => array(
                    array(
                        'name'    => __( 'Shop layout', 'boutique' ),
                        'id'      => 'kt_woo_shop_layout',
                        'type'    => 'radio_image',
                        'default' => 'left',
                        'options' => array(
                            'left'  => KUTETHEME_PLUGIN_URL .'/assets/images/2cl.png',
                            'right' => KUTETHEME_PLUGIN_URL .'/assets/images/2cr.png',
                            'full'  => KUTETHEME_PLUGIN_URL .'/assets/images/1column.png',
                        ),
                        'desc'    => __( 'Setting layuout shop page', 'boutique' )
                    ),
                    array(
                        'name'    => __( 'Shop page sidebar', 'boutique' ),
                        'id'      => 'kt_woo_shop_used_sidebar',
                        'type'    => 'sidebar_select',
                        'default' => 'sidebar-shop',
                        'desc'    => __( 'Setting sidebar in the area sidebar on shop page', 'boutique' ),
                        'dependency' => array(
                            'id'    => 'kt_woo_shop_layout',
                            'value' => array( 'left','right' )
                        )
                    ),
                    array(
                        'name' => 'Page banners',
                        'desc' => '',
                        'id'   => 'kt_shop_banner',
                        'type' => 'file_list'
                    ),
                    array(
                        'name'    => __( 'Products perpage', 'boutique' ),
                        'id'      => 'kt_woo_products_perpage',
                        'type'    => 'text',
                        'default' => '12',
                        'desc'    => __( 'Number of products on shop page', 'boutique' ),
                    ),
                    array(
                        'name'    => __( 'Columns on Destop', 'boutique' ),
                        'id'      => 'kt_woo_grid_column',
                        'type'    => 'select',
                        'default' => '3',
                        'options' => array(
                            '2' => '2 Columns',
                            '3' => '3 Columns',
                            '4' => '4 Columns',
                        ),
                        'desc'    => __( '(Screen resolution of device >= 992px )', 'boutique' ),
                    ),
                    array(
                        'name'    => __( 'Columns on Tablet', 'boutique' ),
                        'id'      => 'kt_woo_ipad_grid_column',
                        'type'    => 'select',
                        'default' => '2',
                        'options' => array(
                            '2' => '2 Columns',
                            '3' => '3 Columns',
                            '4' => '4 Columns',
                        ),
                        'desc'    => __( '(Screen resolution of device >=768px and < 992px )', 'boutique' ),
                    ),
                    array(
                        'name'    => __( 'Columns on Mobile', 'boutique' ),
                        'id'      => 'kt_woo_mobile_grid_column',
                        'type'    => 'select',
                        'default' => '1',
                        'options' => array(
                            '1' => '1 Column',
                            '2' => '2 Columns',
                            '3' => '3 Columns',
                            '4' => '4 Columns',
                        ),
                        'desc'    => __( '(Screen resolution of device < 768px)', 'boutique' ),
                    ),
                ),
            ),
            // Single produuct
            $prefix . 'single_page' => array(
                'setting' => array( 
                    'id'      => $prefix . 'single_page',
                    'hookup'  => false,
                    'title'   => 'Single Product',
                    'show_on' => array(
                        // These are important, don't remove
                        'key'   => 'options-page',
                        'value' => array( $key )
                    ) 
                ),
                'fields'    => array(
                    array(
                        'name'    => __( 'Shop layout', 'boutique' ),
                        'id'      => 'kt_woo_single_layout',
                        'type'    => 'radio_image',
                        'default' => 'left',
                        'options' => array(
                            'left'  => KUTETHEME_PLUGIN_URL .'/assets/images/2cl.png',
                            'right' => KUTETHEME_PLUGIN_URL .'/assets/images/2cr.png',
                            'full'  => KUTETHEME_PLUGIN_URL .'/assets/images/1column.png',
                        ),
                        'desc'    => __( 'Setting layuout shop page', 'boutique' )
                    ),

                    array(
                        'name'    => __( 'Page sidebar', 'boutique' ),
                        'id'      => 'kt_woo_single_used_sidebar',
                        'type'    => 'sidebar_select',
                        'default' => 'sidebar-shop',
                        'desc'    => __( 'Setting sidebar in the area sidebar on shop page', 'boutique' ),
                        'dependency' => array(
                            'id'    => 'kt_woo_single_layout',
                            'value' => array( 'left','right' )
                        )
                    ),
                    array(
                        'name' => 'Page banners',
                        'desc' => '',
                        'id'   => 'kt_shop_single_banner',
                        'type' => 'file_list'
                    ),
                    array(
                        'name'    => 'Use Thumbnail slide',
                        'id'      => 'kt_enable_product_thumb_slide',
                        'type'    => 'radio_inline',
                        'default' =>'yes',
                        'options' => array(
                            'yes' => __( 'Yes', 'boutique' ),
                            'no'   => __( 'No', 'boutique' ),
                        ),
                    ),
                )
            ),
            // Related products
            $prefix . 'related_products' => array(
                'setting' => array( 
                    'id'      => $prefix . 'related_products',
                    'hookup'  => false,
                    'title'   => 'Related Products',
                    'show_on' => array(
                        // These are important, don't remove
                        'key'   => 'options-page',
                        'value' => array( $key )
                    ) 
                ),
                'fields'    => array(
                    array(
                        'name'  => 'Title',
                        'desc'  => '',
                        'id'    => 'kt_related_products_title',
                        'type'  => 'text',
                        'default' => 'Related Products'
                    ),
                    array(
                        'name'    => 'Products perpage',
                        'desc'    => '',
                        'id'      => 'kt_related_products_perpage',
                        'type'    => 'text',
                        'default' => 4
                    ),
                    array(
                        'name'    => __( 'Grid column', 'boutique' ),
                        'id'      => 'kt_related_products_columns',
                        'type'    => 'select',
                        'default' => '3',
                        'options' => array(
                            '2' => '2 Columns',
                            '3' => '3 Columns',
                            '4' => '4 Columns',
                        ),
                        'desc'    => __( 'Number column to display width gird mod', 'boutique' ),
                    ),
                )
            ),
            // Upsell products
            $prefix . 'upsell_products' => array(
                'setting' => array( 
                    'id'      => $prefix . 'upsell_products',
                    'hookup'  => false,
                    'title'   => 'Up sell Products',
                    'show_on' => array(
                        // These are important, don't remove
                        'key'   => 'options-page',
                        'value' => array( $key )
                    ) 
                ),
                'fields'    => array(
                    array(
                        'name'  => 'Title',
                        'desc'  => '',
                        'id'    => 'kt_upsell_products_title',
                        'type'  => 'text',
                        'default' => 'You may also like...'
                    ),
                    array(
                        'name'    => __( 'Grid column', 'boutique' ),
                        'id'      => 'kt_upsell_products_columns',
                        'type'    => 'select',
                        'default' => '3',
                        'options' => array(
                            '2' => '2 Columns',
                            '3' => '3 Columns',
                            '4' => '4 Columns',
                        ),
                        'desc'    => __( 'Number column to display width gird mod', 'boutique' ),
                    ),
                )
            ),
            // Cross-Sells
            $prefix . 'cross_sells' => array(
                'setting' => array( 
                    'id'      => $prefix . 'cross_sells',
                    'hookup'  => false,
                    'title'   => 'Cross Sells',
                    'show_on' => array(
                        // These are important, don't remove
                        'key'   => 'options-page',
                        'value' => array( $key )
                    ) 
                ),
                'fields'    => array(
                    array(
                        'name'  => 'Title',
                        'desc'  => '',
                        'id'    => 'kt_cross_sells_products_title',
                        'type'  => 'text',
                        'default' => 'You may be interested in…'
                    ),
                    array(
                        'name'    => __( 'Grid column', 'boutique' ),
                        'id'      => 'kt_cross_sells_products_columns',
                        'type'    => 'select',
                        'default' => '3',
                        'options' => array(
                            '2' => '2 Columns',
                            '3' => '3 Columns',
                            '4' => '4 Columns',
                        ),
                        'desc'    => __( 'Number column to display width gird mod', 'boutique' ),
                    ),
                )
            )      
        )
    ),
    //Font Family
  //   $prefix . 'fonts_family' => array(
  //       'title'   => 'Font Family',
  //       'type'    => 'wrapper',
        
  //       'cmb'     => array (
  //           $prefix . 'fonts_family' => array(
  //               'setting' => array( 
  //                   'id'      => $prefix . 'fonts_family',
  //       			'hookup'  => false,
  //                   'title'   => 'Fonts',
  //       			'show_on' => array(
  //       				// These are important, don't remove
  //       				'key'   => 'options-page',
  //       				'value' => array( $key )
  //       			) 
  //               ),
  //               'fields'    => array(
  //                   array(
  //               		'name'    => __( 'Content', 'boutique' ),
  //               		'id'      => 'font_content',
  //               		'type'    => 'font_select',
  //               		'default' => 'Roboto',
  //                       'desc'    => __( 'All theme texts except headings and menu', 'boutique' ),
  //               	),
  //                   array(
  //               		'name'    => __( 'Main Menu', 'boutique' ),
  //               		'id'      => 'font_menu',
  //               		'type'    => 'font_select',
  //               		'default' => 'Roboto',
  //                       'desc'    => __( 'Header menu', 'boutique' ),
  //               	),
  //                   array(
  //               		'name'    => __( 'Page Title', 'boutique' ),
  //               		'id'      => 'font_title',
  //               		'type'    => 'font_select',
  //               		'default' => 'Roboto',
  //                       'desc'    => __( 'The title of page', 'boutique' ),
  //               	),
  //                   array(
  //               		'name'    => __( 'Big Headings', 'boutique' ),
  //               		'id'      => 'font_headings',
  //               		'type'    => 'font_select',
  //               		'default' => 'Roboto',
  //                       'desc'    => __( 'H1, H2, H3 & H4 headings', 'boutique' ),
  //               	),
  //                   array(
  //               		'name'    => __( 'Small Headings', 'boutique' ),
  //               		'id'      => 'font_headings_small',
  //               		'type'    => 'font_select',
  //               		'default' => 'Roboto',
  //                       'desc'    => __( 'H5 & H6 headings', 'boutique' ),
  //               	),
                    
  //                   array(
  //               		'name'    => __( 'Blockquote', 'boutique' ),
  //               		'id'      => 'font_blockquote',
  //               		'type'    => 'font_select',
  //               		'default' => 'Roboto'
  //               	),
  //                   array(
  //               		'name'    => __( 'Decorative', 'boutique' ),
  //               		'id'      => 'font_decorative',
  //               		'type'    => 'font_select',
  //               		'default' => 'Roboto',
  //                       'desc'    => __( 'Digits in some items, eg. Chart Box, Counter, How it Works, Quick Fact, Single Product Price', 'boutique' ),
  //               	)
  //               )
  //           ),
  //           $prefix . 'font_weight' => array(
  //               'setting' => array( 
  //                   'id'      => $prefix . 'font_weight',
  //       			'hookup'  => false,
  //                   'title'   => 'Font Weight',
  //       			'show_on' => array(
  //       				// These are important, don't remove
  //       				'key'   => 'options-page',
  //       				'value' => array( $key )
  //       			) 
  //               ),
  //               'fields'    => array(
  //                   array(
  //   					'id' 		=> 'font_weight',
  //   					'type' 		=> 'multicheck',
  //   					'name' 	=> __('Google Fonts Style & Weight', 'boutique'),
  //   					'desc' 		=> __('Some of the fonts in the Google Fonts Directory support multiple styles. For a complete list of available font subsets please see <a href="http://www.google.com/webfonts" target="_blank">Google Web Fonts</a>.', 'boutique'),
  //   					'options' 	=> array(
  //   						'100'		=> '100 Thin',
  //   						'100italic'	=> '100 Thin Italic',
  //   						'200'		=> '200 Extra-Light',
  //   						'200italic'	=> '200 Extra-Light Italic',
  //   						'300'		=> '300 Light',
  //   						'300italic'	=> '300 Light Italic',
  //   						'400'		=> '400 Regular',
  //   						'400italic'	=> '400 Regular Italic',
  //   						'500'		=> '500 Medium',
  //   						'500italic'	=> '500 Medium Italic',
  //   						'600'		=> '600 Semi-Bold',
  //   						'600italic'	=> '600 Semi-Bold Italic',
  //   						'700'		=> '700 Bold',
  //   						'700italic'	=> '700 Bold Italic',
  //   						'800'		=> '800 Extra-Bold',
  //   						'800italic'	=> '800 Extra-Bold Italic',
  //   						'900'		=> '900 Black',
  //   						'900italic'	=> '900 Black Italic',
  //   					),
  //   					'class'		=> 'float-left',
  //   				),	
    
  //   				array(
  //   					'id' 		=> 'font_subset',
  //   					'type' 		=> 'text',
  //   					'name' 	=> __('Google Fonts Subset', 'boutique'),
  //                       'desc' 		=> __('Some of the fonts in the Google Fonts Directory support multiple scripts (like Latin and Cyrillic for example). For a complete list of available font subsets please see <a href="http://www.google.com/webfonts" target="_blank">Google Web Fonts</a>.', 'boutique'),
  //   					'class' 	=> 'small-text'
  //   				)
  //               )
  //           ),
  //           $prefix . 'font_custom' => array(
  //               'setting' => array( 
  //                   'id'      => $prefix . 'font_custom',
  //       			'hookup'  => false,
  //                   'title'   => 'Font Custom',
  //       			'show_on' => array(
  //       				// These are important, don't remove
  //       				'key'   => 'options-page',
  //       				'value' => array( $key )
  //       			) 
  //               ),
  //               'fields'    => array(
  //                   array(
  //               		'name' => __( 'Font | Name', 'boutique' ),
  //               		'desc' => __( 'Name for Custom Font uploaded below. Font will show on fonts list after click the Save Changes button.', 'boutique' ),
  //               		'id'   => 'font_custom_name',
  //               		'type' => 'text',
  //               	),
  //                   array(
  //                       'name'    => 'Font | .woff',
  //                       'id'      => 'font_custom_woff',
  //                       'type'    => 'file',
  //                       // Optional:
  //                       'options' => array(
  //                           'url' => true, // Hide the text input for the url
  //                           'add_upload_file_text' => 'Add Font .woff' // Change upload button text. Default: "Add or Upload File"
  //                       ),
  //                   ),
  //                   array(
  //                       'name'    => 'Font | .ttf',
  //                       'id'      => 'font_custom_ttf',
  //                       'type'    => 'file',
  //                       // Optional:
  //                       'options' => array(
  //                           'url' => true, // Hide the text input for the url
  //                           'add_upload_file_text' => 'Add Font .ttf' // Change upload button text. Default: "Add or Upload File"
  //                       ),
  //                   ),
  //                   array(
  //                       'name'    => 'Font | .svg',
  //                       'id'      => 'font_custom_svg',
  //                       'type'    => 'file',
  //                       // Optional:
  //                       'options' => array(
  //                           'url' => true, // Hide the text input for the url
  //                           'add_upload_file_text' => 'Add Font .svg' // Change upload button text. Default: "Add or Upload File"
  //                       ),
  //                   ),
  //                   array(
  //                       'name'    => 'Font | .eot',
  //                       'id'      => 'font_custom_eot',
  //                       'type'    => 'file',
  //                       // Optional:
  //                       'options' => array(
  //                           'url' => true, // Hide the text input for the url
  //                           'add_upload_file_text' => 'Add Font .eot' // Change upload button text. Default: "Add or Upload File"
  //                       ),
  //                   ),
  //                   array(
  //               		'name' => __( 'Font 2 | Name', 'boutique' ),
  //               		'desc' => __( 'Name for Custom Font uploaded below. Font will show on fonts list after click the Save Changes button.', 'boutique' ),
  //               		'id'   => 'font_custom2_name',
  //               		'type' => 'text',
  //               	),
  //                   array(
  //                       'name'    => 'Font 2 | .woff',
  //                       'id'      => 'font_custom2_woff',
  //                       'type'    => 'file',
  //                       // Optional:
  //                       'options' => array(
  //                           'url' => true, // Hide the text input for the url
  //                           'add_upload_file_text' => 'Add Font 2 .woff' // Change upload button text. Default: "Add or Upload File"
  //                       ),
  //                   ),
  //                   array(
  //                       'name'    => 'Font 2 | .ttf',
  //                       'id'      => 'font_custom2_ttf',
  //                       'type'    => 'file',
  //                       // Optional:
  //                       'options' => array(
  //                           'url' => true, // Hide the text input for the url
  //                           'add_upload_file_text' => 'Add Font 2 .ttf' // Change upload button text. Default: "Add or Upload File"
  //                       ),
  //                   ),
  //                   array(
  //                       'name'    => 'Font 2 | .svg',
  //                       'id'      => 'font_custom2_svg',
  //                       'type'    => 'file',
  //                       // Optional:
  //                       'options' => array(
  //                           'url' => true, // Hide the text input for the url
  //                           'add_upload_file_text' => 'Add Font 2 .svg' // Change upload button text. Default: "Add or Upload File"
  //                       ),
  //                   ),
  //                   array(
  //                       'name'    => 'Font 2 | .eot',
  //                       'id'      => 'font_custom2_eot',
  //                       'type'    => 'file',
  //                       // Optional:
  //                       'options' => array(
  //                           'url' => true, // Hide the text input for the url
  //                           'add_upload_file_text' => 'Add Font 2 .eot' // Change upload button text. Default: "Add or Upload File"
  //                       ),
  //                   )
  //               )
  //           )
            
		// ),
  //   ),
    //Social
    $prefix . 'social' =>  array(
        'setting' => array(
            'id'      => $prefix . 'social',
            'title'   => 'Socials',
    		'hookup'  => false,
    		'show_on' => array(
    			// These are important, don't remove
    			'key'   => 'options-page',
    			'value' => array( $key )
            )
		),
        'fields'    => array(
            array(
        		'name' => __( 'Addthis ID', 'boutique' ),
        		'desc' => __( 'Setting id addthis', 'boutique' ),
        		'id'   => 'kt_addthis_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Facebook Link', 'boutique' ),
        		'desc' => __( 'Setting id facebook link', 'boutique' ),
        		'id'   => 'kt_facebook_link_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Twitter', 'boutique' ),
        		'desc' => __( 'Your twitter username', 'boutique' ),
        		'id'   => 'kt_twitter_link_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Pinterest', 'boutique' ),
        		'desc' => __( 'Your pinterest username', 'boutique' ),
        		'id'   => 'kt_pinterest_link_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Dribbble', 'boutique' ),
        		'desc' => __( 'Your dribbble username', 'boutique' ),
        		'id'   => 'kt_dribbble_link_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Vimeo', 'boutique' ),
        		'desc' => __( 'Your vimeo username', 'boutique' ),
        		'id'   => 'kt_vimeo_link_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Tumblr Link', 'boutique' ),
        		'desc' => __( 'Your tumblr username', 'boutique' ),
        		'id'   => 'kt_tumblr_link_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Skype', 'boutique' ),
        		'desc' => __( 'Your skype username', 'boutique' ),
        		'id'   => 'kt_skype_link_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'LinkedIn Link', 'boutique' ),
        		'desc' => __( 'Setting id linkedIn link', 'boutique' ),
        		'id'   => 'kt_linkedIn_link_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Vk', 'boutique' ),
        		'desc' => __( 'Your vk id', 'boutique' ),
        		'id'   => 'kt_vk_link_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Google+ Link', 'boutique' ),
        		'desc' => __( 'Setting id Google+ link', 'boutique' ),
        		'id'   => 'kt_google_plus_link_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Google+ Link', 'boutique' ),
        		'desc' => __( 'Setting id Google+ link', 'boutique' ),
        		'id'   => 'kt_google_plus_link_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Youtube', 'boutique' ),
        		'desc' => __( 'Your youtube username', 'boutique' ),
        		'id'   => 'kt_youtube_link_id',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Instagram', 'boutique' ),
        		'desc' => __( 'Your instagram username', 'boutique' ),
        		'id'   => 'kt_instagram_link_id',
        		'type' => 'text',
        	)
        )
    ),
    //CSS
    $prefix . 'stylesheet_js' =>  array(
        'setting' => array(
            'id'      => $prefix . 'stylesheet_js',
            'title'   => 'Custom JS/CSS',
    		'hookup'  => false,
    		'show_on' => array(
    			// These are important, don't remove
    			'key'   => 'options-page',
    			'value' => array( $key )
            )
		),
        'fields'    => array(
            array(
        		'name' => __( 'Custom CSS', 'boutique' ),
        		'desc' => __( 'Add css in your site', 'boutique' ),
        		'id'   => 'kt_custom_css',
        		'type' => 'ace_editer_css',
        	),
            array(
                'name' => __( 'Custom JS', 'boutique' ),
                'desc' => __( 'Add js in your site', 'boutique' ),
                'id'   => 'kt_custom_js',
                'type' => 'ace_editer_js',
            ),
        )
    ),
    
    //Infomation
    $prefix . 'infomation' =>  array(
        'setting' => array(
            'id'      => $prefix . 'infomation',
            'title'   => 'Info',
    		'hookup'  => false,
    		'show_on' => array(
    			// These are important, don't remove
    			'key'   => 'options-page',
    			'value' => array( $key )
            )
		),
        'fields'    => array(
            array(
        		'name' => __( 'Address', 'boutique' ),
        		'desc' => __( 'Setting address for your site', 'boutique' ),
        		'id'   => 'kt_address',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Phone', 'boutique' ),
        		'desc' => __( 'Setting hotline for your site', 'boutique' ),
        		'id'   => 'kt_phone',
        		'type' => 'text',
        	),
            array(
        		'name' => __( 'Email', 'boutique' ),
        		'desc' => __( 'Setting email for your site', 'boutique' ),
        		'id'   => 'kt_email',
        		'type' => 'text',
        	)
        )
    )
);
return $config;