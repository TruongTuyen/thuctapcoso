<?php
/*
Plugin Name: Boutique Toolkit
Plugin URI: http://kutethemes.com/demo/kuteshop/
Description: A Toolkit for Boutique theme
Version: 1.0.0
Author: KuteTheme
Author URI: http://kutethemes.com/
Text Domain: boutique
@package Boutique toolkit
@author KuteTheme
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
require_once plugin_dir_path(__FILE__) .'global.php';

add_action( 'plugins_loaded', function(){
    define("KUTETHEME_PLUGIN_PATH", trailingslashit( plugin_dir_path(__FILE__) ) );
    define("KUTETHEME_PLUGIN_URL", trailingslashit( plugin_dir_url(__FILE__) ) );
    
    if( ! defined( 'THEME_DIR' ) ) {
        define( 'THEME_DIR', trailingslashit(get_template_directory()));
    }
    if( ! defined( 'THEME_URL' ) ) {
        define( 'THEME_URL', trailingslashit(get_template_directory_uri()));
    }
    
    
    // ADD PAGE MENU
    add_action( 'admin_menu', 'kt_register_my_theme_menu_page' );
    
    function kt_register_my_theme_menu_page(){
        add_menu_page( 'Boutique', 'Boutique', 'manage_options', 'kt_capnel_page', 'kt_backend_wellcome', KUTETHEME_PLUGIN_URL.'assets/images/menu-icon.png', 1 ); 
    }
    
    function kt_backend_wellcome(){
        ?>
        <h1><?php _e('Wellcome to Boutique Theme','boutique');?></h1>
        <?php
        $file = get_template_directory().'/changelog.txt';
        if( file_exists( $file ) ){
            ?>
            <h3><?php _e('Change Log','boutique');?></h3>
            <div style="height: 200px; overflow: auto;">
                <?php
                $myfile = fopen($file, "r") or die("Unable to open file!");
                // Output one line until end-of-file
                while(!feof($myfile)) {
                  echo fgets($myfile) . "<br>";
                }
                fclose($myfile);
                ?>
            </div>
            <?php
            
        }
    }
    
    if( ! function_exists( 'kt_enqueue_assets' ) ){
        function kt_enqueue_assets(){
            wp_enqueue_style(
        		"custom-style-vc", KUTETHEME_PLUGIN_URL . "assets/css/style.css"
        	);
        }
        
    }
    //add_action( 'wp_head', 'kt_enqueue_assets' );

    /* ---------------------------------------------------------------------------
     * SSL | Compatibility
     * --------------------------------------------------------------------------- */
    if( ! function_exists( 'kt_ssl' ) ){
    	function kt_ssl( $echo = false ){
    		$ssl = '';
    		if( is_ssl() ) $ssl = 's';
    		if( $echo ){
    			echo $ssl;
    		}
    		return $ssl;
    	}
    }
    if( ! function_exists('kt_check_active_plugin') ){
        function kt_check_active_plugin( $key ){
            $active_plugins = (array) get_option( 'active_plugins', array() );
            
    		if ( is_multisite() ){
    		  $active_plugins = array_merge( $active_plugins, get_site_option( 'active_sitewide_plugins', array() ) ); 
    		}
            return in_array( $key, $active_plugins ) || array_key_exists( $key, $active_plugins );
        }
    }
    
    if ( ! function_exists( 'kt_option' ) ){
        function kt_option( $option = false, $default = false ){
            if($option === FALSE){
                return FALSE;
            }
            
            $option_name = apply_filters('theme_option_name', 'kt_options' );
            
            $kt_options  = wp_cache_get( $option_name );
            if(  ! $kt_options ){
                $kt_options = get_option( $option_name );
                if( empty($kt_options)  ){
                    // get default theme option
                    if( defined( 'ICL_LANGUAGE_CODE' ) ){
                        $kt_options = get_option( 'kt_options' );
                    }
                }
                wp_cache_delete( $option_name );
                wp_cache_add( $option_name, $kt_options );
            }
            if(isset($kt_options[$option]) && $kt_options[$option] !== ''){
                return $kt_options[$option];
            }else{
                return $default;
            }
        }
    }
    
    
    if( ! function_exists( 'kt_fonts_selected' ) )
    {
    	function kt_fonts_selected(){
    		$fonts = array();
    		
    		$fonts['content'] 		= kt_option( 'font_content', 		'Roboto' );
    		$fonts['menu'] 			= kt_option( 'font_menu', 			'Roboto' );
    		$fonts['title'] 		= kt_option( 'font_title', 			'Roboto' );
    		$fonts['headings'] 		= kt_option( 'font_headings', 		'Roboto' );
    		$fonts['headingsSmall'] = kt_option( 'font_headings_small', 'Roboto' );
    		$fonts['blockquote'] 	= kt_option( 'font_blockquote', 	'Roboto' );
    		$fonts['decorative'] 	= kt_option( 'font_decorative', 	'Roboto' );
    		
    		return $fonts;
    	}
    }
    if( ! function_exists( 'kt_google_fonts' ) ){
        function kt_google_fonts(){
            // Google Fonts --------------------
    		$google_fonts 	= kt_fonts( 'all' );
    		
    		// subset
    		$subset 		= kt_option('font_subset');
    		if( $subset ) $subset = '&amp;subset='. str_replace(' ', '', $subset);
    		
    		// style & weight
    		if( $weight = kt_option('font_weight') ){
    			$weight = ':'. implode( ',', $weight );	
    		}
    	
    		$fonts = kt_fonts_selected();
    		foreach( $fonts as $font ){
    			
    			if( in_array( $font, $google_fonts ) ){
    				
    				// Google Fonts
    				$font_slug = str_replace(' ', '+', $font);
    				wp_enqueue_style( $font_slug, 'http'. kt_ssl() .'://fonts.googleapis.com/css?family='. $font_slug . $weight . $subset );	
    			
    			}
    		}
        }
        
    }
    add_action( 'wp_enqueue_scripts', 'kt_google_fonts' );

    /* LOAD FONT ICON*/
    function kt_custom_font_icons(){
        wp_enqueue_style( 'kt-pe-icon-7-stroke', get_template_directory_uri() . '/css/pe-icon-7-stroke.css');
    }
    add_action('admin_enqueue_scripts', 'kt_custom_font_icons');
    /* --------------------
     * Styles | Custom Font
     * -------------------- */
    if( ! function_exists( 'kt_styles_custom_font' ) )
    {
    	function kt_styles_custom_font()
    	{
    		$font_custom  = kt_option( 'font_custom_name' );
    		$font_custom2 = kt_option( 'font_custom2_name' );
    	
    		if( $font_custom ){
    			echo '<!-- style | custom font -->'."\n";
    			echo '<style>'."\n\t";
    				echo '@font-face {'."\n\t\t";
    					echo 'font-family: "'. $font_custom .'";'."\n\t\t";
    					echo 'src: url("'. kt_option('font_custom_eot') .'");'."\n\t\t";
    					echo 'src: url("'. kt_option('font_custom_eot') .'#iefix") format("embedded-opentype"),'."\n\t\t\t";
    						echo 'url("'. kt_option('font_custom_woff') .'") format("woff"),'."\n\t\t\t";
    						echo 'url("'. kt_option('font_custom_ttf') .'") format("truetype"),'."\n\t\t\t";
    						echo 'url("'. kt_option('font_custom_svg') .'#'. $font_custom .'") format("svg");'."\n\t\t";
    					echo 'font-weight: normal;'."\n\t\t";
    					echo 'font-style: normal;'."\n\t";
    				echo '}'."\n";
    			echo '</style>'."\n";
    		}
    		
    		if( $font_custom2 ){
    			echo '<!-- style | custom font 2 -->'."\n";
    			echo '<style>'."\n";
    				echo '@font-face {'."\n\t\t";
    					echo 'font-family: "'. $font_custom2 .'";'."\n\t\t";
    					echo 'src: url("'. kt_option('font_custom2_eot') .'");'."\n\t\t";
    					echo 'src: url("'. kt_option('font_custom2_eot') .'#iefix") format("embedded-opentype"),'."\n\t\t\t";
    						echo 'url("'. kt_option('font_custom2_woff') .'") format("woff"),'."\n\t\t\t";
    						echo 'url("'. kt_option('font_custom2_ttf') .'") format("truetype"),'."\n\t\t\t";
    						echo 'url("'. kt_option('font_custom2_svg') .'#'. $font_custom2 .'") format("svg");'."\n\t\t";
    					echo 'font-weight: normal;'."\n\t\t";
    					echo 'font-style: normal;'."\n\t";
    				echo '}'."\n";
    			echo '</style>'."\n";
    		}
    	}
    }
    add_action('wp_head', 'kt_styles_custom_font');
    /**
     * Render data option for carousel
     * 
     * @param $data array. All data for carousel
     * 
     */
    if( ! function_exists( '_data_carousel' ) ){
        function _data_carousel( $data ){
            $output = "";
            foreach($data as $key => $val){
                if($val){
                    $output .= ' data-'.$key.'="'.esc_attr( $val ).'"';
                }
            }
            return $output;
        }
    }
    if( ! function_exists('kt_get_all_attributes') ){
        function kt_get_all_attributes( $tag, $text ) {
            preg_match_all( '/' . get_shortcode_regex() . '/s', $text, $matches );
            $out = array();
            if( isset( $matches[2] ) )
            {
                foreach( (array) $matches[2] as $key => $value )
                {
                    if( $tag === $value )
                        $out[] = shortcode_parse_atts( $matches[3][$key] );  
                }
            }
            return $out;
        }
    }
    if( ! function_exists( 'kt_custom_blog_excerpt_length' ) ){
        function kt_custom_blog_excerpt_length(){
            return 23;
        }
    }
    /**
     * Get Option settings file config
     *
     * Override template in your theme
     * YOUR_THEME_DIR/settings/options.php
     * YOUR_THEME_DIR/inc/options.php
     * YOUR_THEME_DIR/includes/options.php
     * YOUR_THEME_DIR/admin/options.php
     *
     * @since 1.0
     * @param string file path
     * @return string|bool
     */
    if( ! function_exists( 'kt_get_file_config' ) ){
        function kt_get_file_config( $file_config = '' ) {
            // If neither the child nor parent theme have overridden the template,
            // we load the template from the 'templates' directory if this plugin
            $file =  KUTETHEME_PLUGIN_PATH.'settings/'.$file_config.'.php';
            return ( is_file( $file ) ) ?  $file : false ;
        }
    }
    
    
    load_plugin_textdomain( 'kutetheme', false, plugin_basename( dirname( __FILE__ ) ) . "/languages" );
    
    
    //CMB2
    if( is_admin() ){
        require_once KUTETHEME_PLUGIN_PATH .'cmb2/init.php';
        require_once KUTETHEME_PLUGIN_PATH .'option_post_type.php';
        require_once KUTETHEME_PLUGIN_PATH .'cmb2/admin.php';
    }
    
    
    // Post types
    require_once KUTETHEME_PLUGIN_PATH .'post-types/post-types.php';
    
    /**
     * Initialising Visual Composer
     * 
     */ 
    if ( kt_check_active_plugin( 'js_composer/js_composer.php' ) ) {
        
        if ( ! function_exists( 'js_composer_bridge_admin' ) ) {
    		function js_composer_bridge_admin( $hook ) {
    			wp_enqueue_style( 'js_composer_bridge', KUTETHEME_PLUGIN_URL . 'js_composer/css/style.css', array() );
    		}
    	}
        add_action( 'admin_enqueue_scripts', 'js_composer_bridge_admin', 15 );
        
        require_once KUTETHEME_PLUGIN_PATH.'js_composer/visualcomposer.php';
        require_once KUTETHEME_PLUGIN_PATH.'js_composer/templates.php';
    }
    if ( kt_check_active_plugin( 'yith-woocommerce-quick-view/init.php' ) ) {
        /**
    	 * Add quick view button in wc product loop
    	 * @package Free version QV
    	 * @access public
    	 * @return void
    	 * @since  1.0.0
    	 * @author AngelsIT
    	 */
        function kt_add_quick_view_button() {
    
    		global $product;
    
    		$label = esc_html( get_option( 'yith-wcqv-button-label' ) );
    
    		echo '<a href="#" title="' . $label . '" class="button quick-view yith-wcqv-button" data-product_id="' . $product->id . '"><i class="fa fa-search"></i></a>';
    	}
        
        add_action( 'kt_function_shop_loop_item_quickview', 'kt_add_quick_view_button', 5 );
        
    }
    if ( kt_check_active_plugin( 'yith-woocommerce-wishlist/init.php' ) ) {
        add_action( 'kt_function_shop_loop_item_wishlist', create_function( '', 'echo do_shortcode( "[yith_wcwl_add_to_wishlist]" );' ), 5 );
    }
    
    if ( kt_check_active_plugin( 'yith-woocommerce-compare/init.php' ) ) {
        add_action( 'kt_function_shop_loop_item_compare', create_function( '', 'echo do_shortcode( "[yith_compare_button]" );' ), 5 );
    }
    /*-Footer Shortcode -------------------------------------- 
    */
    require_once KUTETHEME_PLUGIN_PATH .'template-sc.php';
    
    /*-Fonts -------------------------------------- 
    */
    require_once KUTETHEME_PLUGIN_PATH .'fonts.php';
    
    /*Product brand-----------------------------------------
    */
    require_once KUTETHEME_PLUGIN_PATH .'brands/product_brand.php';
    
    /*-Megamenu-----------------------------------------
    */

    require_once KUTETHEME_PLUGIN_PATH .'kt-tax-meta.php';
    require_once KUTETHEME_PLUGIN_PATH .'ace_editer.php';

}, 99999 );





