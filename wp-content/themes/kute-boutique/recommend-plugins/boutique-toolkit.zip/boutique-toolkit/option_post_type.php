<?php
/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB2 directory)
 *
 * Be sure to replace all instances of 'kt_' with your project's prefix.
 * http://nacin.com/2010/05/11/in-wordpress-prefix-everything/
 *
 * @category boutique
 * @package  ThemeOption
 */


add_action( 'cmb2_init', 'kt_register_metabox' );
/**
 * Hook in and add a demo metabox. Can only happen on the 'cmb2_init' hook.
 */
function kt_register_metabox() {
	global $wp_registered_sidebars;
    $sidebars = array();
  
    foreach ( $wp_registered_sidebars as $sidebar ){
        $sidebars[  $sidebar['id'] ] =   $sidebar['name'];
    }
    
	// Start with an underscore to hide fields from custom fields list
	$prefix = '_kt_page_';
	/**
	 * Sample metabox to demonstrate each field type included
	 */
	$page_option = new_cmb2_box( array(
		'id'            => $prefix . 'metabox',
		'title'         => __( 'Page Options', 'boutique' ),
		'object_types'  => array( 'page', )
	) );

	$page_option->add_field( array(
	    'name'             => __('Page Title', 'boutique'),
	    'desc'             => __("Display of title.", 'boutique'),
	    'id'               => 'kt_show_page_title',
	    'type'             => 'select',
	    'default'          => 'show',
	    'options'          => array(
			'show' =>__('Show','boutique'),
			'hide' => __( 'Hide', 'boutique' ),
	    ),
	) );
	$page_option->add_field( array(
	    'name'             => __('Page layout','boutique'),
	    'id'               => 'kt_page_layout',
	    'type'             => 'radio_image',
	    'options'          => array(
			''      => KUTETHEME_PLUGIN_URL .'/assets/images/none.png',
			'full'  => KUTETHEME_PLUGIN_URL .'/assets/images/1column.png',
			'left'  => KUTETHEME_PLUGIN_URL .'/assets/images/2cl.png',
			'right' => KUTETHEME_PLUGIN_URL .'/assets/images/2cr.png',
	    ),
	) );
    $page_option->add_field( array(
		'name' => __( 'Logo', 'boutique' ),
		'desc'    => __( 'Setting your site\'s logo', 'boutique' ),
		'id'   =>  'kt_page_logo',
		'type' => 'file',
	) );
    $page_option->add_field( array(
    	'name'             => __( 'Header', 'boutique' ),
    	'id'               => 'kt_header',
    	'type'             => 'post_select',
        'post_type'        => 'template',
        'desc'             => __( 'Setting header style display', 'boutique' ),
        'show_option_none' => __( 'Choose header', 'boutique'),
	) );
    
    $page_option->add_field( array(
	    'name'             => __('Page Header','boutique'),
	    'id'               => 'kt_page_header',
	    'type'             => 'select',
	    'options'          => array(
            '0' => 'None',
			'1' => 'Header Style 01',
			'2' => 'Header Style 02',
			'3' => 'Header Style 03',
			'4' => 'Header Style 04',
            '5' => 'Header Style 05',
			'6' => 'Header Style 06',
			'7' => 'Header Style 07',
	    ),
	) );
    
    $page_option->add_field( array(
    	'name'             => __( 'Page Footer', 'boutique' ),
    	'id'               => 'kt_page_footer',
    	'type'             => 'post_select',
        'post_type'        => 'template',
        'desc'             => __( 'Setting footer style display', 'boutique' ),
        'show_option_none' => __( 'Choose footer', 'boutique'),
	) );
    
	$page_option->add_field( array(
		'name'    => __( 'Sidebar for page layout', 'boutique' ),
		'id'      => 'kt_page_used_sidebar',
		'type'    => 'select',
		'show_option_none' => true,
        'options' => $sidebars,
        'desc'    => __( 'Setting sidebar in the area sidebar', 'boutique' ),
        'dependency' => array(
            'id'  => 'kt_page_layout',
            'value' => array( 'left', 'right' )
        )
	) );
        
	$page_option->add_field( array(
		'name' => __( 'Extra page class', 'boutique' ),
		'desc' => __( 'If you wish to add extra classes to the body class of the page (for custom css use), then please add the class(es) here.', 'boutique' ),
		'id'   => 'kt_page_extra_class',
		'type' => 'text',
	) );
    
}

add_action( 'cmb2_init', 'kt_register_about_page_metabox' );
/**
 * Hook in and add a metabox that only appears on the 'About' page
 */
function kt_register_about_page_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_kt_about_';

	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_about_page = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'About Page Metabox', 'boutique' ),
		'object_types' => array( 'page', ), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb_about_page->add_field( array(
		'name' => __( 'Test Text', 'boutique' ),
		'desc' => __( 'field description (optional)', 'boutique' ),
		'id'   => $prefix . 'text',
		'type' => 'text',
	) );


}

//add_action( 'cmb2_init', 'kt_register_repeatable_group_field_metabox' );
/**
 * Hook in and add a metabox to demonstrate repeatable grouped fields
 */
function kt_register_repeatable_group_field_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_kt_group_';

	/**
	 * Repeatable Field Groups
	 */
	$cmb_group = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'Repeating Field Group', 'boutique' ),
		'object_types' => array( 'page', ),
	) );

	// $group_field_id is the field id string, so in this case: $prefix . 'demo'
	$group_field_id = $cmb_group->add_field( array(
		'id'          => $prefix . 'demo',
		'type'        => 'group',
		'description' => __( 'Generates reusable form entries', 'boutique' ),
		'options'     => array(
			'group_title'   => __( 'Entry {#}', 'boutique' ), // {#} gets replaced by row number
			'add_button'    => __( 'Add Another Entry', 'boutique' ),
			'remove_button' => __( 'Remove Entry', 'boutique' ),
			'sortable'      => true, // beta
		),
	) );

	/**
	 * Group fields works the same, except ids only need
	 * to be unique to the group. Prefix is not needed.
	 *
	 * The parent field's id needs to be passed as the first argument.
	 */
	$cmb_group->add_group_field( $group_field_id, array(
		'name'       => __( 'Entry Title', 'boutique' ),
		'id'         => 'title',
		'type'       => 'text',
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );

	$cmb_group->add_group_field( $group_field_id, array(
		'name'        => __( 'Description', 'boutique' ),
		'description' => __( 'Write a short description for this entry', 'boutique' ),
		'id'          => 'description',
		'type'        => 'textarea_small',
	) );

	$cmb_group->add_group_field( $group_field_id, array(
		'name' => __( 'Entry Image', 'boutique' ),
		'id'   => 'image',
		'type' => 'file',
	) );

	$cmb_group->add_group_field( $group_field_id, array(
		'name' => __( 'Image Caption', 'boutique' ),
		'id'   => 'image_caption',
		'type' => 'text',
	) );

}

add_action( 'cmb2_init', 'kt_register_theme_options_metabox' );
/**
 * Hook in and register a metabox to handle a theme options page
 */
function kt_register_theme_options_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$option_key = '_kt_theme_options';

	/**
	 * Metabox for an options page. Will not be added automatically, but needs to be called with
	 * the `cmb2_metabox_form` helper function. See wiki for more info.
	 */
	$cmb_options = new_cmb2_box( array(
		'id'      => $option_key . 'page',
		'title'   => __( 'Theme Options Metabox', 'boutique' ),
		'hookup'  => false, // Do not need the normal user/post hookup
		'show_on' => array(
			// These are important, don't remove
			'key'   => 'options-page',
			'value' => array( $option_key )
		),
	) );

	/**
	 * Options fields ids only need
	 * to be unique within this option group.
	 * Prefix is not needed.
	 */
	$cmb_options->add_field( array(
		'name'    => __( 'Site Background Color', 'boutique' ),
		'desc'    => __( 'field description (optional)', 'boutique' ),
		'id'      => 'bg_color',
		'type'    => 'colorpicker',
		'default' => '#ffffff',
	) );

}
